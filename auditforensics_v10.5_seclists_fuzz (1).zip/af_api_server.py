#!/usr/bin/env python3
"""Run the agent manager API outside Streamlit (recommended for production) or embedded in it.

  python af_api_server.py            # foreground service (systemd / docker)
Environment:
  AF_API_HOST (default 127.0.0.1)    AF_AGENT_API_PORT (8765)
  AF_TLS_CERT / AF_TLS_KEY           HTTPS for the agent API
  AF_TLS_CLIENT_CA                   require client certificates (mutual TLS) signed by this CA
  AF_ENROLL_PORT (8766)              bootstrap listener for CSR enrollment (TLS only; needs the CA in AF_PKI_DIR)
  AF_ALLOW_PLAINTEXT=1               permit plain HTTP on a non-loopback address (lab only)
"""
import os, socket, ssl, sys, threading, time
from pathlib import Path

from af_util import af_home

STATUS = {"running": False, "error": "", "scheme": "http", "host": "", "port": 0, "enroll_port": 0, "mtls": False}
_servers = []


class PlaintextRefused(RuntimeError):
    pass


def is_loopback(host):
    return host in ("localhost", "::1") or host.startswith("127.")


def tls_kwargs():
    cert, key, ca = os.environ.get("AF_TLS_CERT"), os.environ.get("AF_TLS_KEY"), os.environ.get("AF_TLS_CLIENT_CA")
    if not (cert and key):
        return {}
    kw = {"ssl_certfile": cert, "ssl_keyfile": key}
    if ca:
        kw.update(ssl_ca_certs=ca, ssl_cert_reqs=ssl.CERT_REQUIRED)
    return kw


def preflight(host, port):
    """Raise a readable error if the port is taken (instead of failing silently inside a thread)."""
    s = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
    except OSError as e:
        raise RuntimeError(f"cannot listen on {host}:{port}: {e.strerror or e}")
    finally:
        s.close()


def _launch(app, host, port, tls, http_cls=None):
    import uvicorn
    cfg = uvicorn.Config(app, host=host, port=port, log_level="warning", http=http_cls or "auto", **tls)
    srv = uvicorn.Server(cfg)
    srv.install_signal_handlers = lambda: None            # not the main thread
    err = []

    def run():
        try:
            srv.run()
        except BaseException as e:                         # surface instead of swallowing
            err.append(e)
    t = threading.Thread(target=run, name=f"af-api-{port}", daemon=True)
    t.start()
    for _ in range(100):
        if srv.started or err or not t.is_alive():
            break
        time.sleep(0.1)
    if err or not srv.started:
        raise RuntimeError(f"API server on {host}:{port} failed to start: {err[0] if err else 'timeout'}")
    _servers.append(srv)
    return srv


def start(host=None, port=None, enroll_port=None):
    """Start the API (and the enrollment listener when TLS + a CA are available). Returns STATUS; never raises."""
    if STATUS["running"]:
        return STATUS
    try:
        import af_manager_api as api
        host = host or os.environ.get("AF_API_HOST", "127.0.0.1")
        port = int(port or os.environ.get("AF_AGENT_API_PORT", "8765"))
        tls = tls_kwargs()
        if not tls and not is_loopback(host) and os.environ.get("AF_ALLOW_PLAINTEXT") != "1":
            raise PlaintextRefused(
                f"refusing to serve the agent API over plain HTTP on {host}: agents send tokens and findings. "
                "Set AF_TLS_CERT/AF_TLS_KEY (see INSTALL.md), bind to 127.0.0.1, or set AF_ALLOW_PLAINTEXT=1 for a lab.")
        preflight(host, port)
        _launch(api.app, host, port, tls, api.PeerCertProtocol)
        STATUS.update(running=True, error="", scheme="https" if tls else "http", host=host, port=port,
                      mtls="ssl_ca_certs" in tls)
        ep = int(enroll_port or os.environ.get("AF_ENROLL_PORT", "8766"))
        pki = Path(os.environ.get("AF_PKI_DIR") or (af_home() / "pki"))
        if tls and (pki / "ca.key").exists() and ep:
            etls = {"ssl_certfile": tls["ssl_certfile"], "ssl_keyfile": tls["ssl_keyfile"]}      # TLS only: no client cert yet
            preflight(host, ep)
            _launch(api.enroll_app, host, ep, etls)
            STATUS["enroll_port"] = ep
    except Exception as e:
        STATUS.update(running=False, error=str(e))
    return STATUS


def stop():
    for s in _servers:
        s.should_exit = True
    _servers.clear()
    STATUS.update(running=False)


def main():
    st = start()
    if not st["running"]:
        sys.exit(f"[!] {st['error']}")
    print(f"[+] agent API on {st['scheme']}://{st['host']}:{st['port']}"
          + (f" (mTLS required)" if st["mtls"] else "")
          + (f"; enrollment on :{st['enroll_port']}" if st["enroll_port"] else ""))
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        stop()


if __name__ == "__main__":
    main()
