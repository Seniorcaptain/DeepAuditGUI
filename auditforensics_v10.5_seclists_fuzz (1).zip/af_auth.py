#!/usr/bin/env python3
"""AuditForensics UI authentication & authorisation (stdlib + sqlite + streamlit).

 * scrypt password hashing (per-user salt), NIST 800-63B style length-first policy
 * TOTP MFA (RFC 6238) with replay protection; AF_REQUIRE_MFA=1 forces enrolment
 * roles: admin / analyst / auditor (read-only) -> permission checks via can()
 * lockout after repeated failures, idle-session timeout, audit trail of auth + privileged actions
 Controls: NIST 800-53 AC-2/AC-3/AC-7/AC-11/AU-2/IA-2/IA-5, ISO 27001 A.5.15-A.5.18/A.8.2/A.8.5,
 SOC 2 CC6.1-CC6.3, HIPAA 164.312(a)(1)/(a)(2)(iii)/(d).
"""
import base64, hashlib, hmac, json, os, re, secrets, sqlite3, struct, sys, time
import af_audit
from af_util import af_home, private_write, utc_iso

try:
    import af_vault as _vault
except Exception:            # vault optional: TOTP secrets then stored unencrypted
    _vault = None

ROLE_PERMS = {
    "admin": {"view", "export", "scan", "agents", "attest", "risk_accept", "schedule", "admin"},
    "analyst": {"view", "export", "scan", "agents", "attest"},
    "auditor": {"view", "export"},
}
MAX_FAILS = int(os.environ.get("AF_MAX_LOGIN_FAILS", "5"))
LOCK_SECONDS = int(os.environ.get("AF_LOCKOUT_MIN", "15")) * 60
IDLE_SECONDS = int(os.environ.get("AF_UI_IDLE_MIN", "180")) * 60
MIN_PW = int(os.environ.get("AF_MIN_PW", "12"))
REQUIRE_MFA = os.environ.get("AF_REQUIRE_MFA", "0") == "1"
_COMMON = {"password1234", "123456789012", "qwertyuiop12", "administrator", "changemechangeme",
           "welcome12345", "letmein12345", "iloveyou1234", "passwordpassword", "auditforensics",
           "password12345", "qwertyuiopasdf", "1234567890123", "abcdefghijkl", "adminadminadmin", "welcome123456",
           "changeme12345", "p@ssw0rd1234", "passw0rd12345", "letmeinletmein", "admin1234567", "trustno1trustno1"}
BREACH_CHECK = os.environ.get("AF_HIBP", "1") != "0"           # k-anonymity range query; fails open when offline
BREACHED_FILE = os.environ.get("AF_BREACHED_FILE", "")         # optional offline list: SHA-1 hashes, sorted (HIBP format)


def can(user, perm):
    return bool(user) and perm in ROLE_PERMS.get(user.get("role"), set())


# ------------------------------------------------------------------ storage
def _db(path):
    c = sqlite3.connect(str(path), timeout=30)
    c.row_factory = sqlite3.Row
    return c


def init(path):
    c = _db(path)
    c.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY, pw_hash TEXT NOT NULL, role TEXT NOT NULL,
            totp_secret TEXT, mfa_enabled INTEGER DEFAULT 0, totp_last_step INTEGER DEFAULT 0,
            must_change_pw INTEGER DEFAULT 0, disabled INTEGER DEFAULT 0,
            failed_count INTEGER DEFAULT 0, locked_until REAL DEFAULT 0,
            created TEXT, last_login TEXT);
        CREATE TABLE IF NOT EXISTS ui_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, username TEXT, event TEXT, detail TEXT);""")
    cols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
    for col, ddl in (("recovery_codes", "TEXT"), ("auth_source", "TEXT DEFAULT 'local'")):
        if col not in cols:
            c.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
    af_audit.ensure_chain_columns(c, "ui_audit")
    c.commit(); c.close()


def audit(path, username, event, detail=""):
    """Hash-chained audit row (tamper-evident; optionally mirrored to syslog via AF_SYSLOG)."""
    af_audit.append(path, "ui_audit", ts=utc_iso(), username=username, event=event, detail=str(detail)[:300])


def verify_audit(path):
    return af_audit.verify(path, "ui_audit")


# ------------------------------------------------------------------ passwords
def hash_password(pw):
    salt = secrets.token_bytes(16)
    n, r, p = 2 ** 15, 8, 1
    dk = hashlib.scrypt(pw.encode(), salt=salt, n=n, r=r, p=p, dklen=32, maxmem=2 ** 26)
    return f"scrypt${n}${r}${p}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(pw, stored):
    try:
        _, n, r, p, salt, dk = stored.split("$")
        calc = hashlib.scrypt(pw.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p),
                              dklen=32, maxmem=2 ** 26)
        return hmac.compare_digest(calc, base64.b64decode(dk))
    except Exception:
        return False


def password_problems(pw, username=""):
    """Length-first policy (NIST SP 800-63B): minimum length, no trivial/contextual passwords."""
    out = []
    if len(pw) < MIN_PW:
        out.append(f"at least {MIN_PW} characters")
    if len(pw) > 128:
        out.append("at most 128 characters")
    if username and username.lower() in pw.lower():
        out.append("must not contain the username")
    if pw.lower() in _COMMON or len(set(pw)) < 5:
        out.append("too common / too repetitive")
    elif not out and breached_count(pw):
        out.append("appears in known data breaches - choose another")
    return out


def _offline_breached(sha1_hex, path):
    """Binary search a sorted list of uppercase SHA-1 hashes (optionally ``HASH:count``) without loading it."""
    want = sha1_hex.encode()
    try:
        with open(path, "rb") as f:
            lo, hi = 0, os.fstat(f.fileno()).st_size            # invariant: target (if any) starts in [lo, hi); lo is a line start
            while lo < hi:
                mid = (lo + hi) // 2
                if mid > lo:
                    f.seek(mid - 1)
                    f.readline()                                 # advance to the first line starting at or after mid
                else:
                    f.seek(lo)
                start = f.tell()
                if start >= hi:
                    hi = mid
                    continue
                key = f.readline().strip().split(b":")[0].upper()
                if key == want:
                    return True
                if key < want:
                    lo = f.tell()
                else:
                    hi = mid
            return False
    except OSError:
        return False


def breached_count(pw):
    """Times this password appears in known breaches (0 = not found / check unavailable)."""
    h = hashlib.sha1(pw.encode()).hexdigest().upper()          # nosec: SHA-1 is the HIBP lookup key, not a security hash
    if BREACHED_FILE and _offline_breached(h, BREACHED_FILE):
        return 1
    if not BREACH_CHECK:
        return 0
    try:
        import requests
        r = requests.get(f"https://api.pwnedpasswords.com/range/{h[:5]}", headers={"Add-Padding": "true"}, timeout=3)
        if r.status_code != 200:
            return 0
        for line in r.text.splitlines():
            suf, _, n = line.partition(":")
            if suf.strip() == h[5:] and int(n or 0) > 0:
                return int(n)
    except Exception:
        pass
    return 0


# ------------------------------------------------------------------ TOTP (RFC 6238)
def new_totp_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def totp_at(secret_b32, t=None, step=30, digits=6):
    key = base64.b32decode(secret_b32 + "=" * (-len(secret_b32) % 8), casefold=True)
    counter = int((time.time() if t is None else t) // step)
    h = hmac.new(key, struct.pack(">Q", counter), "sha1").digest()
    o = h[-1] & 0x0F
    code = (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return f"{code:0{digits}d}", counter


def totp_check(secret_b32, code, last_step=0, window=1, now=None):
    """Returns the matched time-step (for replay protection) or None."""
    code = (code or "").strip().replace(" ", "")
    if not re.fullmatch(r"\d{6}", code):
        return None
    now = time.time() if now is None else now
    for off in range(-window, window + 1):
        c, step = totp_at(secret_b32, now + off * 30)
        if hmac.compare_digest(c, code) and step > last_step:
            return step
    return None


def otpauth_uri(username, secret, issuer="AuditForensics"):
    from urllib.parse import quote
    return f"otpauth://totp/{quote(issuer)}:{quote(username)}?secret={secret}&issuer={quote(issuer)}&digits=6&period=30"


def _enc(s, username=""):
    return _vault.encrypt_text(s, f"users.totp_secret|{username}") if _vault else s


def _dec(s, username=""):
    return _vault.decrypt_text(s, f"users.totp_secret|{username}") if _vault else s


# ------------------------------------------------------------------ user ops
def get_user(path, username):
    c = _db(path)
    r = c.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    c.close()
    return dict(r) if r else None


def list_users(path):
    c = _db(path)
    rows = [dict(r) for r in c.execute(
        "SELECT username, role, mfa_enabled, must_change_pw, disabled, failed_count, last_login, created "
        "FROM users ORDER BY username")]
    c.close()
    return rows


def create_user(path, username, password, role="analyst", must_change=False, actor="system"):
    username = username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,64}", username):
        raise ValueError("username: 3-64 chars of letters, digits, . _ @ -")
    if role not in ROLE_PERMS:
        raise ValueError("unknown role")
    probs = password_problems(password, username)
    if probs:
        raise ValueError("password: " + "; ".join(probs))
    c = _db(path)
    try:
        c.execute("INSERT INTO users (username,pw_hash,role,must_change_pw,created) VALUES (?,?,?,?,?)",
                  (username, hash_password(password), role, int(must_change), utc_iso()))
        c.commit()
    except sqlite3.IntegrityError:
        raise ValueError("user already exists")
    finally:
        c.close()
    audit(path, actor, "user_created", f"{username} role={role}")


def _count_admins(path, excluding=None):
    c = _db(path)
    n = c.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND disabled=0 AND username<>?",
                  (excluding or "",)).fetchone()[0]
    c.close()
    return n


def update_user(path, username, actor, **fields):
    allowed = {"role", "disabled", "must_change_pw", "mfa_enabled", "totp_secret", "pw_hash",
               "failed_count", "locked_until", "totp_last_step", "recovery_codes", "auth_source"}
    if not set(fields) <= allowed:                       # real validation (assert is stripped under python -O)
        raise ValueError(f"cannot update field(s): {', '.join(sorted(set(fields) - allowed))}")
    if "role" in fields and fields["role"] not in ROLE_PERMS:
        raise ValueError("unknown role")
    cur = get_user(path, username)
    if not cur:
        raise ValueError("no such user")
    if cur["role"] == "admin" and (fields.get("role", "admin") != "admin" or fields.get("disabled")):
        if _count_admins(path, excluding=username) == 0:
            raise ValueError("cannot remove or disable the last active administrator")
    sets = ", ".join(f"{k}=?" for k in fields)
    c = _db(path)
    c.execute(f"UPDATE users SET {sets} WHERE username=?", (*fields.values(), username))  # nosec B608 - identifiers come from internal constants, values are bound
    c.commit(); c.close()
    audit(path, actor, "user_updated", f"{username}: {', '.join(k for k in fields if k not in ('pw_hash', 'totp_secret'))}")


def delete_user(path, username, actor):
    cur = get_user(path, username)
    if cur and cur["role"] == "admin" and _count_admins(path, excluding=username) == 0:
        raise ValueError("cannot delete the last active administrator")
    c = _db(path); c.execute("DELETE FROM users WHERE username=?", (username,)); c.commit(); c.close()
    audit(path, actor, "user_deleted", username)


def _public(u):
    sso = (u["auth_source"] if "auth_source" in u.keys() else "local") == "sso"
    needs = (not sso) and (bool(u["must_change_pw"]) or (REQUIRE_MFA and not u["mfa_enabled"]))
    return {"username": u["username"], "role": u["role"], "mfa": bool(u["mfa_enabled"]), "needs_setup": needs,
            "sso": sso}


def authenticate(path, username, password, code=""):
    """-> (ok, user_dict|None, message). Generic failure text; constant-ish timing for unknown users."""
    generic = "Invalid credentials, MFA code, or account locked."
    u = get_user(path, (username or "").strip())
    if not u:
        hash_password(password or "x")                      # equalise timing
        audit(path, username or "?", "login_failed", "unknown user")
        return False, None, generic
    now = time.time()
    if u["disabled"] or u["locked_until"] > now:
        audit(path, u["username"], "login_blocked", "disabled" if u["disabled"] else "locked")
        return False, None, generic
    ok = verify_password(password or "", u["pw_hash"])
    step = None
    if ok and u["mfa_enabled"]:
        step = totp_check(_dec(u["totp_secret"], u["username"]), code, u["totp_last_step"])
        recovered = False
        if step is None and _looks_like_recovery(code):
            recovered = consume_recovery_code(path, u["username"], code)
            step = 0 if recovered else None
            if recovered:
                audit(path, u["username"], "mfa_recovery_code_used", "a one-time recovery code was consumed")
        ok = step is not None
    if not ok:
        fails = u["failed_count"] + 1
        locked = now + LOCK_SECONDS if fails >= MAX_FAILS else 0
        update_user(path, u["username"], "system", failed_count=0 if locked else fails, locked_until=locked)
        audit(path, u["username"], "login_failed", f"attempt {fails}" + (" -> LOCKED" if locked else ""))
        return False, None, generic
    fields = {"failed_count": 0, "locked_until": 0}
    if step:
        fields["totp_last_step"] = step
    update_user(path, u["username"], "system", **fields)
    c = _db(path)
    c.execute("UPDATE users SET last_login=? WHERE username=?", (utc_iso(), u["username"]))
    c.commit(); c.close()
    audit(path, u["username"], "login_ok", "mfa" if u["mfa_enabled"] else "password only")
    return True, _public(get_user(path, u["username"])), ""


def change_password(path, username, current, new, actor=None):
    u = get_user(path, username)
    if not u or not verify_password(current, u["pw_hash"]):
        raise ValueError("current password incorrect")
    probs = password_problems(new, username)
    if probs:
        raise ValueError("new password: " + "; ".join(probs))
    if verify_password(new, u["pw_hash"]):
        raise ValueError("new password must differ from the current one")
    update_user(path, username, actor or username, pw_hash=hash_password(new), must_change_pw=0)


# ------------------------------------------------------------------ MFA recovery codes
def _looks_like_recovery(code):
    return bool(re.fullmatch(r"[a-z2-7]{5}-?[a-z2-7]{5}", (code or "").strip().lower()))


def _rc_hash(code, salt):
    return hashlib.sha256((salt + re.sub(r"[^a-z2-7]", "", code.lower())).encode()).hexdigest()


def set_recovery_codes(path, username, actor=None, n=10):
    """Create n one-time codes; returns them ONCE in clear text, stores salted hashes only."""
    codes = ["".join(secrets.choice("abcdefghijklmnopqrstuvwxyz234567") for _ in range(10)) for _ in range(n)]
    shown = [c[:5] + "-" + c[5:] for c in codes]
    stored = []
    for c in codes:
        salt = secrets.token_hex(8)
        stored.append(f"{salt}${_rc_hash(c, salt)}")
    update_user(path, username, actor or username, recovery_codes=json.dumps(stored))
    audit(path, actor or username, "recovery_codes_generated", username)
    return shown


def recovery_codes_left(path, username):
    u = get_user(path, username)
    try:
        return len(json.loads(u["recovery_codes"] or "[]"))
    except (TypeError, ValueError):
        return 0


def consume_recovery_code(path, username, code):
    u = get_user(path, username)
    try:
        stored = json.loads(u["recovery_codes"] or "[]")
    except (TypeError, ValueError):
        return False
    hit = None
    for item in stored:                                    # compare against all (no early exit)
        salt, _, h = item.partition("$")
        if hmac.compare_digest(_rc_hash(code, salt), h):
            hit = item
    if hit is None:
        return False
    stored.remove(hit)
    c = _db(path); c.execute("UPDATE users SET recovery_codes=? WHERE username=?", (json.dumps(stored), username)); c.commit(); c.close()
    return True


# ------------------------------------------------------------------ step-up authentication
STEPUP_SECONDS = int(os.environ.get("AF_STEPUP_MIN", "5")) * 60


def verify_step_up(path, username, password, code=""):
    """Re-verify password (+ TOTP when MFA is on) before a sensitive action."""
    u = get_user(path, username)
    if not u or u["disabled"] or not verify_password(password or "", u["pw_hash"]):
        audit(path, username, "stepup_failed", "password")
        return False
    if u["mfa_enabled"]:
        step = totp_check(_dec(u["totp_secret"], username), code, u["totp_last_step"])
        if step is None:
            audit(path, username, "stepup_failed", "mfa")
            return False
        update_user(path, username, "system", totp_last_step=step)
    audit(path, username, "stepup_ok")
    return True


def step_up_ok(st):
    return time.time() < st.session_state.get("stepup_until", 0)


def require_step_up(st, path, user, purpose="this action", key="su"):
    """Streamlit helper. True when the user re-authenticated in the last AF_STEPUP_MIN minutes; otherwise renders
    the re-authentication form and returns False. SSO users authenticate (with MFA) at their identity provider."""
    if user.get("sso") or user.get("noauth") or step_up_ok(st):
        return True
    with st.form(f"{key}_form"):
        st.caption(f"🔐 Confirm your identity to continue with {purpose}.")
        pw = st.text_input("Your password", type="password", key=f"{key}_pw")
        code = st.text_input("MFA code", key=f"{key}_code", max_chars=8) if user.get("mfa") else ""
        if st.form_submit_button("Confirm"):
            if verify_step_up(path, user["username"], pw, code):
                st.session_state["stepup_until"] = time.time() + STEPUP_SECONDS
                st.rerun()
            st.error("Confirmation failed.")
    return False


# ------------------------------------------------------------------ first-run setup code
_setup_fails = []


def setup_code_path():
    return af_home() / "setup_code"


def get_setup_code():
    """One-time code that must be typed into the first-run form. Printed to the server console and stored mode 600,
    so only someone with access to the host (not just to the port) can claim the administrator account."""
    p = setup_code_path()
    if p.exists():
        return p.read_text().strip()
    code = secrets.token_urlsafe(9)
    private_write(p, code)
    print(f"\n[AuditForensics] FIRST-RUN SETUP CODE: {code}   (also stored in {p})\n", file=sys.stderr, flush=True)
    return code


def check_setup_code(code):
    now = time.time()
    _setup_fails[:] = [t for t in _setup_fails if now - t < 60]
    if len(_setup_fails) >= 5:
        return False
    ok = hmac.compare_digest((code or "").strip().encode(), get_setup_code().encode())
    if not ok:
        _setup_fails.append(now)
    return ok


def clear_setup_code():
    try:
        setup_code_path().unlink()
    except OSError:
        pass


# ------------------------------------------------------------------ SSO (OpenID Connect via Streamlit's native st.login)
_ROLE_RANK = {"admin": 3, "analyst": 2, "auditor": 1}


def sso_enabled():
    return os.environ.get("AF_SSO", "0") == "1"


def map_sso_role(claims):
    """Highest-privilege role granted by the IdP groups/roles claim via AF_SSO_ROLE_MAP (JSON {group: role}).
    Falls back to AF_SSO_DEFAULT_ROLE (default 'auditor'; 'none' denies sign-in)."""
    claim = os.environ.get("AF_SSO_ROLE_CLAIM", "groups")
    try:
        mapping = json.loads(os.environ.get("AF_SSO_ROLE_MAP", "{}"))
    except ValueError:
        mapping = {}
    vals = claims.get(claim) or []
    vals = [vals] if isinstance(vals, str) else list(vals)
    roles = [mapping[v] for v in vals if mapping.get(v) in _ROLE_RANK]
    if roles:
        return max(roles, key=_ROLE_RANK.get)
    d = os.environ.get("AF_SSO_DEFAULT_ROLE", "auditor")
    return d if d in _ROLE_RANK else None


def _claims(st):
    u = st.user
    keys = ("email", "name", "email_verified", os.environ.get("AF_SSO_ROLE_CLAIM", "groups"))
    out = {}
    for k in keys:
        try:
            v = u.get(k) if hasattr(u, "get") else getattr(u, k, None)
        except Exception:
            v = None
        if v is not None:
            out[k] = v
    return out


def sso_provision(path, claims):
    """Create/update the local account for an authenticated IdP user. -> (user_dict|None, message)."""
    email = str(claims.get("email", "")).strip().lower()
    if not email or not re.fullmatch(r"[A-Za-z0-9_.@+-]{3,128}", email):
        return None, "The identity provider did not return a usable email address."
    if claims.get("email_verified") is False:
        return None, "Your email address is not verified at the identity provider."
    role = map_sso_role(claims)
    if role is None:
        return None, "Your account is not authorised for AuditForensics (no mapped role)."
    u = get_user(path, email)
    c = _db(path)
    if u is None:
        c.execute("INSERT INTO users (username,pw_hash,role,created,auth_source) VALUES (?,?,?,?,'sso')", (email, "!sso", role, utc_iso()))
        audit(path, email, "sso_user_created", f"role={role}")
    elif (u["auth_source"] or "local") != "sso":
        c.close()
        return None, "A local account with this email already exists; ask an administrator to convert it."
    else:
        if u["disabled"]:
            c.close()
            return None, "Account disabled."
        if u["role"] != role:
            audit(path, email, "sso_role_changed", f"{u['role']} -> {role}")
        c.execute("UPDATE users SET role=? WHERE username=?", (role, email))
    c.execute("UPDATE users SET last_login=? WHERE username=?", (utc_iso(), email))
    c.commit(); c.close()
    audit(path, email, "login_ok", "sso")
    return _public(get_user(path, email)), ""


# ------------------------------------------------------------------ Streamlit views
def _bootstrap(st, path):
    st.title("🛡️ AuditForensics — first-run setup")
    env_u, env_p = os.environ.get("AF_ADMIN_USER"), os.environ.get("AF_ADMIN_PASSWORD")
    if env_u and env_p:
        try:
            create_user(path, env_u, env_p, "admin", actor="bootstrap-env")
            st.success("Administrator created from environment. Reloading…"); st.rerun()
        except ValueError as e:
            st.error(f"AF_ADMIN_USER / AF_ADMIN_PASSWORD rejected: {e}")
            st.stop()
    get_setup_code()
    st.warning("No users exist. Enter the **setup code** printed in the server console (or stored in "
               f"`{setup_code_path()}`) to create the first administrator. Without host access nobody can claim it; "
               "or provision headlessly with AF_ADMIN_USER / AF_ADMIN_PASSWORD.")
    sc = st.text_input("Setup code", type="password", key="bs_code")
    u = st.text_input("Administrator username", "admin", key="bs_user")
    p1 = st.text_input(f"Password (min {MIN_PW} chars)", type="password", key="bs_p1")
    p2 = st.text_input("Confirm password", type="password", key="bs_p2")
    if st.button("Create administrator", type="primary", key="bs_btn"):
        if not check_setup_code(sc):
            st.error("Setup code incorrect (or too many attempts - wait a minute).")
        elif p1 != p2:
            st.error("Passwords do not match.")
        else:
            try:
                create_user(path, u, p1, "admin", actor="bootstrap")
                clear_setup_code()
                st.success("Created. Sign in now."); st.rerun()
            except ValueError as e:
                st.error(str(e))
    st.stop()


def logout(st, path, reason="logout"):
    u = st.session_state.get("auth_user")
    if u:
        audit(path, u["username"], reason)
    for k in ("auth_user", "auth_last", "mfa_pending", "stepup_until"):
        st.session_state.pop(k, None)
    if u and u.get("sso") and hasattr(st, "logout"):
        try:
            st.logout()
        except Exception:
            pass


def gate(st, path):
    """Call right after st.set_page_config(). Returns the user dict or stops the script."""
    if os.environ.get("AF_UI_AUTH", "1") == "0":
        st.error("⚠️ UI authentication is DISABLED (AF_UI_AUTH=0): anyone who can reach this port has full admin access.")
        return {"username": "local-noauth", "role": "admin", "mfa": False, "needs_setup": False, "noauth": True}
    init(path)
    ss, now = st.session_state, time.time()
    u = ss.get("auth_user")
    if u:
        if now - ss.get("auth_last", now) > IDLE_SECONDS:
            logout(st, path, "session_timeout")
            st.info("Session expired due to inactivity. Please sign in again.")
            u = None
        else:
            fresh = get_user(path, u["username"])
            if not fresh or fresh["disabled"]:
                logout(st, path, "session_revoked"); u = None
            else:
                ss["auth_last"] = now
                ss["auth_user"] = u = _public(fresh)
    if u:
        if u["needs_setup"]:
            render_account(st, path, u, forced=True)
            st.stop()
        return u
    c = _db(path); n = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]; c.close()
    if n == 0:
        _bootstrap(st, path)
    st.title("🛡️ AuditForensics — sign in")
    if sso_enabled():
        if not hasattr(st, "login"):
            st.error("AF_SSO=1 needs Streamlit >= 1.42 (native OIDC) and an [auth] section in .streamlit/secrets.toml.")
        elif getattr(getattr(st, "user", None), "is_logged_in", False):
            user, msg = sso_provision(path, _claims(st))
            if user:
                ss["auth_user"], ss["auth_last"] = user, time.time()
                st.rerun()
            st.error(msg)
            st.button("Sign out of SSO", on_click=st.logout)
            st.stop()
        else:
            if st.button("Sign in with SSO", type="primary", key="sso_btn"):
                st.login(os.environ.get("AF_SSO_PROVIDER") or None)
            if os.environ.get("AF_SSO_ONLY", "0") == "1":
                st.stop()
            st.divider()
    name = st.text_input("Username", key="li_user")
    pw = st.text_input("Password", type="password", key="li_pass")
    code = st.text_input("MFA code (if enabled)", key="li_code", max_chars=8)
    if st.button("Sign in", type="primary", key="li_btn"):
        ok, user, msg = authenticate(path, name, pw, code)
        if ok:
            ss["auth_user"], ss["auth_last"] = user, time.time()
            st.rerun()
        st.error(msg)
    st.stop()


def render_account(st, path, user, forced=False):
    if forced:
        st.title("🔐 Complete account setup")
        st.info("Before continuing: " + ("set a new password. " if get_user(path, user["username"])["must_change_pw"] else "")
                + ("Enable MFA (required by policy)." if REQUIRE_MFA and not user["mfa"] else ""))
    else:
        st.subheader(f"Account — {user['username']} ({user['role']})")
    with st.expander("Change password", expanded=forced and get_user(path, user["username"])["must_change_pw"] == 1):
        cur = st.text_input("Current password", type="password", key="cp_cur")
        n1 = st.text_input(f"New password (min {MIN_PW})", type="password", key="cp_n1")
        n2 = st.text_input("Confirm new password", type="password", key="cp_n2")
        if st.button("Update password", key="cp_btn"):
            if n1 != n2:
                st.error("New passwords do not match.")
            else:
                try:
                    change_password(path, user["username"], cur, n1)
                    st.success("Password updated."); st.rerun()
                except ValueError as e:
                    st.error(str(e))
    with st.expander("Multi-factor authentication (TOTP)", expanded=forced and REQUIRE_MFA and not user["mfa"]):
        if user["mfa"]:
            st.success("MFA is enabled.")
            left = recovery_codes_left(path, user["username"])
            st.caption(f"Recovery codes remaining: {left}")
            if require_step_up(st, path, user, "changing MFA settings", key="su_mfa"):
                if st.button("Generate new recovery codes", key="rc_new"):
                    st.session_state["rc_shown"] = set_recovery_codes(path, user["username"])
                if st.session_state.get("rc_shown"):
                    st.warning("Save these one-time codes now - they are shown only once. Each works once instead of an authenticator code.")
                    st.code("\n".join(st.session_state["rc_shown"]))
                if not REQUIRE_MFA and st.button("Disable MFA", key="mfa_off"):
                    update_user(path, user["username"], user["username"], mfa_enabled=0, totp_secret=None, recovery_codes=None)
                    st.session_state.pop("stepup_until", None)
                    st.rerun()
        else:
            sec = st.session_state.setdefault("mfa_pending", new_totp_secret())
            st.write("Add this key to an authenticator app (Google/Microsoft Authenticator, Authy, 1Password):")
            st.code(sec)
            st.caption(otpauth_uri(user["username"], sec))
            code = st.text_input("Enter the 6-digit code to confirm", key="mfa_on_code", max_chars=8)
            if st.button("Enable MFA", key="mfa_on"):
                step = totp_check(sec, code)
                if step:
                    update_user(path, user["username"], user["username"], totp_secret=_enc(sec, user["username"]),
                                mfa_enabled=1, totp_last_step=step)
                    st.session_state["rc_shown"] = set_recovery_codes(path, user["username"])
                    st.session_state.pop("mfa_pending", None); st.rerun()
                st.error("Code did not match — check your device clock.")
    if not forced and st.button("Sign out", key="signout"):
        logout(st, path); st.rerun()
    if forced:
        if st.button("Sign out", key="signout_f"):
            logout(st, path); st.rerun()


def render_user_admin(st, path, user):
    if not can(user, "admin"):
        st.info("User management is restricted to administrators.")
        return
    st.subheader("👥 Users & roles")
    st.caption("admin: everything · analyst: scan, agents, attest, export · auditor: read-only + export")
    st.dataframe(list_users(path), hide_index=True, use_container_width=True)
    if not require_step_up(st, path, user, "user administration", key="su_admin"):
        st.info("Re-authenticate above to create, modify or delete accounts.")
        return
    a, b, c_ = st.columns(3)
    nu = a.text_input("New username", key="nu_name")
    nr = b.selectbox("Role", list(ROLE_PERMS), index=1, key="nu_role")
    if c_.button("Create user (temporary password)", key="nu_btn"):
        tmp = secrets.token_urlsafe(12)
        try:
            create_user(path, nu, tmp, nr, must_change=True, actor=user["username"])
            st.success(f"Created {nu}. Temporary password (shown once): `{tmp}` — must be changed at first login.")
        except ValueError as e:
            st.error(str(e))
    names = [u["username"] for u in list_users(path)]
    if names:
        t1, t2, t3, t4 = st.columns(4)
        who = t1.selectbox("User", names, key="ua_who")
        role = t2.selectbox("Set role", list(ROLE_PERMS), key="ua_role")
        if t2.button("Apply role", key="ua_role_btn"):
            try:
                update_user(path, who, user["username"], role=role); st.rerun()
            except ValueError as e:
                st.error(str(e))
        if t3.button("Reset password", key="ua_reset"):
            tmp = secrets.token_urlsafe(12)
            update_user(path, who, user["username"], pw_hash=hash_password(tmp), must_change_pw=1,
                        failed_count=0, locked_until=0)
            st.success(f"Temporary password for {who} (shown once): `{tmp}`")
        tgt = get_user(path, who)
        if t4.button("Enable" if tgt and tgt["disabled"] else "Disable", key="ua_dis"):
            try:
                update_user(path, who, user["username"], disabled=0 if tgt["disabled"] else 1); st.rerun()
            except ValueError as e:
                st.error(str(e))
        x1, x2 = st.columns(2)
        if x1.button("Reset MFA", key="ua_mfa"):
            update_user(path, who, user["username"], mfa_enabled=0, totp_secret=None); st.success("MFA reset.")
        if x2.button("Delete user", key="ua_del") and who != user["username"]:
            try:
                delete_user(path, who, user["username"]); st.rerun()
            except ValueError as e:
                st.error(str(e))
    with st.expander("🧾 Audit trail (authentication & privileged actions)"):
        if st.button("Verify audit chain integrity", key="audit_verify"):
            r = verify_audit(path)
            (st.success if r["ok"] else st.error)(f"{r['message']} ({r['checked']} chained rows checked"
                                                  + (f"; first bad row id {r['first_bad_id']}" if r["first_bad_id"] else "") + ")")
        c = _db(path)
        rows = [dict(r) for r in c.execute("SELECT ts, username, event, detail FROM ui_audit ORDER BY id DESC LIMIT 500")]
        c.close()
        st.dataframe(rows, hide_index=True, use_container_width=True)
