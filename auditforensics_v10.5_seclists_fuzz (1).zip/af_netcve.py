#!/usr/bin/env python3
"""CVEs for network services: banner/version -> CPE -> NVD -> filtered, enriched, prioritised.

Honest limits (shown in the UI):
  * A banner version is a claim by the server. Matching is *unverified* until you confirm it.
  * Linux distributions backport security fixes without changing the upstream version, so a banner such as
    ``OpenSSH_8.9p1 Ubuntu-3ubuntu0.6`` can be patched although 8.9p1 is listed as vulnerable. Such hits are
    flagged ``backport_risk``.
  * Services that hide their version cannot be mapped (they are listed, not guessed).
The vendor/product table below is best-effort; add or correct entries in AF_HOME/cpe_map.yaml (key: [vendor, product]).
"""
import json, re, time
from pathlib import Path

from af_util import af_home

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
CACHE_TTL = 24 * 3600

# product key -> (cpe vendor, cpe product)
CPE_MAP = {
    "openssh": ("openbsd", "openssh"), "dropbear": ("dropbear_ssh_project", "dropbear_ssh"),
    "apache": ("apache", "http_server"), "nginx": ("nginx", "nginx"), "iis": ("microsoft", "internet_information_services"),
    "lighttpd": ("lighttpd", "lighttpd"), "haproxy": ("haproxy", "haproxy"), "squid": ("squid-cache", "squid"),
    "caddy": ("caddyserver", "caddy"), "tomcat": ("apache", "tomcat"), "jetty": ("eclipse", "jetty"),
    "php": ("php", "php"), "openssl": ("openssl", "openssl"), "samba": ("samba", "samba"),
    "bind": ("isc", "bind"), "dnsmasq": ("thekelleys", "dnsmasq"), "unbound": ("nlnetlabs", "unbound"),
    "proftpd": ("proftpd", "proftpd"), "vsftpd": ("vsftpd_project", "vsftpd"), "pure-ftpd": ("pureftpd", "pure-ftpd"),
    "exim": ("exim", "exim"), "postfix": ("postfix", "postfix"), "sendmail": ("sendmail", "sendmail"),
    "dovecot": ("dovecot", "dovecot"), "mysql": ("oracle", "mysql"), "mariadb": ("mariadb", "mariadb"),
    "postgresql": ("postgresql", "postgresql"), "redis": ("redis", "redis"), "mongodb": ("mongodb", "mongodb"),
    "elasticsearch": ("elastic", "elasticsearch"), "memcached": ("memcached", "memcached"), "openvpn": ("openvpn", "openvpn"),
    "nodejs": ("nodejs", "node.js"), "grafana": ("grafana", "grafana"), "jenkins": ("jenkins", "jenkins"),
    "rabbitmq": ("vmware", "rabbitmq"), "docker": ("docker", "docker"), "ntp": ("ntp", "ntp"), "mosquitto": ("eclipse", "mosquitto"),
    "wordpress": ("wordpress", "wordpress"), "phpmyadmin": ("phpmyadmin", "phpmyadmin"), "gitlab": ("gitlab", "gitlab"),
}
BACKPORT_MARKERS = re.compile(r"ubuntu|debian|\.el\d|centos|rhel|red hat|fedora|suse|alpine|\+deb\d|deb\d+u\d", re.I)


def cpe_for(product_key):
    m = dict(CPE_MAP)
    try:
        import yaml
        m.update({k: tuple(v) for k, v in (yaml.safe_load((af_home() / "cpe_map.yaml").read_text()) or {}).items()})
    except Exception:
        pass
    return m.get(product_key)


# ---------------------------------------------------------------- version comparison
def version_tuple(v):
    if not v:
        return ()
    v = re.sub(r"p(\d+)", r".\1", str(v).strip())
    parts = []
    for p in re.split(r"[._\-~+]", v):
        m = re.match(r"(\d+)", p)
        parts.append(int(m.group(1)) if m else 0)
    return tuple(parts)


def in_range(installed, start_incl=None, end_incl=None, start_excl=None, end_excl=None):
    iv = version_tuple(installed)
    if not iv:
        return False
    if start_incl and iv < version_tuple(start_incl):
        return False
    if start_excl and iv <= version_tuple(start_excl):
        return False
    if end_incl and iv > version_tuple(end_incl):
        return False
    if end_excl and iv >= version_tuple(end_excl):
        return False
    return True


# ---------------------------------------------------------------- NVD client (cached, rate-limited, paginated)
class NVD:
    def __init__(self, api_key="", http=None, cache_path=None, sleep=time.sleep):
        self.key, self.http, self.sleep = api_key, http, sleep
        self.path = Path(cache_path or (af_home() / "nvd_cache.json"))
        self.cache = self._load()
        self.last = 0.0
        self.errors = []

    def _load(self):
        try:
            return json.loads(self.path.read_text())
        except (OSError, ValueError):
            return {}

    def _save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.cache))
        except OSError:
            pass

    def _wait(self):
        delay = 0.7 if self.key else 6.5                     # NVD: 50 requests / 30 s with a key, 5 / 30 s without
        d = delay - (time.time() - self.last)
        if d > 0:
            self.sleep(d)
        self.last = time.time()

    def cves(self, vendor, product, version, max_pages=5):
        k = f"{vendor}:{product}:{version}"
        e = self.cache.get(k)
        if e and time.time() - e["t"] < CACHE_TTL:
            return e["v"]
        import requests
        http = self.http or requests
        out, start = [], 0
        for _ in range(max_pages):
            self._wait()
            params = {"virtualMatchString": f"cpe:2.3:a:{vendor}:{product}:*:*:*:*:*:*:*:*", "versionStart": version,
                      "versionStartType": "including", "versionEnd": version, "versionEndType": "including",
                      "resultsPerPage": 2000, "startIndex": start}
            try:
                r = http.get(NVD_URL, params=params, headers={"apiKey": self.key} if self.key else {}, timeout=60)
            except Exception as ex:
                self.errors.append(f"{vendor}/{product} {version}: {type(ex).__name__}")
                return None                                   # None = lookup failed (do not cache, do not claim 'no CVEs')
            if r.status_code != 200:
                self.errors.append(f"{vendor}/{product} {version}: HTTP {r.status_code}")
                return None
            doc = r.json()
            out += [parse_nvd_item(i["cve"]) for i in doc.get("vulnerabilities", [])]
            start += doc.get("resultsPerPage", 0) or 0
            if start >= doc.get("totalResults", 0) or not doc.get("resultsPerPage"):
                break
        self.cache[k] = {"t": time.time(), "v": out}
        self._save()
        return out


def parse_nvd_item(c):
    m, score, sev = c.get("metrics", {}), 0.0, "UNKNOWN"
    for k in ("cvssMetricV31", "cvssMetricV40", "cvssMetricV30", "cvssMetricV2"):
        if m.get(k):
            d = m[k][0]["cvssData"]
            score, sev = d.get("baseScore", 0.0), (d.get("baseSeverity") or m[k][0].get("baseSeverity") or "UNKNOWN")
            break
    ranges = [{"start_incl": x.get("versionStartIncluding"), "start_excl": x.get("versionStartExcluding"),
               "end_incl": x.get("versionEndIncluding"), "end_excl": x.get("versionEndExcluding")}
              for cfg in c.get("configurations", []) for node in cfg.get("nodes", []) for x in node.get("cpeMatch", []) if x.get("vulnerable")]
    desc = next((d["value"] for d in c.get("descriptions", []) if d.get("lang") == "en"), "")
    return {"cve": c["id"], "score": score, "severity": sev.capitalize(), "summary": desc[:300], "ranges": ranges}


# ---------------------------------------------------------------- matching
def _risk(sev, score):
    s = (sev or "").lower()
    if s in ("critical", "high", "medium", "low"):
        return s.capitalize()
    return "Critical" if score >= 9 else "High" if score >= 7 else "Medium" if score >= 4 else "Low"


def match_devices(devices, nvd, kev=None, epss_fn=None, exposure_fn=None, progress=None, cancel=None, max_per_service=60):
    """Attach ``device['cves']`` for every service with a mappable product+version. Returns summary stats.
    ``nvd`` needs .cves(vendor, product, version) -> list | None. Services are de-duplicated across the network, so
    100 hosts running the same nginx cost one lookup."""
    kev = kev or set()
    services = {}
    for d in devices:
        for s in d.get("services", []):
            if s.get("product_key") and s.get("version") and cpe_for(s["product_key"]):
                services.setdefault((s["product_key"], s["version"]), []).append((d, s))
    stats = {"lookups": len(services), "failed": 0, "unmappable": 0, "cves": 0, "kev": 0}
    for d in devices:
        d["cves"] = []
        stats["unmappable"] += sum(1 for s in d.get("services", []) if s.get("state") == "open" and not (s.get("product_key") and s.get("version")))
    all_ids = set()
    for i, ((pk, ver), users) in enumerate(services.items()):
        if cancel and cancel():
            break
        if progress:
            progress(i, len(services), f"{pk} {ver}")
        vendor, prod = cpe_for(pk)
        found = nvd.cves(vendor, prod, ver)
        if found is None:
            stats["failed"] += 1
            for d, s in users:
                s["cve_lookup"] = "failed"
            continue
        hits = [c for c in found if not c["ranges"] or any(in_range(ver, **r) for r in c["ranges"])]
        hits.sort(key=lambda c: -c["score"])
        all_ids.update(c["cve"] for c in hits)
        for d, s in users:
            s["cve_lookup"] = "ok"
            backport = bool(BACKPORT_MARKERS.search(s.get("banner", "") + " " + " ".join(d.get("os_hints", []))))
            for c in hits[:max_per_service]:
                d["cves"].append({"cve": c["cve"], "score": c["score"], "severity": _risk(c["severity"], c["score"]), "summary": c["summary"],
                                  "port": s["port"], "proto": s.get("proto", "tcp"), "product": s.get("product") or pk, "version": ver,
                                  "confidence": "banner version match (unverified)", "backport_risk": backport, "kev": c["cve"] in kev})
    epss = {}
    if epss_fn and all_ids:
        try:
            epss = {k: (v[0] if isinstance(v, (tuple, list)) else v) for k, v in (epss_fn(sorted(all_ids)) or {}).items()}
        except Exception:
            epss = {}
    from af_vuln import priority_score, priority_label
    for d in devices:
        expo = exposure_fn(d) if exposure_fn else ("internet" if d.get("public") else "internal")
        for c in d["cves"]:
            c["epss"] = epss.get(c["cve"], 0.0)
            c["priority"] = priority_score(c["score"] or None, c["kev"], c["epss"], d.get("criticality", "medium"), expo)
            c["priority_label"] = priority_label(c["priority"])
        d["cves"].sort(key=lambda c: -c["priority"])
        stats["cves"] += len(d["cves"])
        stats["kev"] += sum(1 for c in d["cves"] if c["kev"])
    return stats
