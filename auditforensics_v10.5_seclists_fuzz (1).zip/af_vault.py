#!/usr/bin/env python3
"""AuditForensics vault - application-level encryption at rest (envelope encryption).

Format  enc:v2:<keyid>:<base64url(nonce || AES-256-GCM ciphertext)>
  * Data keys are random 256-bit keys kept in a keyring (AF_HOME/vault.keys), each wrapped with a
    key-encryption key (KEK). New data is encrypted with the *primary* data key; old key ids stay readable,
    so keys can be rotated without downtime (``rotate`` then ``reencrypt``).
  * Every value is bound to its context with AES-GCM associated data (table.column|row-key), so a ciphertext
    copied into another row or column fails authentication instead of decrypting.
  * Legacy ``enc:v1:`` Fernet values remain readable; ``reencrypt`` upgrades them in place.

KEK sources (AF_KEK_BACKEND, default auto):
  passphrase  AF_DB_KEY env var, scrypt-derived with a per-install salt (AF_HOME/vault.salt)
  keyring     OS keyring entry service "auditforensics" (needs the optional ``keyring`` package)
  keyfile     AF_HOME/vault.key (mode 600). Protects stolen DB files/backups, NOT an attacker running as the
              same OS user.
LOSE THE KEK = LOSE THE DATA: back it up separately from the database.
Controls: NIST SC-28/SC-12, ISO 27001 A.8.24/A.8.12, SOC 2 CC6.1/C1.1, HIPAA 164.312(a)(2)(iv).
CLI: python af_vault.py status | encrypt FILE | decrypt FILE [-o OUT] | rotate | reencrypt [--db PATH]
"""
import argparse, base64, datetime, getpass, hashlib, json, os, secrets, sqlite3, sys
from pathlib import Path

try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    HAS_CRYPTO = True
except ImportError:                     # degrade loudly via status(), never silently claim encryption
    HAS_CRYPTO = False

HOME = Path(os.environ.get("AF_HOME") or (Path.home() / ".auditforensics"))
PREFIX_V1 = "enc:v1:"
PREFIX_V2 = "enc:v2:"
PREFIX = PREFIX_V1                      # kept for older callers that import PREFIX
MAGIC = b"AFENC1"
_cache = {}

# table -> (encrypted columns, plaintext context column bound into the AAD)
ENC_SPEC = {
    "scans": (["results_json", "sigma_json", "correlations_json", "ai_summary"], "timestamp"),
    "agent_findings": (["details", "recommendation"], "agent_id"),
    "agent_inventory": (["data"], "agent_id"),
    "users": (["totp_secret"], "username"),
    "net_scans": (["devices_json"], "timestamp"),
    "net_assets": (["services_json"], "asset_key"),
}


def aad_for(table, column, ctx=""):
    return f"{table}.{column}|{ctx}"


def _scrypt(pw, salt):
    return hashlib.scrypt(pw, salt=salt, n=2 ** 15, r=8, p=1, dklen=32, maxmem=2 ** 26)


def _private_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def enabled():
    return HAS_CRYPTO and os.environ.get("AF_VAULT", "1") != "0"


def backend():
    b = os.environ.get("AF_KEK_BACKEND", "auto").lower()
    if b == "auto":
        return "passphrase" if os.environ.get("AF_DB_KEY") else "keyfile"
    return b


def mode():                             # legacy name used by the UI
    return "disabled" if not enabled() else backend()


# ---------------------------------------------------------------- KEK handling
def _kek():
    """32-byte key-encryption key from the configured backend."""
    b = backend()
    if b == "passphrase":
        pw = os.environ.get("AF_DB_KEY")
        if not pw:
            raise RuntimeError("AF_KEK_BACKEND=passphrase but AF_DB_KEY is not set")
        sp = HOME / "vault.salt"
        if not sp.exists():
            _private_write(sp, secrets.token_bytes(16))
        return _scrypt(pw.encode(), sp.read_bytes())
    if b == "keyring":
        import keyring                              # optional dependency
        v = keyring.get_password("auditforensics", "kek")
        if not v:
            v = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()
            keyring.set_password("auditforensics", "kek", v)
        return base64.urlsafe_b64decode(v)
    kp = HOME / "vault.key"
    if not kp.exists():
        _private_write(kp, Fernet.generate_key())
    return base64.urlsafe_b64decode(kp.read_bytes().strip())


def _wrap(kek, kid, key):
    n = secrets.token_bytes(12)
    return base64.b64encode(n + AESGCM(kek).encrypt(n, key, kid.encode())).decode()


def _unwrap(kek, kid, blob):
    raw = base64.b64decode(blob)
    return AESGCM(kek).decrypt(raw[:12], raw[12:], kid.encode())


def _keyring_path():
    return HOME / "vault.keys"


def _load_keyring():
    """-> (primary_kid, {kid: key_bytes}); creates k1 on first use. Cached per backend/home."""
    sig = (backend(), str(HOME), os.environ.get("AF_DB_KEY", ""))
    if _cache.get("sig") == sig:
        return _cache["ring"]
    kek, p = _kek(), _keyring_path()
    if p.exists():
        doc = json.loads(p.read_text())
    else:
        kid = "k1"
        doc = {"v": 2, "primary": kid,
               "keys": {kid: {"wrapped": _wrap(kek, kid, secrets.token_bytes(32)), "created": _now()}}}
        _private_write(p, json.dumps(doc, indent=1).encode())
    keys = {kid: _unwrap(kek, kid, v["wrapped"]) for kid, v in doc["keys"].items()}
    _cache.update(sig=sig, ring=(doc["primary"], keys))
    return _cache["ring"]


def rotate_key():
    """Add a new data key and make it primary. Existing data stays readable; run ``reencrypt`` to migrate it."""
    kek, p = _kek(), _keyring_path()
    _load_keyring()
    doc = json.loads(p.read_text())
    kid = f"k{len(doc['keys']) + 1}"
    doc["keys"][kid] = {"wrapped": _wrap(kek, kid, secrets.token_bytes(32)), "created": _now()}
    doc["primary"] = kid
    _private_write(p, json.dumps(doc, indent=1).encode())
    _cache.clear()
    return kid


def _legacy_fernet():
    return Fernet(base64.urlsafe_b64encode(_kek()))


def status():
    m = mode()
    try:
        primary, keys = _load_keyring() if enabled() else ("-", {})
    except Exception as e:
        primary, keys = f"error: {e}", {}
    loc = {"passphrase": "AF_DB_KEY env + vault.salt", "keyfile": str(HOME / "vault.key"),
           "keyring": "OS keyring (service 'auditforensics')", "disabled": "-"}.get(m, m)
    warn = ""
    if not HAS_CRYPTO:
        warn = "cryptography package missing: data is stored UNENCRYPTED (pip install cryptography)"
    elif m == "keyfile":
        warn = "KEK file lives beside the data - set AF_DB_KEY or AF_KEK_BACKEND=keyring for stronger protection"
    return {"mode": m, "available": HAS_CRYPTO, "key_location": loc, "primary_key": primary,
            "data_keys": len(keys), "keyring_file": str(_keyring_path()), "warning": warn}


# ---------------------------------------------------------------- text encryption
def encrypt_text(s, aad=""):
    if s is None or not enabled() or str(s).startswith((PREFIX_V1, PREFIX_V2)):
        return s
    kid, keys = _load_keyring()
    n = secrets.token_bytes(12)
    ct = AESGCM(keys[kid]).encrypt(n, str(s).encode(), aad.encode())
    return f"{PREFIX_V2}{kid}:" + base64.urlsafe_b64encode(n + ct).decode()


def needs_reencrypt(s):
    if not isinstance(s, str) or not s.startswith((PREFIX_V1, PREFIX_V2)):
        return bool(s) and enabled()                  # plaintext that should be encrypted
    if s.startswith(PREFIX_V1):
        return True
    return s[len(PREFIX_V2):].split(":", 1)[0] != _load_keyring()[0]


def decrypt_text(s, aad=""):
    if not isinstance(s, str) or not s.startswith((PREFIX_V1, PREFIX_V2)):
        return s
    if not HAS_CRYPTO:
        return "[encrypted: cryptography package missing]"
    try:
        if s.startswith(PREFIX_V1):
            return _legacy_fernet().decrypt(s[len(PREFIX_V1):].encode()).decode()
        kid, body = s[len(PREFIX_V2):].split(":", 1)
        raw = base64.urlsafe_b64decode(body.encode())
        return AESGCM(_load_keyring()[1][kid]).decrypt(raw[:12], raw[12:], aad.encode()).decode()
    except Exception:
        return "[encrypted: wrong key, or ciphertext was moved/tampered]"


def reencrypt_db(db_path, dry_run=False):
    """Upgrade legacy / old-key / plaintext values to the primary key. Returns {table: rows_changed}."""
    c = sqlite3.connect(str(db_path), timeout=30)
    out = {}
    try:
        for table, (cols, ctxcol) in ENC_SPEC.items():
            try:
                rows = c.execute(f"SELECT rowid, {ctxcol}, {', '.join(cols)} FROM {table}").fetchall()  # nosec B608 - identifiers come from internal constants, values are bound
            except sqlite3.Error:
                continue
            changed = 0
            for row in rows:
                upd = {}
                for i, col in enumerate(cols, start=2):
                    v = row[i]
                    if v and needs_reencrypt(v):
                        aad = aad_for(table, col, row[1])
                        is_v2 = isinstance(v, str) and v.startswith(PREFIX_V2)
                        pt = decrypt_text(v, aad if is_v2 else "")
                        if pt.startswith("[encrypted:"):
                            continue                  # unreadable: never overwrite with an error string
                        upd[col] = encrypt_text(pt, aad)
                if upd and not dry_run:
                    c.execute(f"UPDATE {table} SET {', '.join(f'{k}=?' for k in upd)} WHERE rowid=?",  # nosec B608
                              (*upd.values(), row[0]))
                changed += bool(upd)
            out[table] = changed
        if not dry_run:
            c.commit()
    finally:
        c.close()
    return out


# ---------------------------------------------------------------- passphrase blobs (exports)
def encrypt_blob(data, passphrase):
    """Passphrase-encrypt an export (compliance pack etc.). Raises if cryptography is missing."""
    if not HAS_CRYPTO:
        raise RuntimeError("cryptography package not installed")
    salt = secrets.token_bytes(16)
    f = Fernet(base64.urlsafe_b64encode(_scrypt(passphrase.encode(), salt)))
    return MAGIC + salt + f.encrypt(data)


def decrypt_blob(blob, passphrase):
    if not blob.startswith(MAGIC):
        raise ValueError("not an AuditForensics encrypted file")
    salt, tok = blob[len(MAGIC):len(MAGIC) + 16], blob[len(MAGIC) + 16:]
    try:
        return Fernet(base64.urlsafe_b64encode(_scrypt(passphrase.encode(), salt))).decrypt(tok)
    except InvalidToken:
        raise ValueError("wrong passphrase or file tampered with")


def main():
    p = argparse.ArgumentParser(description="AuditForensics vault")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    sub.add_parser("rotate")
    r = sub.add_parser("reencrypt")
    r.add_argument("--db", default=str(HOME / "history.db"))
    r.add_argument("--dry-run", action="store_true")
    for n in ("encrypt", "decrypt"):
        s = sub.add_parser(n); s.add_argument("file"); s.add_argument("-o", "--out")
    a = p.parse_args()
    if a.cmd == "status":
        for k, v in status().items():
            print(f"{k:13s} {v}")
        return
    if a.cmd == "rotate":
        print("new primary key:", rotate_key(), "- now run: python af_vault.py reencrypt")
        return
    if a.cmd == "reencrypt":
        for t, n in reencrypt_db(a.db, a.dry_run).items():
            print(f"{t:18s} {n} row(s) {'would change' if a.dry_run else 'upgraded'}")
        return
    pw = os.environ.get("AF_EXPORT_PASSPHRASE") or getpass.getpass("Passphrase: ")
    data = Path(a.file).read_bytes()
    if a.cmd == "encrypt":
        out = Path(a.out or a.file + ".afenc"); out.write_bytes(encrypt_blob(data, pw))
    else:
        out = Path(a.out or (a.file[:-6] if a.file.endswith(".afenc") else a.file + ".dec"))
        try:
            out.write_bytes(decrypt_blob(data, pw))
        except ValueError as e:
            sys.exit(f"error: {e}")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
