"""Shared helpers: UTC time handling and private file/dir creation.

All timestamps stored by AuditForensics are timezone-aware UTC ISO-8601 strings (``...+00:00``).
Legacy rows written by older releases are naive *local* time; ``parse_ts`` / ``to_utc_iso`` convert them.
"""
import datetime as _dt
import os
from pathlib import Path

UTC = _dt.timezone.utc


def utcnow():
    return _dt.datetime.now(UTC)


def utc_iso(timespec="seconds"):
    return utcnow().isoformat(timespec=timespec)


def utc_today():
    return utcnow().date()


def parse_ts(s):
    """Parse an ISO timestamp -> aware UTC datetime. Naive values are treated as legacy local time."""
    if isinstance(s, _dt.datetime):
        d = s
    else:
        d = _dt.datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    if d.tzinfo is None:
        d = d.astimezone()          # interpret as the machine's local zone (legacy rows), then convert
    return d.astimezone(UTC)


def to_utc_iso(s, timespec="seconds"):
    try:
        return parse_ts(s).isoformat(timespec=timespec)
    except Exception:
        return s


def has_tz(s):
    s = str(s or "")
    return s.endswith("Z") or "+" in s[10:] or "-" in s[11:]


def af_home():
    return Path(os.environ.get("AF_HOME") or (Path.home() / ".auditforensics"))


def private_dir(path, mode=0o700):
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(p, mode)
    except OSError:
        pass
    return p


def private_write(path, data, mode=0o600):
    """Create/overwrite a file that is never world-readable, not even briefly (no write-then-chmod race)."""
    p = Path(path)
    private_dir(p.parent)
    if isinstance(data, str):
        data = data.encode()
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    try:
        os.chmod(p, mode)
    except OSError:
        pass
    return p


def migrate_naive_to_utc(conn, table, columns):
    """One-time conversion of naive-local timestamp columns to UTC. Safe to re-run (aware values skipped)."""
    n = 0
    try:
        pk = "rowid"
        rows = conn.execute(f"SELECT {pk}, {', '.join(columns)} FROM {table}").fetchall()  # nosec B608 - identifiers come from internal constants, values are bound
    except Exception:
        return 0
    for row in rows:
        upd = {}
        for i, col in enumerate(columns, start=1):
            v = row[i]
            if v and not has_tz(v):
                nv = to_utc_iso(v)
                if nv != v:
                    upd[col] = nv
        if upd:
            sets = ", ".join(f"{c}=?" for c in upd)
            conn.execute(f"UPDATE {table} SET {sets} WHERE {pk}=?", (*upd.values(), row[0]))  # nosec B608 - identifiers come from internal constants, values are bound
            n += 1
    conn.commit()
    return n
