#!/usr/bin/env python3
"""Subdomain discovery for the Web Application scanner.

Two sources, both read-only against the public DNS / certificate-transparency system (never the target's own
servers until a discovered name is actually web-scanned):
  * certificate transparency (crt.sh) - passive, finds names that were never guessed
  * DNS brute force against a built-in + optional custom / SecLists word list

Resolution is a small stdlib DNS client (UDP, A/AAAA/CNAME) built on af_netmap's wire-format helpers, so no extra
dependency is needed. Every probe goes through af_scope.throttle(resolver) so a brute force cannot hammer a
resolver past the configured rate.

This module never decides whether scanning is authorised - the caller must already hold a recorded authorization
for the apex domain (and that authorization's text should say it covers discovered subdomains) before enumerating,
and must still check each discovered name against the scope deny list (af_scope.host_denied) before scanning it.

Third-party hosting: a subdomain whose CNAME points at a SaaS/cloud platform (GitHub Pages, Shopify, Azure
App Service, ...) is not part of the target's own infrastructure even though its name is. Such records are
classified so the caller can exclude them from active scanning by default. A CNAME to a takeover-prone provider
that does not resolve further (no A/AAAA) is flagged as a possible subdomain takeover regardless of that setting,
since reporting it is itself the useful action.

SecLists integration (optional): place a SecLists checkout (or just the Discovery/DNS wordlists) next to the tool
or under ~/.auditforensics/SecLists / /opt/SecLists.  Use load_seclist_subdomains(size) or pass an explicit
wordlist path / list of names.  Larger lists significantly increase probe count — always stay inside authorised
scope and rate limits.
"""
import os
import random, re, socket
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import af_scope
from af_netmap import dns_query, parse_dns

DEFAULT_RESOLVERS = ["1.1.1.1", "8.8.8.8"]
QTYPES = ((1, "a"), (28, "aaaa"))

# Candidate locations for a SecLists installation (first existing wins)
_SECLISTS_SEARCH = [
    Path(__file__).resolve().parent / "SecLists",                 # bundled next to the .py files
    Path(__file__).resolve().parent.parent / "SecLists",          # sibling of package dir
    Path.home() / ".auditforensics" / "SecLists",
    Path("/opt/SecLists"),
    Path("/usr/share/seclists"),
    Path("/usr/share/wordlists/SecLists"),
]

_SECLISTS_SUBDOMAIN_FILES = {
    "tiny":   "Discovery/DNS/subdomains-top1million-5000.txt",   # ~5k
    "small":  "Discovery/DNS/subdomains-top1million-5000.txt",
    "medium": "Discovery/DNS/subdomains-top1million-20000.txt",  # ~20k
    "large":  "Discovery/DNS/subdomains-top1million-20000.txt",  # alias; full 1M is too heavy for default use
}

COMMON_SUBDOMAINS = sorted(set("""
www www1 www2 ww1 ww2 web web1 web2 site m mobile wap touch
mail smtp smtp1 pop pop3 imap webmail mx mx1 mx2 email autodiscover autoconfig
ns1 ns2 ns3 ns4 dns dns1 dns2 ftp ftps sftp files file download downloads upload uploads
vpn remote rdp ssh telnet gateway gw proxy firewall router
api api1 api2 apiv1 apiv2 api-dev api-staging graphql rest rpc ws websocket socket
app apps portal dashboard admin administrator manage management console panel cpanel whm webdisk
dev develop development staging stage test testing qa uat preprod pre-prod sandbox demo beta alpha canary
git gitlab github bitbucket svn jenkins ci cd build artifactory nexus registry docker
jira confluence wiki kb knowledgebase helpdesk support help docs doc documentation status statuspage
blog news press forum community
shop store cart checkout payments pay billing invoice
cdn static assets img images media video photos
db database mysql postgres postgresql redis mongo mongodb elastic elasticsearch kibana grafana prometheus metrics
monitor monitoring nagios zabbix splunk
auth sso login signin logon accounts account identity idp oauth saml
intranet extranet internal partner partners client clients customer customers vendor
old new legacy backup bak archive migrate migration
host1 host2 host3 server server1 server2 node1 node2 cluster
secure security vault secrets hsm
uat1 uat2 app1 app2 web3 lb loadbalancer cache
""".split()))


def find_seclists_root():
    """Return the first existing SecLists root directory, or None."""
    for p in _SECLISTS_SEARCH:
        if p.is_dir() and (p / "Discovery").is_dir():
            return p
    return None


def load_wordlist_file(path, max_lines=None, strip_comments=True):
    """Load a plain-text wordlist (one entry per line). Returns a sorted unique list of lowercased tokens."""
    path = Path(path)
    if not path.is_file():
        return []
    out = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if max_lines is not None and i >= max_lines:
                    break
                w = line.strip().lower()
                if not w:
                    continue
                if strip_comments and (w.startswith("#") or w.startswith("//")):
                    continue
                # basic sanitise: subdomain labels only
                if re.fullmatch(r"[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?", w) or \
                   re.fullmatch(r"[a-z0-9]([a-z0-9\-\.]{0,250}[a-z0-9])?", w):
                    out.append(w)
    except OSError:
        return []
    return sorted(set(out))


def load_seclist_subdomains(size="small", extra_paths=None, max_lines=None):
    """Load a SecLists subdomain wordlist.

    size: 'tiny'/'small' (~5k), 'medium'/'large' (~20k). Falls back to COMMON_SUBDOMAINS if SecLists is absent.
    extra_paths: optional list of additional wordlist files to merge.
    max_lines: hard cap on lines read from each file (None = no cap beyond the chosen size file).
    """
    size = (size or "small").lower().strip()
    rel = _SECLISTS_SUBDOMAIN_FILES.get(size, _SECLISTS_SUBDOMAIN_FILES["small"])
    words = list(COMMON_SUBDOMAINS)
    root = find_seclists_root()
    if root:
        words.extend(load_wordlist_file(root / rel, max_lines=max_lines))
    for p in (extra_paths or []):
        words.extend(load_wordlist_file(p, max_lines=max_lines))
    return sorted(set(words))


# pattern -> (provider, takeover_prone). takeover_prone marks providers where an unclaimed name can typically be
# registered by anyone, making a dangling CNAME a real subdomain-takeover risk.
THIRD_PARTY_PATTERNS = [
    (r"\.github\.io$", "GitHub Pages", True), (r"\.githubusercontent\.com$", "GitHub", False),
    (r"\.herokuapp\.com$", "Heroku", True), (r"\.herokudns\.com$", "Heroku DNS", True),
    (r"\.azurewebsites\.net$", "Azure App Service", True), (r"\.azure-api\.net$", "Azure API Management", True),
    (r"\.trafficmanager\.net$", "Azure Traffic Manager", True), (r"\.cloudapp\.azure\.com$", "Azure VM", False),
    (r"\.blob\.core\.windows\.net$", "Azure Blob Storage", True), (r"\.azureedge\.net$", "Azure CDN", True),
    (r"\.s3[.-][a-z0-9\-]*\.amazonaws\.com$", "AWS S3", True), (r"\.s3-website[.\-][a-z0-9\-]*\.amazonaws\.com$", "AWS S3 Website", True),
    (r"\.cloudfront\.net$", "AWS CloudFront", False), (r"\.elasticbeanstalk\.com$", "AWS Elastic Beanstalk", True),
    (r"\.execute-api\.[a-z0-9\-]+\.amazonaws\.com$", "AWS API Gateway", False), (r"\.elb\.amazonaws\.com$", "AWS ELB", False),
    (r"\.myshopify\.com$", "Shopify", True), (r"\.wixsite\.com$", "Wix", True), (r"\.wixdns\.net$", "Wix DNS", True),
    (r"\.squarespace\.com$", "Squarespace", False), (r"\.wordpress\.com$", "WordPress.com", True),
    (r"\.pantheonsite\.io$", "Pantheon", True), (r"\.netlify\.app$", "Netlify", True), (r"\.vercel\.app$", "Vercel", True),
    (r"\.firebaseapp\.com$", "Firebase Hosting", True), (r"\.web\.app$", "Firebase Hosting", True),
    (r"\.appspot\.com$", "Google App Engine", False), (r"\.zendesk\.com$", "Zendesk", False),
    (r"\.statuspage\.io$", "Statuspage", False), (r"\.freshdesk\.com$", "Freshdesk", False),
    (r"\.intercom\.io$", "Intercom", False), (r"\.hubspot\.net$", "HubSpot", False), (r"\.force\.com$", "Salesforce", False),
    (r"\.bitbucket\.io$", "Bitbucket Pages", True), (r"\.gitlab\.io$", "GitLab Pages", True),
    (r"\.surveymonkey\.com$", "SurveyMonkey", False), (r"\.typeform\.com$", "Typeform", False),
    (r"\.zoho\.com$", "Zoho", False), (r"\.fastly\.net$", "Fastly CDN", False), (r"\.akamaiedge\.net$", "Akamai CDN", False),
    (r"\.cloudflare\.net$", "Cloudflare CDN", False), (r"\.ghost\.io$", "Ghost(Pro)", True), (r"\.readme\.io$", "ReadMe", True),
    (r"\.ngrok\.io$", "ngrok", True), (r"\.ngrok-free\.app$", "ngrok", True),
]


def classify_cname(cname):
    """-> (provider, takeover_prone) or (None, False) when the CNAME target matches no known third-party platform."""
    if not cname:
        return None, False
    low = cname.lower().rstrip(".")
    for pat, provider, prone in THIRD_PARTY_PATTERNS:
        if re.search(pat, low):
            return provider, prone
    return None, False


def _is_public(ip):
    import ipaddress
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


# ---------------------------------------------------------------- DNS resolution
def system_resolvers():
    try:
        with open("/etc/resolv.conf") as f:
            ns = re.findall(r"^\s*nameserver\s+([0-9A-Fa-f:.]+)", f.read(), re.M)
        return ns
    except OSError:
        return []


def _query_once(name, qtype, server, timeout, txid):
    try:
        s = socket.socket(socket.AF_INET6 if ":" in server else socket.AF_INET, socket.SOCK_DGRAM)
    except OSError:
        return None
    s.settimeout(timeout)
    try:
        s.sendto(dns_query(name, qtype, 1, txid), (server, 53))
        data, _ = s.recvfrom(4096)
        return parse_dns(data)
    except (socket.timeout, OSError, ValueError):
        return None
    finally:
        s.close()


def resolve(name, servers=None, timeout=1.5, retries=2):
    """-> {'a': [...], 'aaaa': [...], 'cname': str|None, 'nxdomain': bool, 'error': str|None}. Never raises.
    A CNAME chain's final A/AAAA records (when the resolver follows it) land in 'a'/'aaaa' alongside the
    first CNAME seen, which is what both classification and brute-force comparisons need."""
    servers = list(servers or system_resolvers() or DEFAULT_RESOLVERS)
    out = {"a": [], "aaaa": [], "cname": None, "nxdomain": False, "error": None}
    answered = False
    for qtype, _key in QTYPES:
        msg = None
        for server in servers:
            for _ in range(max(1, retries)):
                af_scope.throttle(server)
                txid = random.randint(1, 0xFFFE)
                m = _query_once(name, qtype, server, timeout, txid)
                if m and m.get("id") == txid:
                    msg = m
                    break
            if msg:
                break
        if msg is None:
            continue
        answered = True
        if msg["rcode"] == 3:
            out["nxdomain"] = True
        for aname, atype, ttl, text in msg["answers"]:
            if atype == 1:
                out["a"].append(text)
            elif atype == 28:
                out["aaaa"].append(text)
            elif atype == 5 and not out["cname"]:
                out["cname"] = text.rstrip(".")
    out["a"] = sorted(set(out["a"]))
    out["aaaa"] = sorted(set(out["aaaa"]))
    if not answered:
        out["error"] = "no response from any resolver"
    return out


def detect_wildcard(domain, servers=None, timeout=1.5):
    """A random label that (almost certainly) was never registered. If it resolves, the zone answers everything -
    brute-force hits matching this signature are noise, not real hosts."""
    probe = f"af-wc-{random.getrandbits(40):x}.{domain}"
    r = resolve(probe, servers, timeout)
    if r["a"] or r["aaaa"] or r["cname"]:
        return {"wildcard": True, "a": r["a"], "aaaa": r["aaaa"], "cname": r["cname"]}
    return {"wildcard": False, "a": [], "aaaa": [], "cname": None}


def _matches_wildcard(r, wc):
    return bool(wc["wildcard"]) and r["a"] == wc["a"] and r["aaaa"] == wc["aaaa"] and r["cname"] == wc["cname"] and (r["a"] or r["aaaa"] or r["cname"])


# ---------------------------------------------------------------- sources
def enumerate_bruteforce(domain, wordlist=None, servers=None, concurrency=40, timeout=1.5, cancel=None, progress=None,
                         seclist_size=None):
    """-> ({name: resolve()-result}, wildcard-info). Dead names and wildcard-matching noise are dropped.

    wordlist: explicit list of labels (preferred). If None and seclist_size is set, loads from SecLists.
    seclist_size: 'tiny'|'small'|'medium'|'large' — used only when wordlist is None.
    """
    if wordlist is None and seclist_size:
        words = load_seclist_subdomains(seclist_size)
    else:
        words = sorted(set((wordlist or []) + COMMON_SUBDOMAINS))
    wc = detect_wildcard(domain, servers, timeout)
    names = [f"{w}.{domain}" for w in words]
    out = {}

    def one(name):
        if cancel and cancel():
            return None
        return name, resolve(name, servers, timeout)
    with ThreadPoolExecutor(max_workers=max(1, concurrency)) as ex:
        for i, res in enumerate(ex.map(one, names)):
            if progress and i % 50 == 0:          # less chatty for large lists
                progress(i / max(len(names), 1))
            if not res:
                continue
            name, r = res
            if r["nxdomain"] or r["error"] or _matches_wildcard(r, wc):
                continue
            out[name] = r
    if progress:
        progress(1.0)
    return out, wc


def enumerate_crtsh(domain, http=None, timeout=20):
    """-> (set of names, error). crt.sh is frequently slow or rate-limited; a failure here is not fatal to the
    overall enumeration (brute force still runs), just reported."""
    import requests
    http = http or requests
    domain = domain.lower().strip(".")
    try:
        r = http.get("https://crt.sh/", params={"q": f"%.{domain}", "output": "json"}, timeout=timeout, headers={"User-Agent": "AuditForensics"})
    except Exception as e:
        return set(), f"{type(e).__name__}: {str(e)[:150]}"
    if r.status_code != 200:
        return set(), f"HTTP {r.status_code}"
    try:
        rows = r.json()
    except ValueError:
        return set(), "crt.sh returned non-JSON (likely rate-limited); try again later"
    names = set()
    for row in rows if isinstance(rows, list) else []:
        for n in str(row.get("name_value", "")).split("\n"):
            n = n.strip().lower().lstrip("*.")
            if not n or not re.fullmatch(r"[a-z0-9][a-z0-9.\-]*[a-z0-9]|[a-z0-9]", n):
                continue
            if n == domain or n.endswith("." + domain):
                names.add(n)
    return names, ""


# ---------------------------------------------------------------- classification + orchestration
def classify_record(r):
    provider, prone = classify_cname(r.get("cname"))
    dangling = bool(provider and prone and not r["a"] and not r["aaaa"])
    return {"third_party": bool(provider), "provider": provider or "", "takeover_prone": prone, "takeover_risk": dangling}


def enumerate_subdomains(domain, wordlist=None, use_crtsh=True, use_bruteforce=True, servers=None, http=None,
                         concurrency=40, timeout=1.5, cancel=None, progress=None, seclist_size=None):
    """-> {'domain', 'records': [...], 'wildcard', 'crtsh_error', 'crtsh_count', 'sources', 'wordlist_size'}.
    Each record: {name, a, aaaa, cname, third_party, provider, takeover_prone, takeover_risk, public}.

    seclist_size: when wordlist is None and this is set ('small'|'medium'|...), load SecLists labels.
    """
    domain = domain.lower().strip(".")
    prog = progress or (lambda f, m: None)
    found, wc, crt_err, crt_count = {}, {"wildcard": False, "a": [], "aaaa": [], "cname": None}, "", 0
    wl_size = 0
    if use_bruteforce:
        if wordlist is None and seclist_size:
            prog(0.02, f"loading SecLists subdomain wordlist ({seclist_size})")
            wordlist = load_seclist_subdomains(seclist_size)
        wl_size = len(wordlist) if wordlist else len(COMMON_SUBDOMAINS)
        prog(0.05, f"brute-forcing {wl_size} subdomain names")
        found, wc = enumerate_bruteforce(domain, wordlist, servers, concurrency, timeout, cancel,
                                         lambda f: prog(0.05 + 0.55 * f, "brute force"),
                                         seclist_size=None)  # already loaded
    if cancel and cancel():
        return {"domain": domain, "records": [], "wildcard": wc, "crtsh_error": "cancelled", "crtsh_count": 0,
                "sources": {}, "wordlist_size": wl_size}
    if use_crtsh:
        prog(0.62, "querying crt.sh (certificate transparency)")
        crt_names, crt_err = enumerate_crtsh(domain, http)
        crt_count = len(crt_names)
        rest = sorted(crt_names - set(found) - {domain})

        def one(n):
            if cancel and cancel():
                return None
            return n, resolve(n, servers, timeout)
        if rest:
            with ThreadPoolExecutor(max_workers=max(1, concurrency)) as ex:
                for i, res in enumerate(ex.map(one, rest)):
                    if progress and i % 10 == 0:
                        prog(0.62 + 0.33 * i / max(len(rest), 1), "resolving crt.sh names")
                    if not res:
                        continue
                    n, r = res
                    if r["nxdomain"] or r["error"] or _matches_wildcard(r, wc):
                        continue
                    found[n] = r
    records = []
    for name, r in sorted(found.items()):
        cls = classify_record(r)
        records.append({"name": name, "a": r["a"], "aaaa": r["aaaa"], "cname": r.get("cname"), **cls,
                        "public": any(_is_public(ip) for ip in r["a"] + r["aaaa"])})
    prog(1.0, f"{len(records)} subdomain(s) found")
    return {"domain": domain, "records": records, "wildcard": wc, "crtsh_error": crt_err, "crtsh_count": crt_count,
            "sources": {"crtsh": use_crtsh, "bruteforce": use_bruteforce},
            "wordlist_size": wl_size}
