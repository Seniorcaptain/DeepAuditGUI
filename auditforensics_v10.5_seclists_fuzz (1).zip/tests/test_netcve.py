import json
import pytest
import af_oui as O, af_netcve as N


@pytest.fixture(autouse=True)
def fresh(afhome):
    O.reload(); yield; O.reload()


def test_oui_builtin_randomized_and_ieee_csv(afhome):
    assert O.lookup("00:0c:29:aa:bb:cc") == "VMware" and O.is_virtual("08-00-27-11-22-33")
    assert O.lookup("B8:27:EB:00:00:01") == "Raspberry Pi Foundation"
    assert O.is_randomized("da:a1:19:00:00:01") and not O.is_randomized("00:0c:29:00:00:01")
    assert O.describe("da:a1:19:00:00:01")[1].startswith("randomised")
    assert O.lookup("") == "" and O.lookup("zz") == ""
    (afhome / "oui.csv").write_text('Registry,Assignment,Organization Name,Organization Address\nMA-L,3C5AB4,"Google, Inc.",CA\nMA-L,001A2B,Ayecom,TW\n')
    O.reload()
    assert O.lookup("3c:5a:b4:01:02:03") == "Google, Inc." and O.lookup("00:1A:2B:00:00:00") == "Ayecom"
    (afhome / "nmap-mac-prefixes").write_text("# c\n0050C2 IEEE Registration Authority\n")
    O.reload(); assert O.lookup("00:50:c2:00:00:01") == "IEEE Registration Authority"


def test_oui_refresh_uses_cache_and_validates(afhome):
    class R:
        def __init__(s, t, c=200): s.text, s.status_code = t, c
    calls = []
    http = type("H", (), {"get": lambda s, u, **k: (calls.append(u), R("Registry,Assignment,Organization Name\nMA-L,AABBCC,Acme\n"))[1]})()
    assert O.refresh(http).exists() and O.lookup("aa:bb:cc:00:00:01") == "Acme"
    O.refresh(http); assert len(calls) == 1                                       # cached
    bad = type("H", (), {"get": lambda s, u, **k: R("<html>nope</html>")})()
    assert O.refresh(bad, force=True) is None


def test_version_logic():
    assert N.version_tuple("8.9p1") == (8, 9, 1) and N.version_tuple("1.18.0") < N.version_tuple("1.20")
    assert N.in_range("2.4.49", "2.4.0", None, None, "2.4.52") and not N.in_range("2.4.52", end_excl="2.4.52")
    assert N.in_range("8.0", end_incl="8.0") and not N.in_range("", end_incl="1")


NVD_DOC = {"resultsPerPage": 2, "totalResults": 2, "vulnerabilities": [
    {"cve": {"id": "CVE-2021-41773", "descriptions": [{"lang": "en", "value": "Path traversal in Apache 2.4.49"}],
             "metrics": {"cvssMetricV31": [{"cvssData": {"baseScore": 7.5, "baseSeverity": "HIGH"}}]},
             "configurations": [{"nodes": [{"cpeMatch": [{"vulnerable": True, "versionStartIncluding": "2.4.49", "versionEndIncluding": "2.4.49"}]}]}]}},
    {"cve": {"id": "CVE-2099-0001", "descriptions": [{"lang": "en", "value": "other range"}],
             "metrics": {"cvssMetricV31": [{"cvssData": {"baseScore": 9.8, "baseSeverity": "CRITICAL"}}]},
             "configurations": [{"nodes": [{"cpeMatch": [{"vulnerable": True, "versionEndExcluding": "2.4.40"}]}]}]}}]}


class FakeHttp:
    def __init__(s, doc=NVD_DOC, code=200): s.calls, s.doc, s.code = [], doc, code
    def get(s, url, params=None, headers=None, timeout=0):
        s.calls.append((params, headers))
        return type("R", (), {"status_code": s.code, "json": lambda self: s.doc})()


def dev(ip, product_key, version, banner="", port=80, **kw):
    return {"ip": ip, "services": [{"port": port, "proto": "tcp", "state": "open", "product_key": product_key, "product": product_key,
                                    "version": version, "banner": banner}], "os_hints": [], **kw}


def test_match_filters_by_range_dedups_and_prioritises(afhome):
    http = FakeHttp()
    nvd = N.NVD("KEY", http, afhome / "nvd.json", sleep=lambda s: None)
    devs = [dev("10.0.0.1", "apache", "2.4.49", "Apache/2.4.49 (Ubuntu)"), dev("10.0.0.2", "apache", "2.4.49", "Apache/2.4.49", public=True)]
    st = N.match_devices(devs, nvd, kev={"CVE-2021-41773"}, epss_fn=lambda ids: {i: (0.97, 0.99) for i in ids})
    assert len(http.calls) == 1 and st["lookups"] == 1 and st["cves"] == 2                    # one lookup serves both hosts
    assert http.calls[0][1] == {"apiKey": "KEY"} and http.calls[0][0]["virtualMatchString"].startswith("cpe:2.3:a:apache:http_server")
    a, b = devs
    assert [c["cve"] for c in a["cves"]] == ["CVE-2021-41773"]                                # CVE-2099-0001 (< 2.4.40) excluded by range
    assert a["cves"][0]["backport_risk"] is True and b["cves"][0]["backport_risk"] is False   # Ubuntu banner flagged
    assert a["cves"][0]["kev"] and a["cves"][0]["epss"] == 0.97 and a["cves"][0]["confidence"].endswith("(unverified)")
    assert b["cves"][0]["priority"] > a["cves"][0]["priority"]                                # internet-facing ranks higher
    assert st["kev"] == 2


def test_failed_lookup_is_reported_not_treated_as_clean(afhome):
    nvd = N.NVD("", FakeHttp(code=503), afhome / "n.json", sleep=lambda s: None)
    d = dev("10.0.0.1", "nginx", "1.18.0")
    st = N.match_devices([d], nvd)
    assert st["failed"] == 1 and d["services"][0]["cve_lookup"] == "failed" and d["cves"] == [] and nvd.errors and not nvd.cache
    class Boom:
        def get(s, *a, **k): raise ConnectionError("offline")
    nvd2 = N.NVD("", Boom(), afhome / "n2.json", sleep=lambda s: None)
    assert N.match_devices([dev("1.1.1.1", "nginx", "1.18.0")], nvd2)["failed"] == 1


def test_unmappable_services_counted_and_cache_used(afhome):
    http = FakeHttp({"resultsPerPage": 0, "totalResults": 0, "vulnerabilities": []})
    nvd = N.NVD("", http, afhome / "n.json", sleep=lambda s: None)
    d = {"ip": "1.1.1.1", "services": [{"port": 22, "state": "open", "product_key": "openssh", "version": ""},
                                       {"port": 9999, "state": "open", "product_key": "", "version": ""}], "os_hints": []}
    st = N.match_devices([d], nvd)
    assert st["unmappable"] == 2 and st["lookups"] == 0 and not http.calls
    d2 = dev("1.1.1.2", "nginx", "1.18.0"); N.match_devices([d2], nvd); N.match_devices([dev("1.1.1.3", "nginx", "1.18.0")], nvd)
    assert len(http.calls) == 1                                                                 # second run served from cache


def test_rate_limit_waits_between_requests(afhome):
    waits = []
    nvd = N.NVD("", FakeHttp({"resultsPerPage": 0, "totalResults": 0}), afhome / "n.json", sleep=waits.append)
    nvd.cves("a", "b", "1"); nvd.cves("a", "b", "2")
    assert waits and 6.0 < waits[0] <= 6.5                                                      # keyless NVD limit respected


def test_pagination(afhome):
    pages = [{"resultsPerPage": 1, "totalResults": 2, "vulnerabilities": [NVD_DOC["vulnerabilities"][0]]},
             {"resultsPerPage": 1, "totalResults": 2, "vulnerabilities": [NVD_DOC["vulnerabilities"][1]]}]
    class H:
        def __init__(s): s.i = 0; s.starts = []
        def get(s, url, params=None, **k):
            s.starts.append(params["startIndex"]); d = pages[s.i]; s.i += 1
            return type("R", (), {"status_code": 200, "json": lambda self: d})()
    h = H(); nvd = N.NVD("K", h, afhome / "n.json", sleep=lambda s: None)
    assert len(nvd.cves("apache", "http_server", "2.4.49")) == 2 and h.starts == [0, 1]


def test_user_cpe_map_override(afhome):
    (afhome / "cpe_map.yaml").write_text("myapp: [acme, myapp]\nnginx: [f5, nginx_custom]\n")
    assert N.cpe_for("myapp") == ("acme", "myapp") and N.cpe_for("nginx") == ("f5", "nginx_custom") and N.cpe_for("openssh") == ("openbsd", "openssh")


def test_oui_wireshark_manuf_prefers_long_name(afhome):
    (afhome / "manuf").write_text("# x\n00:00:0C\tCisco\tCisco Systems, Inc\n3C:5A:B4\tGoogle\n")
    O.reload()
    assert O.lookup("00:00:0c:aa:bb:cc") == "Cisco Systems, Inc" and O.lookup("3c:5a:b4:00:00:01") == "Google"
