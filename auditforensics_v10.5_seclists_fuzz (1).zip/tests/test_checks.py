import json, os, stat, zipfile
import pytest
import af_checks as C


def ctx(system="Linux", cmds=None, files=None, tools=None, root=True):
    cmds = cmds or {}
    def runner(cmd, timeout=30):
        key = " ".join(cmd)
        for k, v in cmds.items():
            if key == k or key.startswith(k):
                return v if isinstance(v, tuple) else (v, 0)
        return "", -1
    return C.Ctx(system=system, runner=runner, files=files or {}, tools=set(tools or []), is_root=root, psutil_mod=None)


# ------------------------------------------------------------------ firewall (the original bugs)
def test_ufw_inactive_is_not_active():
    assert C.parse_ufw("Status: inactive") == "inactive"        # "active" in "inactive" was the original bug
    assert C.parse_ufw("Status: active\n\nTo  Action") == "active"
    assert C.parse_ufw("ERROR: You need to be root") is None


def test_ufw_inactive_is_flagged():
    f = C.check_firewall(ctx(cmds={"ufw status": "Status: inactive"}, tools=["ufw"]))
    assert f and f[0]["status"] == "FAIL" and f[0]["check_name"] == "Firewall Disabled"


def test_empty_iptables_accept_all_is_flagged():
    empty = "-P INPUT ACCEPT\n-P FORWARD ACCEPT\n-P OUTPUT ACCEPT"      # contains no 'Chain' trick any more
    assert not C.iptables_protective(empty)
    f = C.check_firewall(ctx(cmds={"iptables -S": empty}, tools=["iptables"]))
    assert f[0]["status"] == "FAIL"


def test_iptables_default_drop_and_rule_drop_ok():
    assert C.iptables_protective("-P INPUT DROP\n-A INPUT -p tcp --dport 22 -j ACCEPT")
    assert C.iptables_protective("-P INPUT ACCEPT\n-A INPUT -s 1.2.3.4/32 -j DROP")
    assert not C.iptables_protective("-P INPUT ACCEPT\n-A OUTPUT -d 1.1.1.1 -j DROP")   # OUTPUT rule is not inbound protection


def test_nft_and_firewalld_and_active_ufw_pass():
    nft = "table inet filter {\n chain input {\n  type filter hook input priority 0; policy drop;\n }\n}"
    assert C.nft_protective(nft)
    assert not C.nft_protective("table inet filter {\n chain input {\n  type filter hook input priority 0; policy accept;\n }\n}")
    assert C.check_firewall(ctx(cmds={"nft list ruleset": nft}, tools=["nft"]))[0]["status"] == "PASS"
    assert C.check_firewall(ctx(cmds={"firewall-cmd --state": "running"}, tools=["firewall-cmd"]))[0]["status"] == "PASS"
    assert C.check_firewall(ctx(cmds={"ufw status": "Status: active"}, tools=["ufw"]))[0]["status"] == "PASS"


def test_firewall_unqueryable_is_skip_not_pass_or_fail():
    c = C.Collector().run("firewall", C.check_firewall, ctx(cmds={"ufw status": ("ERROR: You need to be root", 1)}, tools=["ufw", "iptables"]))
    assert c.stats["skipped"] == 1
    assert c.findings[0]["status"] == "SKIPPED" and "root" in c.findings[0]["details"]


# ------------------------------------------------------------------ coverage / errors
def test_exception_becomes_error_finding_not_pass():
    def boom(_): raise ValueError("kaboom")
    c = C.Collector().run("x", boom, None).run("y", lambda _: [C.F("A", "ok", "PASS", "Info", "fine")], None)
    assert c.stats == {"run": 2, "errors": 1, "skipped": 0, "not_applicable": 0}
    assert c.findings[0]["status"] == "ERROR" and "kaboom" in c.findings[0]["details"]
    assert "1 errored" in c.summary()


def test_not_applicable_counts_only():
    c = C.Collector().run("sip", C.check_macos_hardening, ctx(system="Linux"))
    assert c.findings == [] and c.stats["not_applicable"] == 1


# ------------------------------------------------------------------ ports
SS = """LISTEN 0 128 0.0.0.0:22 0.0.0.0:*
LISTEN 0 244 127.0.0.1:5432 0.0.0.0:*
LISTEN 0 4096 [::]:3306 [::]:*
LISTEN 0 4096 127.0.0.53%lo:53 0.0.0.0:*
LISTEN 0 100 *:6379 *:*"""


def test_parse_listeners_and_bind_awareness():
    got = C.parse_listeners(SS)
    assert ("0.0.0.0", 22) in got and ("127.0.0.1", 5432) in got and ("::", 3306) in got and ("127.0.0.53", 53) in got
    f = C.check_ports(ctx(cmds={"ss -H -ltn": SS}, tools=["ss"]))
    names = {x["check_name"] for x in f}
    assert names == {"Risky Port 3306 (MySQL)", "Risky Port 6379 (Redis)"}      # postgres on 127.0.0.1 is NOT flagged


def test_parse_lsof_and_netstat():
    assert C.parse_listeners("sshd 1 root 3u IPv4 0x1 0t0 TCP *:22 (LISTEN)\npostgres 2 u 5u IPv6 0 0t0 TCP [::1]:5432 (LISTEN)") == [("*", 22), ("::1", 5432)]
    assert C.parse_listeners("tcp 0 0 0.0.0.0:445 0.0.0.0:* LISTEN") == [("0.0.0.0", 445)]


# ------------------------------------------------------------------ ssh
def test_ssh_include_and_first_wins_and_match_block():
    files = {"/etc/ssh/sshd_config": "Include /etc/ssh/sshd_config.d/*.conf\nPermitRootLogin no\n",
             "/etc/ssh/sshd_config.d/50-cloud.conf": "PermitRootLogin yes\nPasswordAuthentication no\n"}
    f = C.check_ssh(ctx(files=files))
    assert [x["check_name"] for x in f] == ["SSH Root Login"]        # included file comes first: its 'yes' wins, as in OpenSSH
    cfg = C.effective_sshd(["PasswordAuthentication no", "Match User bob", "PasswordAuthentication yes"])
    assert cfg["passwordauthentication"] == "no"
    assert C.effective_sshd([])["permitrootlogin"] == "prohibit-password"        # real default, not 'unset'


def test_ssh_uses_sshd_T_when_available():
    f = C.check_ssh(ctx(cmds={"sshd -T": "permitrootlogin yes\npasswordauthentication no\n"}, tools=["sshd"]))
    assert len(f) == 1 and "sshd -T" in f[0]["details"]


def test_ssh_no_sshd_not_applicable():
    c = C.Collector().run("ssh", C.check_ssh, ctx())
    assert c.stats["not_applicable"] == 1


# ------------------------------------------------------------------ users
def test_users_checks():
    files = {"/etc/passwd": "root:x:0:0::/root:/bin/bash\ntoor:x:0:0::/:/bin/sh\nbob:x:1000:1000::/home/bob:/bin/bash",
             "/etc/shadow": "root:$6$x:1:::::\nbob::1:::::", "/etc/sudoers": "# bob ALL=(ALL) NOPASSWD: ALL\nalice ALL=(ALL) NOPASSWD: ALL"}
    names = {x["check_name"] for x in C.check_users(ctx(files=files))}
    assert names == {"UID 0 Accounts", "Empty Password Accounts", "Sudo NOPASSWD"}
    assert C.sudo_nopasswd("# bob NOPASSWD") == []


# ------------------------------------------------------------------ updates
def test_apt_security_distinction():
    out = "Listing...\nopenssl/jammy-security 3.0.2 amd64 [upgradable from: 3.0.1]\nvim/jammy-updates 2 amd64 [upgradable from: 1]"
    assert C.parse_apt_upgradable(out) == (2, 1)
    f = C.check_updates(ctx(cmds={"apt list --upgradable": out}, tools=["apt"]))
    assert f[0]["risk"] == "High" and f[0]["check_name"] == "Pending Security Updates"
    f = C.check_updates(ctx(cmds={"apt list --upgradable": "Listing...\nvim/jammy-updates 2 amd64 [upgradable from: 1]"}, tools=["apt"]))
    assert f[0]["risk"] == "Low"                                    # no longer always High


# ------------------------------------------------------------------ network classification
def test_is_public_ip():
    assert C.is_public_ip("8.8.8.8") and C.is_public_ip("2606:4700:4700::1111")
    for ip in ("10.1.2.3", "192.168.0.1", "172.16.0.1", "172.31.255.255", "127.0.0.1", "169.254.1.1", "::1", "fe80::1", "100.64.0.1", "fd00::1"):
        assert not C.is_public_ip(ip), ip
    assert C.is_public_ip("172.32.0.1")                            # outside 172.16/12: the old startswith('172.') bug treated this as private


def test_external_connections_ss_fallback():
    out = "0 0 10.0.0.5:44321 8.8.8.8:443\n0 0 10.0.0.5:44322 10.0.0.9:22\n0 0 10.0.0.5:44323 172.32.1.1:80"
    f = C.check_external_connections(ctx(cmds={"ss -H -tn state established": out}, tools=["ss"]))
    assert [x["details"] for x in f] == ["172.32.1.1:80", "8.8.8.8:443"] and all(x["risk"] == "Low" for x in f)


# ------------------------------------------------------------------ processes & files
def test_suspicious_exe_rules():
    assert C.suspicious_exe("/tmp/x/payload", "Linux") and C.suspicious_exe("/dev/shm/a", "Linux")
    assert C.suspicious_exe("/usr/bin/x (deleted)", "Linux")
    assert not C.suspicious_exe("/usr/bin/ssh", "Linux")
    assert not C.suspicious_exe(r"C:\Users\bob\AppData\Local\Microsoft\Teams\Teams.exe", "Windows")   # normal user-installed app
    assert C.suspicious_exe(r"C:\Users\bob\AppData\Local\Temp\a.exe", "Windows")


def test_file_scan_flags_executables_with_hash_and_ioc(tmp_path):
    d = tmp_path / "tmp"; d.mkdir()
    (d / "notes.txt").write_text("hello"); (d / "app.js").write_text("console.log(1)")       # .js is not suspicious on Linux
    elf = d / "dropper"; elf.write_bytes(b"\x7fELF" + b"\0" * 50)
    sh = d / "run.sh"; sh.write_text("#!/bin/sh\necho hi"); sh.chmod(0o755)
    plain_sh = d / "plain.sh"; plain_sh.write_text("#!/bin/sh\necho hi"); plain_sh.chmod(0o644)
    (d / "link").symlink_to(elf)
    c = C.Ctx(system="Linux", psutil_mod=None)
    f = C.check_files(c, [str(d)])
    assert {os.path.basename(x["details"].split(" (")[0]) for x in f} == {"dropper", "run.sh"}
    assert all(x["sha256"] and len(x["sha256"]) == 64 for x in f)
    ioc = {C.sha256_file(str(elf))}
    f = C.check_files(c, [str(d)], ioc)
    assert any(x["check_name"] == "Known-Bad File (IOC)" and x["risk"] == "Critical" for x in f)


def test_file_scan_ignores_relative_paths(tmp_path):
    assert list(C.iter_files(["relative/path"])) == []


def test_ioc_sweep_hash_match(tmp_path):
    f = tmp_path / "evil.bin"; f.write_bytes(b"malware")
    h = C.sha256_file(str(f))
    out = C.ioc_sweep(C.Ctx(system="Linux", psutil_mod=None), [str(tmp_path)], [h])
    assert any(x["check_name"] == "IOC Hash Match" for x in out) and out[-1]["check_name"] == "Sweep Coverage"


# ------------------------------------------------------------------ check ids
def test_check_ids_stable_across_dynamic_parts():
    a = C.make_check_id("Network", "Risky Port 21 (FTP)"); b = C.make_check_id("Network", "Risky Port 3389 (RDP)")
    assert a == b == "AF-NETW-risky-port"
    assert C.make_check_id("SSH", "SSH Root Login") == "AF-SSH-ssh-root-login"


# ------------------------------------------------------------------ scap
XCCDF = """<?xml version="1.0"?><Benchmark xmlns="http://checklists.nist.gov/xccdf/1.2"><TestResult>
<rule-result idref="xccdf_org.ssgproject.content_rule_sshd_disable_root_login" severity="high"><result>fail</result><ident system="CCE">CCE-1</ident></rule-result>
<rule-result idref="xccdf_org.ssgproject.content_rule_a" severity="low"><result>pass</result></rule-result>
<rule-result idref="xccdf_org.ssgproject.content_rule_b" severity="low"><result>notapplicable</result></rule-result>
<rule-result idref="xccdf_org.ssgproject.content_rule_c" severity="medium"><result>error</result></rule-result>
</TestResult></Benchmark>"""


def test_parse_xccdf():
    f = C.parse_xccdf_results(XCCDF)
    by = {x["check_name"]: x for x in f}
    assert by["SCAP: sshd_disable_root_login"]["status"] == "FAIL" and by["SCAP: sshd_disable_root_login"]["risk"] == "High"
    assert by["SCAP: c"]["status"] == "ERROR"
    assert "SCAP: a" not in by and "fail=1" in by["SCAP Summary"]["details"] and "pass=1" in by["SCAP Summary"]["details"]


def test_scap_skips_cleanly_without_oscap():
    c = C.Collector().run("scap", C.check_scap, ctx(), "profile")
    assert c.stats["skipped"] == 1


# ------------------------------------------------------------------ triage / live response
def test_triage_manifest_and_hashes(tmp_path):
    c = C.Ctx(system="Linux", psutil_mod=None)
    zp, man = C.build_triage(c, tmp_path / "out", "host/1", "10.5.0")
    assert zp.exists() and (zp.stat().st_mode & 0o777) == 0o600
    assert man["archive_sha256"] == C.sha256_file(str(zp))
    with zipfile.ZipFile(zp) as z:
        m = json.loads(z.read("MANIFEST.json"))
        assert m["host"] == "host/1" and m["collected_utc"].endswith("+00:00")
        for e in m["entries"]:
            import hashlib
            assert hashlib.sha256(z.read(e["name"])).hexdigest() == e["sha256"]


def test_quarantine_moves_hashes_and_refuses_symlink(tmp_path):
    f = tmp_path / "bad.bin"; f.write_bytes(b"xyz")
    meta = C.quarantine_file(str(f), tmp_path / "q")
    assert not f.exists() and meta["sha256"] == C.hashlib.sha256(b"xyz").hexdigest()
    assert (tmp_path / "q" / f"{meta['sha256']}.json").exists()
    t = tmp_path / "t"; t.write_text("x"); l = tmp_path / "l"; l.symlink_to(t)
    with pytest.raises(ValueError): C.quarantine_file(str(l), tmp_path / "q")
    with pytest.raises(ValueError): C.quarantine_file("relative", tmp_path / "q")


def test_kill_process_guards():
    class P:
        def __init__(s, pid): s.pid = pid; s.killed = False
        def name(s): return "evil"
        def exe(s): return "/tmp/evil"
        def terminate(s): s.killed = True
        def wait(s, t): pass
    class PS:
        def Process(self, pid): return P(pid)
    assert C.kill_process(PS(), 4242, "evil")["name"] == "evil"
    with pytest.raises(ValueError): C.kill_process(PS(), 4242, "something-else")       # PID reuse guard
    with pytest.raises(ValueError): C.kill_process(PS(), 1)
    with pytest.raises(ValueError): C.kill_process(PS(), 77, protected_pids=(77,))


def test_isolation_plan_always_allows_manager_and_refuses_blind_isolation():
    plan = C.isolation_plan("Linux", ["10.0.0.5"])
    flat = [" ".join(c) for c in plan]
    assert any("-d 10.0.0.5 -j ACCEPT" in c for c in flat) and any("-s 10.0.0.5 -j ACCEPT" in c for c in flat)
    assert flat.index("iptables -A AF_ISOLATE -j DROP") < flat.index("iptables -I INPUT 1 -j AF_ISOLATE")   # allow rules exist before drop is activated
    with pytest.raises(ValueError): C.isolation_plan("Linux", [])
    with pytest.raises(ValueError): C.isolation_plan("Darwin", ["1.1.1.1"])
    assert C.release_plan("Linux")[-1] == ["iptables", "-X", "AF_ISOLATE"]
    w = C.isolation_plan("Windows", ["10.0.0.5"])
    assert w[-1][-1] == "blockinbound,blockoutbound" and "remoteip=10.0.0.5" in w[0]


def test_run_commands_never_use_shell():
    c = ctx()
    with pytest.raises(AssertionError): c.run("ls; rm -rf /")


def test_inventory_records_dpkg_source_package_for_osv():
    out = "libssl3\t3.0.9-1\topenssl (3.0.9-1)\nbash\t5.2-1\t\ncurl\t7.88\tcurl\n"
    c = ctx(files={"/etc/os-release": 'ID=debian\nVERSION_ID="12"\n'}, cmds={"dpkg-query": out}, tools=["dpkg-query"])
    inv = C.collect_inventory(c)
    by = {p["name"]: p for p in inv["packages"]}
    assert by["libssl3"]["source"] == "openssl" and "source" not in by["bash"] and "source" not in by["curl"]
    assert inv["os_release"]["VERSION_ID"] == "12"


def test_xccdf_with_entities_is_refused():
    with pytest.raises(ValueError, match="DOCTYPE"):
        C.parse_xccdf_results('<?xml version="1.0"?><!DOCTYPE b [<!ENTITY a "b">]><Benchmark/>')
