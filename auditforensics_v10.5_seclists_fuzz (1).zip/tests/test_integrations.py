import json, sys
import pytest


@pytest.fixture()
def I(afhome, tmp_path, monkeypatch):
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    sys.modules.pop("af_integrations", None)
    import af_integrations
    return af_integrations


F1 = {"Host": "web01", "Category": "SSH", "Check": "SSH Root Login", "Status": "FAIL", "Risk": "High", "Details": "PermitRootLogin yes", "MITRE": "T1110"}
F2 = {"category": "Network", "check_name": "Risky Port 21 (FTP)", "status": "WARNING", "risk": "Critical", "details": "FTP open", "check_id": "AF-NETW-risky-port"}
LOW = {"Host": "x", "Check": "meh", "Status": "FAIL", "Risk": "Low", "Details": "d"}
PASS = {"Host": "x", "Check": "ok", "Status": "PASS", "Risk": "Critical", "Details": "d"}


class Resp:
    def __init__(s, code=200, js=None): s.status_code, s._js = code, js or {}
    def json(s): return s._js


class Http:
    def __init__(s, code=200, js=None): s.calls, s.code, s.js = [], code, js
    def post(s, url, **kw): s.calls.append((url, kw)); return Resp(s.code, s.js)


def test_cef_escaping_and_severity(I):
    n = I.norm({**F1, "Details": "a=b|c\nnewline", "Check": "pipe|name"})
    c = I.to_cef(n)
    assert c.startswith("CEF:0|AuditForensics|") and "pipe\\|name" in c and "a\\=b|c newline" in c and "|8|" in c


def test_ocsf_shape(I):
    o = I.to_ocsf(I.norm(F2, "db1"))
    assert o["class_uid"] == 2004 and o["severity_id"] == 5 and o["device"]["hostname"] == "db1" and o["finding_info"]["uid"] == "AF-NETW-risky-port"


def test_only_failing_high_findings_alert_and_cooldown(I, monkeypatch):
    h = Http()
    cfg = {"webhook": {"url": "https://hooks.example.com/x", "kind": "slack"}}
    monkeypatch.setattr(I, "_check_url", lambda u: u)
    r = I.notify_findings([F1, F2, LOW, PASS], "scan", config=cfg, http=h)
    assert r["webhook"].startswith("ok") and len(h.calls) == 1
    text = h.calls[0][1]["json"]["text"]; assert "2 new" in text and "meh" not in text and "ok" not in text.split("\n")[1:][0]
    r = I.notify_findings([F1, F2], "scan", config=cfg, http=h)
    assert "suppressed" in r["webhook"] and len(h.calls) == 1                        # same findings: no repeat page
    r = I.notify_findings([F1, {**F1, "Host": "web02"}], "scan", config=cfg, http=h)
    assert "ok" in r["webhook"] and "web02" in h.calls[1][1]["json"]["text"] and "web01" not in h.calls[1][1]["json"]["text"]


def test_failed_integration_does_not_raise_or_burn_cooldown(I, monkeypatch):
    monkeypatch.setattr(I, "_check_url", lambda u: u)
    cfg = {"webhook": {"url": "https://x"}}
    r = I.notify_findings([F1], config=cfg, http=Http(500)); assert r["webhook"].startswith("FAILED")
    r = I.notify_findings([F1], config=cfg, http=Http(200)); assert r["webhook"].startswith("ok")      # retried next time


def test_splunk_and_secrets_from_env(I, monkeypatch):
    monkeypatch.setattr(I, "_check_url", lambda u: u)
    h = Http()
    cfg = {"splunk_hec": {"url": "https://s/", "token_env": "AF_T"}}
    r = I.notify_findings([F1], config=cfg, http=h); assert r["splunk_hec"].startswith("FAILED") and "AF_T" in r["splunk_hec"]
    monkeypatch.setenv("AF_T", "tok123")
    r = I.notify_findings([F1], config=cfg, http=h); assert r["splunk_hec"].startswith("ok")
    assert h.calls[-1][1]["headers"]["Authorization"] == "Splunk tok123"
    assert json.loads(h.calls[-1][1]["data"].split("\n")[0])["event"]["class_uid"] == 2004


def test_jira_and_servicenow_tickets_only_for_critical(I, monkeypatch):
    monkeypatch.setattr(I, "_check_url", lambda u: u)
    monkeypatch.setenv("J_E", "me@x"); monkeypatch.setenv("J_T", "tok"); monkeypatch.setenv("S_U", "u"); monkeypatch.setenv("S_P", "p")
    h = Http(201, {"key": "SEC-7", "result": {"number": "INC001"}})
    cfg = {"jira": {"base_url": "https://j", "project": "SEC", "email_env": "J_E", "token_env": "J_T"},
           "servicenow": {"instance_url": "https://s", "user_env": "S_U", "pass_env": "S_P", "min_severity": "High"}}
    r = I.notify_findings([F1, F2], config=cfg, http=h)
    jira = [c for c in h.calls if "/rest/api/3/issue" in c[0]]; snow = [c for c in h.calls if "/api/now/table" in c[0]]
    assert len(jira) == 1 and "Risky Port" in jira[0][1]["json"]["fields"]["summary"]            # only the Critical one
    assert len(snow) == 2 and r["jira"] == ["SEC-7"]
    h2 = Http(201, {"key": "SEC-8"}); I.notify_findings([F1, F2], config=cfg, http=h2)
    assert not h2.calls                                                                         # tickets are not re-created within a week


def test_metadata_ip_blocked(I, monkeypatch):
    import socket
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(2, 1, 6, "", ("169.254.169.254", 0))])
    with pytest.raises(ValueError, match="link-local"): I._check_url("http://metadata.example/")
    with pytest.raises(ValueError): I._check_url("file:///etc/passwd")


def test_email_sender(I):
    sent = {}
    class S:
        def __init__(s, *a, **k): pass
        def __enter__(s): return s
        def __exit__(s, *a): pass
        def starttls(s, context=None): sent["tls"] = True
        def send_message(s, m): sent["msg"] = m
    r = I.notify_findings([F1], config={"email": {"host": "h", "from": "a@b", "to": ["c@d"]}}, smtp_cls=S)
    assert r["email"].startswith("ok") and sent["tls"] and "SSH Root Login" in sent["msg"].get_content()


def test_drift_and_export(I):
    prev = [F1]; cur = [F1, {**F1, "Check": "New Thing", "Details": "x"}, PASS]
    assert [f["Check"] for f in I.drift_new_findings(prev, cur)] == ["New Thing"]
    assert len(I.export_events([F1, F2]).splitlines()) == 2 and I.export_events([F1], "cef").startswith("CEF:0")
