from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
import hashlib, json, os, random, sqlite3, sys, time
import pytest


@pytest.fixture()
def auth(afhome, tmp_path, monkeypatch):
    for m in ("af_auth",):
        sys.modules.pop(m, None)
    import af_auth
    monkeypatch.setattr(af_auth, "BREACH_CHECK", False)
    db = tmp_path / "h.db"
    af_auth.init(db)
    af_auth.DB = db
    return af_auth


def mk(auth, name="alice", pw="correct horse battery", role="admin"):
    auth.create_user(auth.DB, name, pw, role)
    return name, pw


def test_audit_trail_is_chained_and_tamper_evident(auth):
    mk(auth); auth.authenticate(auth.DB, "alice", "wrong"); auth.authenticate(auth.DB, "alice", "correct horse battery")
    assert auth.verify_audit(auth.DB)["ok"]
    c = sqlite3.connect(auth.DB); c.execute("UPDATE ui_audit SET event='nothing_to_see' WHERE event='login_failed'"); c.commit()
    assert not auth.verify_audit(auth.DB)["ok"]


def test_timestamps_are_utc(auth):
    mk(auth); auth.authenticate(auth.DB, "alice", "correct horse battery")
    u = auth.get_user(auth.DB, "alice")
    assert u["created"].endswith("+00:00") and u["last_login"].endswith("+00:00")
    c = sqlite3.connect(auth.DB); assert all(r[0].endswith("+00:00") for r in c.execute("SELECT ts FROM ui_audit"))


def test_update_user_validates_without_assert(auth):
    mk(auth)
    with pytest.raises(ValueError, match="cannot update"): auth.update_user(auth.DB, "alice", "x", is_admin=1)
    with pytest.raises(ValueError, match="unknown role"): auth.update_user(auth.DB, "alice", "x", role="root")
    src = (ROOT / "af_auth.py").read_text(); assert "assert set(fields)" not in src


def test_totp_secret_bound_to_user_and_recovery_codes(auth):
    mk(auth, "alice"); mk(auth, "bob")
    sec = auth.new_totp_secret()
    auth.update_user(auth.DB, "alice", "alice", totp_secret=auth._enc(sec, "alice"), mfa_enabled=1)
    assert auth._dec(auth.get_user(auth.DB, "alice")["totp_secret"], "alice") == sec
    assert auth._dec(auth.get_user(auth.DB, "alice")["totp_secret"], "bob").startswith("[encrypted")   # cannot be moved to another account
    codes = auth.set_recovery_codes(auth.DB, "alice")
    assert len(codes) == 10 and auth.recovery_codes_left(auth.DB, "alice") == 10
    ok, user, _ = auth.authenticate(auth.DB, "alice", "correct horse battery", codes[0])
    assert ok and auth.recovery_codes_left(auth.DB, "alice") == 9
    ok, *_ = auth.authenticate(auth.DB, "alice", "correct horse battery", codes[0])
    assert not ok                                                                    # single use
    ok, *_ = auth.authenticate(auth.DB, "alice", "correct horse battery", codes[1].replace("-", "").upper())
    assert ok                                                                        # case/dash insensitive
    ok, *_ = auth.authenticate(auth.DB, "alice", "wrong password!!", codes[2]); assert not ok   # code alone is not enough
    stored = auth.get_user(auth.DB, "alice")["recovery_codes"]; assert codes[3].replace("-", "") not in stored   # hashed at rest


def test_totp_login_still_works_and_replay_blocked(auth):
    mk(auth); sec = auth.new_totp_secret()
    auth.update_user(auth.DB, "alice", "alice", totp_secret=auth._enc(sec, "alice"), mfa_enabled=1)
    code = auth.totp_at(sec)[0]
    assert auth.authenticate(auth.DB, "alice", "correct horse battery", code)[0]
    assert not auth.authenticate(auth.DB, "alice", "correct horse battery", code)[0]


def test_step_up_requires_password_and_totp(auth):
    mk(auth); assert not auth.verify_step_up(auth.DB, "alice", "nope")
    assert auth.verify_step_up(auth.DB, "alice", "correct horse battery")
    sec = auth.new_totp_secret(); auth.update_user(auth.DB, "alice", "alice", totp_secret=auth._enc(sec, "alice"), mfa_enabled=1)
    assert not auth.verify_step_up(auth.DB, "alice", "correct horse battery", "000000")
    assert auth.verify_step_up(auth.DB, "alice", "correct horse battery", auth.totp_at(sec)[0])


class FakeSt:
    def __init__(self): self.session_state = {}
    def form(self, *a, **k): raise AssertionError("form must not be shown when step-up is fresh")


def test_step_up_window_and_sso_exemption(auth):
    st = FakeSt()
    assert auth.require_step_up(st, auth.DB, {"username": "a", "sso": True})
    st.session_state["stepup_until"] = time.time() + 60
    assert auth.require_step_up(st, auth.DB, {"username": "a", "mfa": False})
    st.session_state["stepup_until"] = time.time() - 1
    assert not auth.step_up_ok(st)


def test_setup_code_gate(auth, afhome):
    code = auth.get_setup_code()
    assert (afhome / "setup_code").stat().st_mode & 0o777 == 0o600 and auth.get_setup_code() == code
    assert not auth.check_setup_code("wrong") and auth.check_setup_code(code)
    auth._setup_fails[:] = [time.time()] * 5
    assert not auth.check_setup_code(code)                              # brute-force lockout
    auth._setup_fails.clear(); auth.clear_setup_code(); assert not (afhome / "setup_code").exists()


def test_password_policy_and_offline_breach_list(auth, tmp_path, monkeypatch):
    assert auth.password_problems("password12345")
    hashes = sorted(hashlib.sha1(f"password-{i:05d}".encode()).hexdigest().upper() for i in range(2000))
    f = tmp_path / "breached.txt"; f.write_text("\n".join(h + ":42" for h in hashes) + "\n")
    for i in random.sample(range(2000), 200):
        assert auth._offline_breached(hashlib.sha1(f"password-{i:05d}".encode()).hexdigest().upper(), str(f)), i
    for i in range(50):
        assert not auth._offline_breached(hashlib.sha1(f"absent-{i}".encode()).hexdigest().upper(), str(f))
    assert auth._offline_breached(hashes[0], str(f)) and auth._offline_breached(hashes[-1], str(f))     # first/last lines
    monkeypatch.setattr(auth, "BREACHED_FILE", str(f))
    assert "appears in known data breaches - choose another" in auth.password_problems("password-00123")
    assert auth.password_problems("a-very-unique-passphrase-2931") == []


def test_hibp_range_query_parsing(auth, monkeypatch):
    import requests
    h = hashlib.sha1(b"hunter2hunter2").hexdigest().upper()
    class R:
        status_code = 200; text = f"0018A45C4D1DEF81644B54AB7F969B88D65:0\n{h[5:]}:77\n"
    seen = {}
    monkeypatch.setattr(requests, "get", lambda url, **k: (seen.update(url=url, **k), R())[1])
    monkeypatch.setattr(auth, "BREACH_CHECK", True)
    assert auth.breached_count("hunter2hunter2") == 77
    assert seen["url"].endswith(h[:5]) and h[5:] not in seen["url"]                 # only the 5-char prefix leaves the machine
    monkeypatch.setattr(requests, "get", lambda *a, **k: (_ for _ in ()).throw(requests.ConnectionError()))
    assert auth.breached_count("hunter2hunter2") == 0                              # offline: fail open


# ------------------------------------------------------------------ SSO
def test_sso_role_mapping(auth, monkeypatch):
    monkeypatch.setenv("AF_SSO_ROLE_MAP", json.dumps({"af-admins": "admin", "af-analysts": "analyst", "evil": "root"}))
    assert auth.map_sso_role({"groups": ["af-analysts", "af-admins"]}) == "admin"          # highest wins
    assert auth.map_sso_role({"groups": "af-analysts"}) == "analyst"
    assert auth.map_sso_role({"groups": ["evil"]}) == "auditor"                              # unknown mapped role ignored -> default
    monkeypatch.setenv("AF_SSO_DEFAULT_ROLE", "none")
    assert auth.map_sso_role({"groups": []}) is None


def test_sso_provisioning_rules(auth, monkeypatch):
    monkeypatch.setenv("AF_SSO_ROLE_MAP", json.dumps({"g1": "analyst"}))
    u, msg = auth.sso_provision(auth.DB, {"email": "Eve@Corp.com", "email_verified": True, "groups": ["g1"]})
    assert u["username"] == "eve@corp.com" and u["role"] == "analyst" and u["sso"] and not u["needs_setup"]
    assert not auth.authenticate(auth.DB, "eve@corp.com", "!sso")[0]                       # IdP accounts have no usable local password
    u, _ = auth.sso_provision(auth.DB, {"email": "eve@corp.com", "groups": ["g1"]}); assert u
    assert auth.sso_provision(auth.DB, {"email": "x@y.z", "email_verified": False})[0] is None
    assert auth.sso_provision(auth.DB, {"groups": ["g1"]})[0] is None
    mk(auth, "carol@corp.com")                                                               # local account cannot be silently taken over
    assert auth.sso_provision(auth.DB, {"email": "carol@corp.com", "groups": ["g1"]})[0] is None
    auth.update_user(auth.DB, "eve@corp.com", "admin", disabled=1)
    assert auth.sso_provision(auth.DB, {"email": "eve@corp.com", "groups": ["g1"]})[0] is None
