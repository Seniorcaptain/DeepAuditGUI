"""A lab of real listening services on 127.0.0.1 (ephemeral ports) for exercising the scanner end to end."""
import asyncio, datetime, ipaddress, socket, ssl, tempfile, threading
from pathlib import Path


def make_cert(cn="lab.local", days=30, self_signed=True):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    key = rsa.generate_private_key(65537, 2048)
    now = datetime.datetime.now(datetime.timezone.utc)
    name = x509.Name([x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, cn)])
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=400 if days < 0 else 1)).not_valid_after(now + datetime.timedelta(days=days))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName(cn), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]), False)
            .sign(key, hashes.SHA256()))
    d = Path(tempfile.mkdtemp())
    (d / "c.pem").write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    (d / "k.pem").write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    return str(d / "c.pem"), str(d / "k.pem")


HTTP_RESP = (b"HTTP/1.1 200 OK\r\nServer: Apache/2.4.49 (Ubuntu)\r\nX-Powered-By: PHP/7.4.3\r\nContent-Type: text/html\r\n\r\n"
             b"<html><head><title> Admin   Panel </title></head><body>hi</body></html>")
HTTPS_RESP = b"HTTP/1.1 200 OK\r\nServer: nginx/1.18.0 (Ubuntu)\r\nContent-Type: text/html\r\n\r\n<html><title>Secure</title></html>"
RDP_CC_STANDARD = bytes.fromhex("03000013" "0ed0" "0000" "1234" "00" "02000800" "00000000")
RDP_CC_NLA = bytes.fromhex("03000013" "0ed0" "0000" "1234" "00" "02000800" "02000000")
MYSQL_GREETING = b"\x4a\x00\x00\x00\x0a5.7.38-0ubuntu0.18.04.1\x00" + b"\x00" * 40


class Lab:
    def __init__(self, tls_days=30, rdp=RDP_CC_STANDARD):
        self.ports, self.loop, self._servers = {}, asyncio.new_event_loop(), []
        self.tls_days, self.rdp = tls_days, rdp
        self.ready = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def __enter__(self):
        self.thread.start()
        assert self.ready.wait(10)
        return self

    def __exit__(self, *a):
        self.loop.call_soon_threadsafe(self.loop.stop)
        self.thread.join(5)

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._start())
        self.ready.set()
        self.loop.run_forever()

    async def _start(self):
        async def serve(name, handler, ssl_ctx=None):
            srv = await asyncio.start_server(handler, "127.0.0.1", 0, ssl=ssl_ctx)
            self.ports[name] = srv.sockets[0].getsockname()[1]
            self._servers.append(srv)

        async def ssh(r, w):
            w.write(b"SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6\r\n"); await w.drain(); await asyncio.sleep(0.2); w.close()

        async def ftp(r, w):
            w.write(b"220 (vsFTPd 3.0.3)\r\n"); await w.drain()
            try:
                while True:
                    ln = await asyncio.wait_for(r.readline(), 3)
                    if not ln: break
                    if ln.upper().startswith(b"USER"): w.write(b"331 Please specify the password.\r\n")
                    elif ln.upper().startswith(b"PASS"): w.write(b"230 Login successful.\r\n")
                    else: w.write(b"500 ?\r\n")
                    await w.drain()
            except Exception: pass
            w.close()

        async def http(resp):
            async def h(r, w):
                try:
                    await asyncio.wait_for(r.readuntil(b"\r\n\r\n"), 3)
                    w.write(resp); await w.drain()
                except Exception: pass
                w.close()
            return h

        async def redis(r, w):
            try:
                while True:
                    ln = await asyncio.wait_for(r.readline(), 3)
                    if not ln: break
                    if ln.upper().startswith(b"PING"): w.write(b"+PONG\r\n")
                    elif ln.upper().startswith(b"INFO"):
                        body = b"# Server\r\nredis_version:6.0.16\r\nos:Linux\r\n"; w.write(b"$%d\r\n" % len(body) + body + b"\r\n")
                    elif ln.strip() and not ln.startswith((b"Host:", b"User-Agent:", b"Accept:", b"Connection:")):
                        w.write(b"-ERR wrong number of arguments for command\r\n")
                    await w.drain()
            except Exception: pass
            w.close()

        async def mysql(r, w):
            w.write(MYSQL_GREETING); await w.drain(); await asyncio.sleep(0.2); w.close()

        async def rdp(r, w):
            try:
                await asyncio.wait_for(r.read(64), 3); w.write(self.rdp); await w.drain()
            except Exception: pass
            w.close()

        async def smb1(r, w):
            try:
                await asyncio.wait_for(r.read(64), 3); w.write(b"\x00\x00\x00\x20\xffSMBr\x00\x00\x00\x00" + b"\x00" * 20); await w.drain()
            except Exception: pass
            w.close()

        async def silent(r, w):
            try: await asyncio.sleep(5)
            finally: w.close()

        await serve("ssh", ssh); await serve("ftp", ftp); await serve("http", await http(HTTP_RESP)); await serve("redis", redis)
        await serve("mysql", mysql); await serve("rdp", rdp); await serve("smb1", smb1); await serve("silent", silent)
        c, k = make_cert(days=self.tls_days)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(c, k)
        await serve("https", await http(HTTPS_RESP), ctx)

    def closed_port(self):
        s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p
