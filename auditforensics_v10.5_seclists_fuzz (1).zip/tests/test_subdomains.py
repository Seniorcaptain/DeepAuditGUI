import socket, struct, threading, time
import pytest
import af_subdomains as S


def _name(n):
    return b"".join(bytes([len(p)]) + p.encode() for p in n.strip(".").split(".")) + b"\x00"


def fake_dns_server(answers, rcode=0):
    """answers: {(qname, qtype): [(rtype, rdata_text)]}. Returns (server_ip, port, stop_fn)."""
    srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    srv.bind(("127.0.0.1", 0))
    srv.settimeout(0.3)
    port = srv.getsockname()[1]
    stop = threading.Event()

    def build_response(data):
        txid = data[:2]
        qd = struct.unpack(">H", data[4:6])[0]
        off = 12
        labels = []
        while data[off]:
            n = data[off]; labels.append(data[off + 1:off + 1 + n].decode()); off += 1 + n
        off += 1
        qname = ".".join(labels)
        qtype = struct.unpack(">H", data[off:off + 2])[0]
        off += 4
        question = data[12:off]
        recs = answers.get((qname, qtype), [])
        rr = b""
        for rtype, text in recs:
            if rtype == 1:
                rdata = socket.inet_aton(text)
            elif rtype == 28:
                rdata = socket.inet_pton(socket.AF_INET6, text)
            elif rtype == 5:
                rdata = _name(text)
            else:
                rdata = text.encode()
            rr += b"\xc0\x0c" + struct.pack(">HHIH", rtype, 1, 60, len(rdata)) + rdata
        header = txid + struct.pack(">H", 0x8180 | rcode) + struct.pack(">HHHH", qd, len(recs), 0, 0)
        return header + question + rr

    def run():
        while not stop.is_set():
            try:
                data, addr = srv.recvfrom(512)
            except socket.timeout:
                continue
            try:
                srv.sendto(build_response(data), addr)
            except OSError:
                pass
        srv.close()
    threading.Thread(target=run, daemon=True).start()
    return "127.0.0.1", port, stop


@pytest.fixture()
def dns(monkeypatch):
    servers = []

    def mk(answers, rcode=0):
        ip, port, stop = fake_dns_server(answers, rcode)
        servers.append(stop)
        # resolve() always talks to port 53; patch socket.sendto target via a thin shim: easiest is to monkeypatch
        # af_subdomains._query_once to redirect the destination port while keeping all parsing logic identical.
        orig = S._query_once

        def patched(name, qtype, server, timeout, txid):
            return orig(name, qtype, server, timeout, txid) if False else _query_at(name, qtype, ip, port, timeout, txid)
        monkeypatch.setattr(S, "_query_once", patched)
        return ip

    def _query_at(name, qtype, host, port, timeout, txid):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        try:
            s.sendto(S.dns_query(name, qtype, 1, txid), (host, port))
            data, _ = s.recvfrom(4096)
            return S.parse_dns(data)
        except (socket.timeout, OSError):
            return None
        finally:
            s.close()
    yield mk
    for st in servers:
        st.set()


def test_resolve_a_aaaa_and_cname(dns):
    dns({("host.example.com", 1): [(1, "10.0.0.5")], ("host.example.com", 28): [(28, "2001:db8::1")]})
    r = S.resolve("host.example.com", ["127.0.0.1"], timeout=1.0, retries=1)
    assert r == {"a": ["10.0.0.5"], "aaaa": ["2001:db8::1"], "cname": None, "nxdomain": False, "error": None}


def test_resolve_cname_chain():
    dns_ip, port, stop = fake_dns_server({("shop.example.com", 1): [(5, "shops.myshopify.com"), (1, "23.227.38.65")],
                                          ("shop.example.com", 28): []})
    import af_subdomains as S2
    S2._query_once = lambda name, qtype, server, timeout, txid: _raw(name, qtype, port, timeout, txid)
    def _raw(name, qtype, port, timeout, txid):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(timeout)
        try:
            s.sendto(S2.dns_query(name, qtype, 1, txid), ("127.0.0.1", port))
            data, _ = s.recvfrom(4096)
            return S2.parse_dns(data)
        except (socket.timeout, OSError):
            return None
        finally:
            s.close()
    r = S2.resolve("shop.example.com", ["127.0.0.1"], timeout=1.0, retries=1)
    assert r["cname"] == "shops.myshopify.com" and r["a"] == ["23.227.38.65"]
    stop.set()


def test_resolve_nxdomain_and_no_response():
    ip, port, stop = fake_dns_server({}, rcode=3)
    import af_subdomains as S2
    def _raw(name, qtype, server, timeout, txid):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(timeout)
        try:
            s.sendto(S2.dns_query(name, qtype, 1, txid), (ip, port))
            data, _ = s.recvfrom(4096)
            return S2.parse_dns(data)
        except (socket.timeout, OSError):
            return None
        finally:
            s.close()
    S2._query_once = _raw
    r = S2.resolve("nope.example.com", ["127.0.0.1"], timeout=1.0, retries=1)
    assert r["nxdomain"] and r["a"] == [] and r["error"] is None
    stop.set()
    # a genuinely closed UDP port for the "nothing answers" case, independent of the server thread's shutdown timing
    closed = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); closed.bind(("127.0.0.1", 0))
    closed_port = closed.getsockname()[1]; closed.close()
    def _closed(name, qtype, server, timeout, txid):
        return _raw(name, qtype, server, timeout, txid) if False else None
    import af_subdomains as S3
    S3._query_once = lambda name, qtype, server, timeout, txid: None
    r2 = S3.resolve("x.example.com", ["127.0.0.1"], timeout=0.1, retries=1)
    assert r2["error"] == "no response from any resolver"


def test_wildcard_detection_and_filtering(monkeypatch):
    wc = {"a": ["1.2.3.4"], "aaaa": [], "cname": None}
    def fake_resolve(name, servers=None, timeout=1.5, retries=2):
        if "af-wc-" in name or name.startswith("ghost."):
            return {"a": wc["a"], "aaaa": [], "cname": None, "nxdomain": False, "error": None}
        if name == "www.example.com.".rstrip("."):
            return {"a": ["5.6.7.8"], "aaaa": [], "cname": None, "nxdomain": False, "error": None}
        return {"a": [], "aaaa": [], "cname": None, "nxdomain": True, "error": None}
    monkeypatch.setattr(S, "resolve", fake_resolve)
    info = S.detect_wildcard("example.com")
    assert info["wildcard"] and info["a"] == ["1.2.3.4"]
    found, wcinfo = S.enumerate_bruteforce("example.com", ["www", "ghost", "doesnotexist"])
    assert set(found) == {"www.example.com"} and wcinfo["wildcard"]      # 'ghost' matches the wildcard signature -> filtered as noise


def test_classify_cname_known_and_unknown_and_takeover():
    assert S.classify_cname("myapp.github.io") == ("GitHub Pages", True)
    assert S.classify_cname("d123.cloudfront.net") == ("AWS CloudFront", False)
    assert S.classify_cname("internal.corp.local") == (None, False)
    assert S.classify_cname(None) == (None, False)
    live = {"a": [], "aaaa": [], "cname": "ghost-project.github.io"}
    dead_cls = S.classify_record(live)
    assert dead_cls == {"third_party": True, "provider": "GitHub Pages", "takeover_prone": True, "takeover_risk": True}
    healthy = {"a": ["1.2.3.4"], "aaaa": [], "cname": "ghost-project.github.io"}
    assert S.classify_record(healthy)["takeover_risk"] is False          # resolves fine: not dangling
    cdn = {"a": [], "aaaa": [], "cname": "d1.cloudfront.net"}
    assert S.classify_record(cdn)["takeover_risk"] is False              # CloudFront is not takeover-prone by itself


def test_crtsh_parses_dedups_and_filters_out_of_scope(monkeypatch):
    class R:
        status_code = 200
        def json(self):
            return [{"name_value": "www.example.com\napi.example.com"}, {"name_value": "*.dev.example.com"},
                    {"name_value": "example.com"}, {"name_value": "evil.other.com"}, {"name_value": "WWW.EXAMPLE.COM"}]
    http = type("H", (), {"get": lambda s, url, params=None, timeout=0, headers=None: R()})()
    names, err = S.enumerate_crtsh("example.com", http)
    assert names == {"www.example.com", "api.example.com", "dev.example.com", "example.com"} and err == ""


def test_crtsh_error_handling(monkeypatch):
    class Bad:
        def get(self, *a, **k): raise ConnectionError("offline")
    names, err = S.enumerate_crtsh("example.com", Bad())
    assert names == set() and "offline" in err
    class HttpErr:
        status_code = 503
        def get(self, *a, **k): return self
    names, err = S.enumerate_crtsh("example.com", HttpErr())
    assert "503" in err
    class BadJson:
        status_code = 200
        def get(self, *a, **k): return self
        def json(self): raise ValueError("not json")
    names, err = S.enumerate_crtsh("example.com", BadJson())
    assert "rate-limited" in err


def test_enumerate_subdomains_end_to_end_with_takeover(monkeypatch):
    calls = []
    def fake_crtsh(domain, http=None, timeout=20):
        return {"api.example.com", "ghost.example.com"}, ""
    def fake_resolve(name, servers=None, timeout=1.5, retries=2):
        calls.append(name)
        data = {"www.example.com": {"a": ["1.1.1.1"], "aaaa": [], "cname": None},
                "api.example.com": {"a": ["2.2.2.2"], "aaaa": [], "cname": None},
                "ghost.example.com": {"a": [], "aaaa": [], "cname": "proj.github.io"},
                "af-wc-dummy.example.com": {"a": [], "aaaa": [], "cname": None}}
        d = data.get(name, {"a": [], "aaaa": [], "cname": None})
        return {**d, "nxdomain": name not in data, "error": None}
    monkeypatch.setattr(S, "enumerate_crtsh", fake_crtsh)
    monkeypatch.setattr(S, "resolve", fake_resolve)
    res = S.enumerate_subdomains("example.com", wordlist=["www"], use_crtsh=True, use_bruteforce=True)
    names = {r["name"] for r in res["records"]}
    assert {"www.example.com", "api.example.com", "ghost.example.com"} <= names
    gh = next(r for r in res["records"] if r["name"] == "ghost.example.com")
    assert gh["takeover_risk"] and gh["provider"] == "GitHub Pages"
    assert res["crtsh_count"] == 2 and res["domain"] == "example.com"


def test_enumerate_subdomains_cancel_stops_early(monkeypatch):
    monkeypatch.setattr(S, "resolve", lambda *a, **k: {"a": [], "aaaa": [], "cname": None, "nxdomain": True, "error": None})
    res = S.enumerate_subdomains("example.com", use_crtsh=False, use_bruteforce=True, cancel=lambda: True)
    assert res["records"] == []


def test_enumerate_subdomains_skips_crtsh_when_disabled(monkeypatch):
    called = []
    monkeypatch.setattr(S, "enumerate_crtsh", lambda *a, **k: called.append(1) or (set(), ""))
    monkeypatch.setattr(S, "resolve", lambda *a, **k: {"a": [], "aaaa": [], "cname": None, "nxdomain": True, "error": None})
    S.enumerate_subdomains("example.com", use_crtsh=False, use_bruteforce=True)
    assert not called
