import sqlite3, json
import pytest
import af_vault, af_signing, af_audit, af_util


# ------------------------------------------------------------------ vault
def test_vault_roundtrip_and_aad_binding(afhome):
    t = af_vault.encrypt_text("secret", af_vault.aad_for("agent_findings", "details", "A1"))
    assert t.startswith("enc:v2:k1:")
    assert af_vault.decrypt_text(t, af_vault.aad_for("agent_findings", "details", "A1")) == "secret"
    # moved to another row / column -> refuses to decrypt
    assert af_vault.decrypt_text(t, af_vault.aad_for("agent_findings", "details", "A2")).startswith("[encrypted:")
    assert af_vault.decrypt_text(t, af_vault.aad_for("agent_findings", "recommendation", "A1")).startswith("[encrypted:")


def test_vault_reads_legacy_v1(afhome):
    from cryptography.fernet import Fernet
    import base64
    kek = af_vault._kek()
    legacy = af_vault.PREFIX_V1 + Fernet(base64.urlsafe_b64encode(kek)).encrypt(b"old").decode()
    assert af_vault.decrypt_text(legacy) == "old"
    assert af_vault.needs_reencrypt(legacy)


def test_vault_rotation_and_reencrypt(afhome, tmp_path):
    db = tmp_path / "h.db"
    c = sqlite3.connect(db)
    c.execute("CREATE TABLE agent_findings (id INTEGER PRIMARY KEY, agent_id TEXT, details TEXT, recommendation TEXT)")
    aad = af_vault.aad_for("agent_findings", "details", "A1")
    c.execute("INSERT INTO agent_findings (agent_id, details, recommendation) VALUES ('A1', ?, 'plain rec')",
              (af_vault.encrypt_text("detail-1", aad),))
    c.commit(); c.close()
    old = af_vault.encrypt_text("x", "")
    new_kid = af_vault.rotate_key()
    assert new_kid == "k2"
    assert af_vault.decrypt_text(old) == "x"                      # old key id still readable
    res = af_vault.reencrypt_db(db)
    assert res["agent_findings"] == 1
    c = sqlite3.connect(db)
    d, r = c.execute("SELECT details, recommendation FROM agent_findings").fetchone()
    assert d.startswith("enc:v2:k2:") and r.startswith("enc:v2:k2:")   # plaintext column got encrypted too
    assert af_vault.decrypt_text(d, aad) == "detail-1"
    assert af_vault.reencrypt_db(db)["agent_findings"] == 0           # idempotent


def test_vault_passphrase_mode(afhome, monkeypatch):
    monkeypatch.setenv("AF_DB_KEY", "correct horse battery staple")
    t = af_vault.encrypt_text("p", "ctx")
    assert af_vault.status()["mode"] == "passphrase"
    monkeypatch.setenv("AF_DB_KEY", "a different passphrase")
    af_vault._cache.clear()
    with pytest.raises(Exception):
        af_vault.decrypt_text(t, "ctx") if False else af_vault._load_keyring()


def test_vault_disabled_passthrough(afhome, monkeypatch):
    monkeypatch.setenv("AF_VAULT", "0")
    assert af_vault.encrypt_text("abc", "x") == "abc"


# ------------------------------------------------------------------ signing
def test_command_signature_roundtrip_and_tamper(afhome):
    sig = af_signing.sign_command("a1", 7, "ping", {}, "n1", "t0", "t1")
    pub = af_signing.public_pem(af_signing.CMD_KEY)
    msg = af_signing.command_message("a1", 7, "ping", {}, "n1", "t0", "t1")
    assert af_signing.verify(pub, sig, msg)
    assert not af_signing.verify(pub, sig, af_signing.command_message("a1", 7, "run_file_scan", {}, "n1", "t0", "t1"))
    assert not af_signing.verify(pub, sig, af_signing.command_message("a2", 7, "ping", {}, "n1", "t0", "t1"))


def test_manifest_signature(afhome):
    sig, pub = af_signing.sign_manifest(b'{"a":1}')
    assert af_signing.verify_manifest(b'{"a":1}', sig, pub)
    assert not af_signing.verify_manifest(b'{"a":2}', sig, pub)


# ------------------------------------------------------------------ audit chain
def _mk(db):
    c = sqlite3.connect(db)
    c.execute("CREATE TABLE ui_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, username TEXT, event TEXT, detail TEXT)")
    c.commit(); c.close()


def test_audit_chain_detects_edit_and_delete(tmp_path):
    db = tmp_path / "a.db"; _mk(db)
    for i in range(5):
        af_audit.append(db, "ui_audit", ts=f"t{i}", username="u", event="e", detail=str(i))
    assert af_audit.verify(db, "ui_audit")["ok"]
    c = sqlite3.connect(db); c.execute("UPDATE ui_audit SET detail='forged' WHERE id=3"); c.commit(); c.close()
    r = af_audit.verify(db, "ui_audit")
    assert not r["ok"] and r["first_bad_id"] == 3
    c = sqlite3.connect(db); c.execute("UPDATE ui_audit SET detail='2' WHERE id=3"); c.execute("DELETE FROM ui_audit WHERE id=2"); c.commit(); c.close()
    assert not af_audit.verify(db, "ui_audit")["ok"]


def test_audit_ignores_legacy_unchained_rows(tmp_path):
    db = tmp_path / "a.db"; _mk(db)
    c = sqlite3.connect(db); c.execute("INSERT INTO ui_audit (ts,username,event,detail) VALUES ('old','u','e','d')"); c.commit(); c.close()
    af_audit.append(db, "ui_audit", ts="n", username="u", event="e", detail="d")
    assert af_audit.verify(db, "ui_audit") == {"ok": True, "checked": 1, "head": af_audit.verify(db, "ui_audit")["head"],
                                               "first_bad_id": None, "message": "chain intact"}


# ------------------------------------------------------------------ utc
def test_utc_helpers():
    assert af_util.has_tz("2026-01-01T00:00:00+00:00") and not af_util.has_tz("2026-01-01T00:00:00")
    assert af_util.parse_ts("2026-01-01T00:00:00Z").utcoffset().total_seconds() == 0
    assert af_util.utc_iso().endswith("+00:00")


def test_migrate_naive_to_utc(tmp_path):
    c = sqlite3.connect(tmp_path / "x.db")
    c.execute("CREATE TABLE t (a TEXT, b TEXT)")
    c.execute("INSERT INTO t VALUES ('2026-01-01T10:00:00', '2026-01-01T10:00:00+00:00')")
    n = af_util.migrate_naive_to_utc(c, "t", ["a", "b"])
    a, b = c.execute("SELECT a,b FROM t").fetchone()
    assert n == 1 and af_util.has_tz(a) and b == "2026-01-01T10:00:00+00:00"
    assert af_util.migrate_naive_to_utc(c, "t", ["a", "b"]) == 0      # idempotent


# ------------------------------------------------------------------ pki
def _csr(cn="x"):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    k = ec.generate_private_key(ec.SECP256R1())
    csr = (x509.CertificateSigningRequestBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)]))
           .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)   # hostile: asks to be a CA
           .sign(k, hashes.SHA256()))
    return csr.public_bytes(serialization.Encoding.PEM)


def test_pki_encrypted_ca_and_csr_signing(tmp_path, monkeypatch):
    import af_pki
    from cryptography import x509
    d = tmp_path / "pki"
    monkeypatch.setenv("AF_CA_PASSPHRASE", "ca-pass-123")
    af_pki.init_ca(d)
    assert b"ENCRYPTED" in (d / "ca.key").read_bytes()
    pem, fp, serial = af_pki.sign_csr(d, _csr("evil-admin"), "web01", days=9999)
    cert = x509.load_pem_x509_certificate(pem)
    assert cert.subject.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)[0].value == "web01"   # CN comes from us
    assert cert.extensions.get_extension_for_class(x509.BasicConstraints).value.ca is False         # CA request ignored
    assert (cert.not_valid_after_utc - cert.not_valid_before_utc).days <= 397                       # days clamped
    assert af_pki.cert_fingerprint(pem) == fp
    assert af_pki.cert_days_left(pem) > 300
    monkeypatch.delenv("AF_CA_PASSPHRASE")
    with pytest.raises(SystemExit):
        af_pki.sign_csr(d, _csr(), "web02")                                                          # no passphrase -> refuses


def test_pki_rejects_weak_rsa(tmp_path, monkeypatch):
    import af_pki
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    monkeypatch.delenv("AF_CA_PASSPHRASE", raising=False)
    d = tmp_path / "pki"; af_pki.init_ca(d)
    k = rsa.generate_private_key(65537, 1024)
    csr = x509.CertificateSigningRequestBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "x")])).sign(k, hashes.SHA256())
    with pytest.raises(ValueError):
        af_pki.sign_csr(d, csr.public_bytes(serialization.Encoding.PEM), "w")
