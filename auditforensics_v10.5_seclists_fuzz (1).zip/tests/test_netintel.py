import csv, io, json
import xml.etree.ElementTree as ET
import pytest
import af_netintel as I, af_netmap as N


def svc(port, name="", product="", key="", version="", notes=(), state="open", http=None, tls=None, os_hints=(), banner="", proto="tcp"):
    return {"port": port, "proto": proto, "state": state, "name": name, "product": product, "product_key": key, "version": version, "notes": list(notes),
            "http": http, "tls": tls, "os_hints": list(os_hints), "banner": banner}


def dev(ip, services=(), udp=(), **kw):
    d = N.new_device(ip); d["services"] = list(services); d["udp"] = list(udp); d.update(kw); return d


# ------------------------------------------------------------------ OS + device type
def test_ttl_math():
    assert I.initial_ttl(57) == 64 and I.hops_from_ttl(57) == 7 and I.initial_ttl(120) == 128 and I.hops_from_ttl(250) == 5 and I.initial_ttl(None) is None


def test_os_guess_windows_from_services_and_ttl():
    d = dev("10.0.0.5", [svc(445, "smb"), svc(3389, "rdp"), svc(135, "msrpc")], ttl=128)
    os_, conf, why = I.guess_os(d)
    assert os_ == "Windows" and conf >= 60 and any("TTL 128" in w for w in why) and any("RDP" in w for w in why)


def test_os_guess_linux_distro_from_banner():
    d = dev("10.0.0.6", [svc(22, "ssh", "OpenSSH", "openssh", "8.9p1", os_hints=["ubuntu"])], ttl=64)
    assert I.guess_os(d)[0] == "Linux (Ubuntu)"
    assert I.guess_os(dev("1.1.1.1")) == ("", 0, [])


def test_os_signals_disagree_lowers_confidence():
    solid = dev("a", [svc(22, "ssh", os_hints=["ubuntu"]), svc(80, "http", os_hints=["ubuntu"])], ttl=64)
    mixed = dev("b", [svc(445, "smb"), svc(22, "ssh", os_hints=["ubuntu"])], ttl=64)
    assert I.guess_os(solid)[1] > I.guess_os(mixed)[1]


@pytest.mark.parametrize("d,expected", [
    (dev("10.0.0.1", [svc(80, "http"), svc(443, "https")], gateway=True), "Router/Gateway"),
    (dev("10.0.0.7", [svc(9100, "jetdirect"), svc(631, "ipp")]), "Printer"),
    (dev("10.0.0.8", [svc(554, "rtsp")]), "IP Camera/NVR"),
    (dev("10.0.0.9", [svc(88, "kerberos"), svc(389, "ldap"), svc(445, "smb"), svc(53, "dns")]), "Domain Controller"),
    (dev("10.0.0.10", [svc(5432, "postgresql"), svc(22, "ssh")]), "Database server"),
    (dev("10.0.0.11", [svc(80, "http", "nginx", "nginx", "1.18.0")]), "Web server"),
    (dev("10.0.0.12", [svc(62078, "")]), "Apple mobile device"),
    (dev("10.0.0.13", [svc(443, "https", http={"title": "VMware ESXi", "server": ""})]), "Hypervisor"),
    (dev("10.0.0.14", [svc(2049), svc(445), svc(548)]), "NAS/Storage"),
    (dev("10.0.0.15", [svc(1883, "mqtt")]), "IoT/Embedded"),
    (dev("10.0.0.16", [svc(6443), svc(10250)]), "Kubernetes node"),
    (dev("10.0.0.17", vendor="Hikvision Digital"), "IP Camera/NVR"),
    (dev("10.0.0.18"), "Unknown")])
def test_device_classification(d, expected):
    t, why = I.classify(d)
    assert t == expected and why


def test_enrich_sets_everything_and_gateway_flag():
    ds = I.enrich_devices([dev("10.0.0.1", [svc(80, "http")], ttl=64, hostnames=["gw.lan"], mac="00:0c:29:00:00:01", vendor="VMware"), dev("10.0.0.2", ttl=60)], gateways=["10.0.0.1"])
    assert ds[0]["gateway"] and ds[0]["dtype"] == "Router/Gateway" and ds[0]["name"] == "gw.lan" and ds[0]["virtual"] and ds[1]["hops"] == 4


# ------------------------------------------------------------------ findings
def titles(d): return {f["check"] for f in I.device_findings(d)}


def test_exposure_findings_and_private_vs_public_severity():
    d = dev("10.0.0.5", [svc(23, "telnet"), svc(21, "ftp", notes=["ftp-anonymous-login"]), svc(445, "smb", notes=["smb1-enabled"]),
                         svc(3389, "rdp", notes=["rdp-nla-not-required"]), svc(6379, "redis", notes=["redis-no-auth"]), svc(3306, "mysql"),
                         svc(80, "http", notes=["http-basic-auth-cleartext"])])
    t = titles(d)
    assert {"Telnet Service Open", "Cleartext FTP Open", "Anonymous FTP Login", "SMBv1 Enabled", "RDP Without NLA", "Redis Without Authentication",
            "Database Service Reachable (MySQL)", "Basic Authentication Over HTTP"} <= t
    risk = {f["check"]: f["risk"] for f in I.device_findings(d)}
    assert risk["Telnet Service Open"] == "High" and risk["Redis Without Authentication"] == "Critical"
    pub = dev("8.8.4.4", [svc(23, "telnet"), svc(3389, "rdp"), svc(445, "smb")], public=True)
    risk = {f["check"]: f["risk"] for f in I.device_findings(pub)}
    assert risk["Telnet Service Open"] == "Critical" and risk["RDP Exposed to Internet"] == "Critical" and risk["SMB Exposed to Internet"] == "Critical"
    assert "Public Address With Open Services" in titles(pub)


def test_tls_findings():
    cert = {"expired": True, "not_after": "2020-01-01T00:00:00+00:00", "days_left": -2000, "self_signed": True, "subject_cn": "x", "key": "RSA-1024", "sig_alg": "sha1WithRSAEncryption"}
    d = dev("10.0.0.5", [svc(443, "https", tls={"version": "TLSv1.2", "cert": cert}, notes=["tls-legacy:TLSv1.0,TLSv1.1"])])
    t = titles(d)
    assert {"Expired Certificate", "Self-Signed Certificate", "Weak Certificate Key", "Weak Certificate Signature", "Legacy TLS Protocols Accepted"} <= t
    soon = dict(cert, expired=False, days_left=10, self_signed=False, key="RSA-2048", sig_alg="sha256WithRSAEncryption")
    assert titles(dev("x", [svc(443, tls={"cert": soon})])) == {"Certificate Expiring Soon"}
    assert titles(dev("x", [svc(443, tls={"cert": dict(soon, days_left=200)})])) == set()


def test_udp_findings_and_many_ports():
    d = dev("10.0.0.5", udp=[svc(161, "snmp", notes=["snmp-public-community"], banner="Linux gw", proto="udp"), svc(11211, "memcached", proto="udp")])
    assert {"SNMP Default Community 'public'", "Memcached UDP Open"} <= titles(d)
    assert "Unusually Many Open Ports" in titles(dev("10.0.0.5", [svc(p) for p in range(1000, 1060)]))
    assert titles(dev("10.0.0.5", udp=[svc(161, "snmp", state="open|filtered", proto="udp")])) == set()       # silence is not a finding


def test_cve_findings_carry_caveats():
    d = dev("10.0.0.5", cves=[{"cve": "CVE-2021-41773", "score": 7.5, "severity": "High", "summary": "Path traversal", "port": 80, "proto": "tcp", "product": "Apache httpd",
                               "version": "2.4.49", "kev": True, "epss": 0.97, "priority": 9.1, "priority_label": "Act now", "backport_risk": True,
                               "confidence": "banner version match (unverified)"}])
    f = I.cve_findings(d)[0]
    assert f["risk"] == "High" and "KEV" in f["details"] and "backported" in f["details"] and "unverified" in f["details"] and f["port"] == 80


def test_device_risk_from_findings():
    d = dev("1.1.1.1"); d["findings"] = [{"status": "FAIL", "risk": "High"}, {"status": "PASS", "risk": "Critical"}, {"status": "WARNING", "risk": "Medium"}]
    assert I.device_risk(d) == "High" and I.device_risk(dev("x")) == "Info"


# ------------------------------------------------------------------ topology
def sample_net():
    ds = [dev("192.168.1.1", [svc(80)], gateway=True, name="router", hops=0), dev("192.168.1.20", [svc(22)], name="srv"), dev("192.168.1.21"),
          dev("10.5.0.9", [svc(445)], name="remote", hops=3)]
    return I.enrich_devices(ds, ["192.168.1.1"])


def test_topology_nodes_edges_and_traces():
    ds = sample_net()
    top = I.build_topology(ds, ["192.168.1.1"], "192.168.1.50", ["192.168.1.0/24"], traces={"10.5.0.9": ["192.168.1.1", "172.16.0.1", "*", "10.5.0.1"]})
    ids = {n["id"]: n for n in top["nodes"]}
    assert ids["scanner"]["kind"] == "scanner" and ids["dev:192.168.1.1"]["kind"] == "gateway" and ids["net:192.168.1.0/24"]["kind"] == "subnet"
    assert ids["hop:172.16.0.1"]["kind"] == "hop" and ids["hop:10.5.0.1"]["kind"] == "hop" and "hop:*" not in ids
    pairs = {(e["source"], e["target"]) for e in top["edges"]} | {(e["target"], e["source"]) for e in top["edges"]}
    assert ("net:192.168.1.0/24", "dev:192.168.1.20") in pairs and ("scanner", "net:192.168.1.0/24") in pairs and ("dev:192.168.1.1", "hop:172.16.0.1") in pairs
    assert ("hop:10.5.0.1", "dev:10.5.0.9") in pairs
    assert all(e["source"] in ids and e["target"] in ids for e in top["edges"])                         # no dangling edges
    assert len(top["edges"]) == len({tuple(sorted((e["source"], e["target"]))) for e in top["edges"]})  # no duplicates


def test_topology_unconnected_subnet_is_attached_not_orphaned():
    top = I.build_topology(sample_net(), ["192.168.1.1"], "192.168.1.50", ["192.168.1.0/24"])
    linked = {e["source"] for e in top["edges"]} | {e["target"] for e in top["edges"]}
    assert "net:10.5.0.0/24" in linked


def test_layout_covers_every_node_without_overlap():
    top = I.build_topology(sample_net(), ["192.168.1.1"], "192.168.1.50", ["192.168.1.0/24"])
    pos = I.layout(top)
    assert set(pos) == {n["id"] for n in top["nodes"]} and pos["scanner"] == (0.0, 0.0)
    pts = list(pos.values()); assert len(set((round(x, 3), round(y, 3)) for x, y in pts)) == len(pts)


def test_graphml_is_valid_xml_and_dot_escapes():
    ds = sample_net(); ds[1]["name"] = 'evil"<script>&'
    top = I.build_topology(ds, ["192.168.1.1"], "192.168.1.50", ["192.168.1.0/24"])
    root = ET.fromstring(I.topology_graphml(top))
    ns = {"g": "http://graphml.graphdrawing.org/xmlns"}
    assert len(root.findall(".//g:node", ns)) == len(top["nodes"]) and len(root.findall(".//g:edge", ns)) == len(top["edges"])
    dot = I.topology_dot(top); assert dot.startswith("graph network {") and '\\"' in dot and dot.rstrip().endswith("}")


# ------------------------------------------------------------------ change detection
def test_diff_new_gone_changed_and_mac_conflict():
    prev = [dev("10.0.0.1", [svc(22)], mac="aa:aa:aa:aa:aa:01", cves=[{"cve": "CVE-1"}]), dev("10.0.0.2", [svc(80)]), dev("10.0.0.3"), dev("172.16.0.9")]
    cur = [dev("10.0.0.1", [svc(22), svc(23)], mac="bb:bb:bb:bb:bb:02", cves=[{"cve": "CVE-1"}, {"cve": "CVE-2"}]), dev("10.0.0.2", [svc(80)]), dev("10.0.0.4", mac="cc:cc:cc:cc:cc:03", dtype="Printer")]
    df = I.diff_scans(prev, cur, scanned_ips=["10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4"])
    assert [d["ip"] for d in df["new"]] == ["10.0.0.4"] and [d["ip"] for d in df["gone"]] == ["10.0.0.3"]            # 172.16.0.9 was out of scope: not 'gone'
    ch = df["changed"][0]
    assert ch["ip"] == "10.0.0.1" and ch["opened"] == [(23, "tcp")] and ch["new_cves"] == ["CVE-2"] and ch["mac_changed"][1] == "bb:bb:bb:bb:bb:02" and df["mac_conflicts"] == ["10.0.0.1"]
    f = {x["check"]: x for x in I.diff_findings(df)}
    assert f["New Device On Network"]["risk"] == "Medium" and f["MAC Address Changed For IP"]["risk"] == "High" and f["New Open Ports"] and f["New Vulnerabilities"]
    assert f["Device No Longer Seen"]["status"] == "INFO"
    assert I.diff_scans(cur, cur)["changed"] == [] and I.diff_findings(I.diff_scans(cur, cur)) == []


# ------------------------------------------------------------------ exports
def test_csv_exports_and_formula_injection_guard():
    d = dev("10.0.0.5", [svc(80, "http", "Apache httpd", "apache", "2.4.49", banner="=HYPERLINK(\"http://evil\",\"x\")", http={"title": "+cmd|' /C calc'!A0"})], name="@SUM(1)",
            cves=[{"cve": "CVE-1", "score": 7.5, "severity": "High", "summary": "-2+3", "port": 80, "proto": "tcp", "product": "Apache", "version": "2.4.49", "kev": False,
                   "epss": 0.1, "priority": 6.0, "priority_label": "Attend", "confidence": "x"}])
    for text in (I.devices_csv([d]), I.services_csv([d]), I.cves_csv([d])):
        rows = list(csv.DictReader(io.StringIO(text)))
        assert rows and all(not str(v).startswith(("=", "+", "-", "@")) for r in rows for k, v in r.items() if k in ("name", "banner", "http_title", "summary"))
    assert list(csv.DictReader(io.StringIO(I.devices_csv([d]))))[0]["name"] == "'@SUM(1)"
    assert json.loads(I.scan_json({"a": 1}, [d]))["devices"][0]["ip"] == "10.0.0.5"


def test_alive_confidence_and_low_confidence_new_device():
    assert I.alive_confidence(dev("1.1.1.1", discovered_by=["icmp"])) == "high"
    assert I.alive_confidence(dev("1.1.1.1", discovered_by=["tcp-closed:80"])) == "low"
    assert I.alive_confidence(dev("1.1.1.1", [svc(22)], discovered_by=["tcp-closed:80"])) == "high"      # an open port is a real conversation
    assert I.alive_confidence(dev("1.1.1.1")) == "unknown"
    df = I.diff_scans([], [dev("10.0.0.9", discovered_by=["tcp-closed:445"])])
    f = I.diff_findings(df)[0]
    assert f["check"].startswith("Possible New Device") and f["risk"] == "Low" and f["status"] == "INFO"       # no rogue-device alarm from RST alone
