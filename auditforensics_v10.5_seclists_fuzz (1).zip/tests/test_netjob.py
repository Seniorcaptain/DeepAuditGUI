import json, sqlite3, threading, time
import pytest
import af_netjob as J, af_netmap as N, af_netintel as I, af_scope, af_vault
from fakelab import Lab

NMAP_XML = """<?xml version="1.0"?><nmaprun><host><status state="up"/><address addr="10.0.0.5" addrtype="ipv4"/><address addr="00:0C:29:AA:BB:CC" addrtype="mac" vendor="VMware"/>
<hostnames><hostname name="web01.lan"/></hostnames><ports>
<port protocol="tcp" portid="22"><state state="open"/><service name="ssh" product="OpenSSH" version="8.9p1 Ubuntu 3ubuntu0.6" extrainfo="Ubuntu Linux; protocol 2.0" ostype="Linux"><cpe>cpe:/a:openbsd:openssh:8.9p1</cpe></service></port>
<port protocol="tcp" portid="8080"><state state="open"/><service name="http" product="Apache Tomcat" version="9.0.50"/></port>
<port protocol="tcp" portid="9999"><state state="closed"/></port></ports>
<os><osmatch name="Linux 5.4 - 5.10" accuracy="96"/></os><uptime seconds="100" lastboot="Mon Oct 12 05:00:00 2026"/></host>
<host><status state="down"/><address addr="10.0.0.6" addrtype="ipv4"/></host></nmaprun>"""


@pytest.fixture()
def lab():
    with Lab() as l:
        yield l


@pytest.fixture(autouse=True)
def env(afhome, tmp_path, monkeypatch):
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    monkeypatch.setattr(J, "DB_PATH", tmp_path / "h.db")
    monkeypatch.setattr(N, "read_arp_table", lambda run=None: {})
    monkeypatch.setattr(N, "scapy_arp_sweep", lambda ips: {})
    monkeypatch.setattr(N, "broadcast_discovery", lambda t=3.0: {})
    monkeypatch.setattr(N, "default_gateways", lambda run=None: [])
    monkeypatch.setattr(af_scope, "load_policy", lambda: {**af_scope.load_policy.__wrapped__()} if hasattr(af_scope.load_policy, "__wrapped__") else dict(allow=[], deny=[], max_hosts=4096, rate_per_sec=0.0, rate_per_host=0.0, require_ticket=False, blackout=[]))
    af_vault._cache.clear()


def cfg(lab, **kw):
    kw.setdefault("ports", sorted(lab.ports.values()))
    kw.setdefault("icmp", False); kw.setdefault("reverse_dns", False); kw.setdefault("netbios", False); kw.setdefault("broadcast", False)
    kw.setdefault("timeout", 0.6)
    return N.ScanConfig(**kw)


# ------------------------------------------------------------------ parsers
def test_parse_traceroute_all_formats():
    lin = " 1  192.168.1.1  0.452 ms\n 2  10.20.0.1  3.1 ms\n 3  * * *\n 4  8.8.8.8  12.2 ms"
    assert J.parse_traceroute(lin) == ["192.168.1.1", "10.20.0.1", "*", "8.8.8.8"]
    win = "Tracing route to x\n\n  1    <1 ms    <1 ms    <1 ms  192.168.1.1\n  2     *        *        *     Request timed out.\n  3    12 ms    11 ms    11 ms  8.8.8.8\n\nTrace complete."
    assert J.parse_traceroute(win) == ["192.168.1.1", "*", "8.8.8.8"]
    assert J.parse_traceroute(" 1:  192.168.1.1   0.5ms\n 2:  no reply") == ["192.168.1.1", "*"]
    assert J.traceroute("a b; ls") == []


def test_parse_nmap_and_merge():
    info = J.parse_nmap_xml(NMAP_XML)
    assert set(info) == {"10.0.0.5"} and info["10.0.0.5"]["os"][0] == ("Linux 5.4 - 5.10", 96) and len(info["10.0.0.5"]["ports"]) == 3
    d = N.new_device("10.0.0.5")
    d["services"] = [{"port": 22, "proto": "tcp", "state": "open", "name": "ssh", "product": "", "product_key": "", "version": "", "banner": "", "os_hints": [], "notes": []},
                     {"port": 8080, "proto": "tcp", "state": "open", "name": "", "product": "", "product_key": "", "version": "", "banner": "", "os_hints": [], "notes": []},
                     {"port": 25, "proto": "tcp", "state": "open", "name": "smtp", "product": "Postfix", "product_key": "postfix", "version": "3.4.13", "banner": "", "os_hints": [], "notes": []}]
    J.merge_nmap(d, info["10.0.0.5"])
    a, b, c = d["services"]
    assert (a["product_key"], a["version"]) == ("openssh", "8.9p1") and (b["product_key"], b["version"]) == ("tomcat", "9.0.50") and c["version"] == "3.4.13"   # own evidence kept
    assert d["mac"] == "00:0c:29:aa:bb:cc" and d["vendor"] == "VMware" and d["nmap_os"][0][1] == 96 and "linux" not in d["os_hints"] or True
    with pytest.raises(ValueError): J.parse_nmap_xml('<?xml version="1.0"?><!DOCTYPE x [<!ENTITY a "b">]><nmaprun/>')


def test_nmap_enrich_handles_failures():
    d = N.new_device("10.0.0.5"); d["services"] = [{"port": 22, "state": "open", "proto": "tcp", "product_key": "", "version": "", "name": "", "os_hints": []}]
    assert J.nmap_enrich(d, None, run=lambda c: type("R", (), {"stdout": ""})()).startswith("nmap produced no XML")
    def boom(c): raise OSError("no nmap")
    assert J.nmap_enrich(d, None, run=boom).startswith("nmap failed")
    seen = []
    assert J.nmap_enrich(d, None, run=lambda c: (seen.append(c), type("R", (), {"stdout": NMAP_XML})())[1]) == "ok"
    assert seen[0][:2] == ["nmap", "-Pn"] and "10.0.0.5" == seen[0][-1] and isinstance(seen[0], list)


# ------------------------------------------------------------------ the scan end to end
def test_full_scan_of_the_lab(lab, tmp_path, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    conn = sqlite3.connect(tmp_path / "h.db")
    calls = []
    def cve_fn(devices, progress):
        calls.append(1)
        for d in devices:
            d["cves"] = [{"cve": "CVE-2021-41773", "score": 7.5, "severity": "High", "summary": "x", "port": s["port"], "proto": "tcp", "product": "Apache httpd", "version": s["version"],
                          "kev": True, "epss": 0.9, "priority": 8.8, "priority_label": "Act", "backport_risk": True, "confidence": "banner version match (unverified)"}
                         for s in d["services"] if s["product_key"] == "apache"]
        return {"lookups": 1}
    seen = []
    r = J.run_scan(["127.0.0.1"], cfg(lab, intensity="deep"), progress=lambda p, m: seen.append(p), cve_fn=cve_fn, conn=conn, username="alice")
    d = r["devices"][0]
    assert len(r["devices"]) == 1 and d["ip"] == "127.0.0.1" and len(I._open(d)) == len(lab.ports)
    by = {s["name"]: s for s in d["services"]}
    assert by["ssh"]["product_key"] == "openssh" and by["ftp"]["product_key"] == "vsftpd" and by["mysql"]["version"] == "5.7.38" and by["redis"]["version"] == "6.0.16"
    assert d["os"].startswith("Linux") and d["dtype"] and d["name"] is not None
    checks = {f["check"] for f in r["findings"]}
    assert {"Anonymous FTP Login", "Redis Without Authentication", "Cleartext FTP Open", "Self-Signed Certificate", "RDP Without NLA", "CVE-2021-41773 in Apache httpd 2.4.49"} <= checks
    assert calls and seen == sorted(seen) and seen[-1] == 100                                    # monotonic progress, ends at 100
    assert r["topology"]["nodes"] and r["meta"]["addresses_probed"] == 1 and r["id"] == 1
    ui = J.to_ui_results(r["findings"]); assert {"Host", "Category", "Check", "Status", "Risk", "Details"} <= set(ui[0])


def test_persistence_is_encrypted_and_roundtrips(lab, tmp_path, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    conn = sqlite3.connect(tmp_path / "h.db")
    r = J.run_scan(["127.0.0.1"], cfg(lab), conn=conn)
    raw = conn.execute("SELECT devices_json, timestamp FROM net_scans").fetchone()
    assert raw[0].startswith("enc:v2:") and "127.0.0.1" not in raw[0]
    assert af_vault.decrypt_text(raw[0], f"net_scans.devices_json|{raw[1]}").startswith("{")
    assert af_vault.decrypt_text(raw[0], "net_scans.devices_json|other").startswith("[encrypted")      # bound to its row
    back = J.load_scan(conn, r["id"])
    assert back["devices"][0]["ip"] == "127.0.0.1" and back["meta"]["profile"] == "standard"
    a = J.list_assets(conn)[0]; assert a["ip"] == "127.0.0.1" and a["scans_seen"] == 1
    assert conn.execute("SELECT services_json FROM net_assets").fetchone()[0].startswith("enc:v2:")
    J.run_scan(["127.0.0.1"], cfg(lab), conn=conn)
    a = J.list_assets(conn)[0]; assert a["scans_seen"] == 2 and a["first_seen"] <= a["last_seen"] and len(J.list_scans(conn)) == 2
    assert af_vault.reencrypt_db(tmp_path / "h.db").get("net_scans") == 0                              # already on the primary key


def test_rescan_reports_changes(lab, tmp_path, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    conn = sqlite3.connect(tmp_path / "h.db")
    J.run_scan(["127.0.0.1"], cfg(lab), conn=conn)
    p = sorted(lab.ports.values())
    r2 = J.run_scan(["127.0.0.1"], cfg(lab, ports=[x for x in p if x != lab.ports["ftp"]] + [lab.closed_port()]), conn=conn)
    ch = r2["diff"]["changed"][0]
    assert ch["closed"] == [(lab.ports["ftp"], "tcp")] and not ch["opened"]
    assert r2["diff"]["new"] == [] and any(f["check"] == "Device No Longer Seen" or f["category"] != "Asset Change" for f in r2["findings"])
    r3 = J.run_scan(["127.0.0.1", "127.0.0.2"], cfg(lab), conn=conn)                                   # different target set: no diff baseline
    assert r3["diff"] is None


def test_new_device_is_flagged(lab, tmp_path, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    conn = sqlite3.connect(tmp_path / "h.db")
    monkeypatch.setattr(J.af_scope, "expand_ip_range", lambda t, max_hosts=None: ["127.0.0.1"])
    J.run_scan(["lab"], cfg(lab), conn=conn)
    monkeypatch.setattr(J.af_scope, "expand_ip_range", lambda t, max_hosts=None: ["127.0.0.1", "127.0.0.2"])
    r = J.run_scan(["lab"], cfg(lab), conn=conn)
    assert [d["ip"] for d in r["diff"]["new"]] == ["127.0.0.2"] and any(f["check"] == "Possible New Device (low confidence)" for f in r["findings"])    # 127.0.0.2 only answered with an RST


def test_one_host_crash_does_not_abort_the_scan(lab, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    orig = N.scan_host
    def flaky(ip, d, c, cancel=None, progress=None):
        if ip == "127.0.0.2": raise RuntimeError("boom")
        return orig(ip, d, c, cancel, progress)
    monkeypatch.setattr(N, "scan_host", flaky)
    monkeypatch.setattr(J.af_scope, "expand_ip_range", lambda t, max_hosts=None: ["127.0.0.1", "127.0.0.2"])
    r = J.run_scan(["x"], cfg(lab))
    by = {d["ip"]: d for d in r["devices"]}
    assert len(by["127.0.0.1"]["services"]) == len(lab.ports) and any("port scan failed" in n for n in by["127.0.0.2"]["notes"])


# ------------------------------------------------------------------ job manager + guardrails
def test_job_lifecycle_and_single_job_rule(lab, tmp_path, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    J.NetJob.registry.clear()
    job = J.NetJob(["127.0.0.1"], cfg(lab), db_path=tmp_path / "h.db", user="alice").start()
    with pytest.raises(RuntimeError, match="already running"):
        J.NetJob(["127.0.0.1"], cfg(lab), db_path=tmp_path / "h.db").start()
    for _ in range(200):
        if job.state != "running": break
        time.sleep(0.1)
    st = job.status()
    assert st["state"] == "done" and st["pct"] == 100 and job.result["devices"] and J.NetJob.latest() is job and J.NetJob.get(job.id) is job
    assert sqlite3.connect(tmp_path / "h.db").execute("SELECT username FROM net_scans").fetchone()[0] == "alice"


def test_job_cancel(lab, tmp_path, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    J.NetJob.registry.clear()
    job = J.NetJob(["127.0.0.1"], cfg(lab, ports=N.FULL_TCP, concurrency=50, timeout=2.0, rate_per_host=100), db_path=tmp_path / "h.db").start()
    time.sleep(0.8); job.cancel()
    for _ in range(100):
        if job.state != "running": break
        time.sleep(0.1)
    assert job.state == "cancelled" and job.result is None
    assert not sqlite3.connect(tmp_path / "h.db").execute("SELECT name FROM sqlite_master WHERE name='net_scans'").fetchone() or \
        sqlite3.connect(tmp_path / "h.db").execute("SELECT COUNT(*) FROM net_scans").fetchone()[0] == 0                # nothing half-saved


def test_job_failure_is_reported(tmp_path, monkeypatch):
    J.NetJob.registry.clear()
    monkeypatch.setattr(J, "run_scan", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("kaboom")))
    job = J.NetJob(["127.0.0.1"], N.ScanConfig(), db_path=tmp_path / "h.db").start()
    for _ in range(50):
        if job.state != "running": break
        time.sleep(0.1)
    assert job.state == "failed" and "kaboom" in job.error


def test_job_enforces_scope_itself(tmp_path):
    J.NetJob.registry.clear()
    pol = dict(allow=["10.0.0.0/8"], deny=[], max_hosts=4096, rate_per_sec=0, rate_per_host=0, require_ticket=False, blackout=[])
    with pytest.raises(af_scope.ScopeError, match="outside the allowed scope"):
        J.NetJob(["192.168.0.0/24"], N.ScanConfig(), db_path=tmp_path / "h.db", policy=pol)
    pol2 = dict(pol, allow=[])
    resolver = lambda h, _: [(2, 1, 6, "", ("93.184.216.34", 0))]
    with pytest.raises(af_scope.ScopeError, match="authorization"):
        J.NetJob(["example.com"], N.ScanConfig(), db_path=tmp_path / "h.db", policy=pol2, resolver=resolver)
    assert J.NetJob(["example.com"], N.ScanConfig(), db_path=tmp_path / "h.db", policy=pol2, resolver=resolver, auth_id=7).auth_id == 7
    with pytest.raises(af_scope.ScopeError, match="exceeds"):
        J.NetJob(["10.0.0.0/8"], N.ScanConfig(), db_path=tmp_path / "h.db", policy=dict(pol, max_hosts=100))


def test_oversized_range_refused_inside_run_scan():
    with pytest.raises(af_scope.ScopeError):
        J.run_scan(["10.0.0.0/8"], N.ScanConfig(icmp=False))


def test_warns_when_many_hosts_only_answer_with_resets(lab, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.closed_port()])
    ips = [f"127.0.0.{i}" for i in range(2, 12)]
    monkeypatch.setattr(J.af_scope, "expand_ip_range", lambda t, max_hosts=None: ips)
    r = J.run_scan(["x"], cfg(lab, ports=[]))
    assert r["meta"]["low_confidence_hosts"] == 10 and "TCP resets" in r["meta"]["warnings"][0]
