from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
import gzip, json, os, sys, time
import pytest
from fastapi.testclient import TestClient

import af_checks as C


class TC:
    """requests-like adapter over the in-process FastAPI TestClient (optionally simulating an outage)."""
    def __init__(self, client): self.c, self.down, self.calls = client, False, []
    def _go(self, verb, url, **kw):
        if self.down: raise ConnectionError("manager unreachable")
        for k in ("timeout", "verify", "cert"): kw.pop(k, None)
        if "data" in kw:
            d = kw.pop("data"); kw["content"] = d.read() if hasattr(d, "read") else d
        self.calls.append((verb, url))
        return getattr(self.c, verb)(url, **kw)
    def get(self, url, **kw): return self._go("get", url, **kw)
    def post(self, url, **kw): return self._go("post", url, **kw)


@pytest.fixture()
def env(afhome, tmp_path, monkeypatch):
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    monkeypatch.setenv("AF_AGENT_HOME", str(tmp_path / "agent"))
    monkeypatch.delenv("AF_ENROLL_TOKEN", raising=False); monkeypatch.delenv("AF_ALLOW_LIVE_RESPONSE", raising=False)
    for m in ("af_manager_api", "af_agent"):
        sys.modules.pop(m, None)
    import af_manager_api as api, af_agent
    api._REG_HITS.clear()
    monkeypatch.setattr(af_agent.time, "sleep", lambda s: None)
    monkeypatch.setattr(af_agent, "POLL_WAIT", 0)
    http = TC(TestClient(api.app))
    class E: pass
    e = E(); e.api, e.agent_mod, e.http, e.tmp = api, af_agent, http, tmp_path
    def mk(ctx=None, **kw):
        return af_agent.AuditForensicsAgent("http://testserver", kw.pop("token", api.get_enroll_token()), http=http,
                                            ctx=ctx or C.Ctx(system="Linux", runner=lambda c, t=30: ("", -1), files={}, tools=set(), psutil_mod=None), **kw)
    e.mk = mk
    return e


def last_cmd(api, aid):
    c = api.db(); return c.execute("SELECT * FROM agent_commands WHERE agent_id=? ORDER BY id DESC LIMIT 1", (aid,)).fetchone()


def test_register_poll_execute_report(env):
    a = env.mk()
    assert a.register() == "ok" and a.agent_token and a.pubkey
    cid, _ = env.api.queue_command(a.agent_id, "ping", {}, "alice")
    a.step()
    r = last_cmd(env.api, a.agent_id)
    assert r["status"] == "done" and "pong" in r["summary"] and r["attempts"] == 1
    # state survives a restart and keeps the same stable uid
    b = env.mk(); assert b.agent_token == a.agent_token and b.state["agent_uid"] == a.state["agent_uid"]
    assert (env.tmp / "agent" / "state.json").stat().st_mode & 0o777 == 0o600


def test_coverage_reaches_the_manager(env):
    a = env.mk(); a.register()
    cid, _ = env.api.queue_command(a.agent_id, "run_local_audit", {}, "alice")
    a.step()
    r = last_cmd(env.api, a.agent_id); cov = json.loads(r["coverage"])
    assert cov["run"] >= 8 and cov["skipped"] + cov["errors"] + cov["not_applicable"] > 0
    assert "coverage" in r["summary"]
    c = env.api.db()
    assert c.execute("SELECT COUNT(*) n FROM agent_findings WHERE status='SKIPPED'").fetchone()["n"] > 0     # skipped checks are visible, not silent


def test_outage_spools_and_flushes_without_duplicates(env):
    a = env.mk(); a.register()
    cid, _ = env.api.queue_command(a.agent_id, "ping", {}, "alice")
    cmds = a.poll()
    env.http.down = True
    a._current_cmd = cmds[0]["id"]; a.send_result(cmds[0]["id"], a.execute(cmds[0]))
    spool = list((env.tmp / "agent" / "spool").glob("*.json.gz")); assert len(spool) == 1
    assert last_cmd(env.api, a.agent_id)["status"] == "running"
    env.http.down = False
    assert a.flush_spool() == 1 and not list((env.tmp / "agent" / "spool").glob("*.json.gz"))
    assert last_cmd(env.api, a.agent_id)["status"] == "done"
    c = env.api.db(); assert c.execute("SELECT COUNT(*) n FROM agent_findings").fetchone()["n"] == 1


def test_permanent_rejection_is_dropped_not_retried_forever(env):
    a = env.mk(); a.register()
    a._spool({"command_id": 9999, "status": "done", "summary": "", "findings": [], "inventory": {}, "coverage": {}, "result_id": "z"})
    assert a.flush_spool() == 1                                   # manager answers 404 -> treated as final
    assert not list((env.tmp / "agent" / "spool").glob("*"))


def test_step_backs_off_when_registration_fails_and_never_exits(env):
    a = env.mk(token="x" * 20)
    d = a.step()
    assert d > 3 and a._fail == 1
    a._fail = 20; assert a._backoff() <= env.agent_mod.MAX_BACKOFF * 1.3


# ------------------------------------------------------------------ signed commands
def test_signature_checks(env):
    a = env.mk(); a.register()
    env.api.queue_command(a.agent_id, "ping", {}, "alice")
    cmd = a.poll()[0]
    a.verify_command(cmd)                                                         # genuine
    with pytest.raises(env.agent_mod.CommandRejected, match="replayed"): a.verify_command(cmd)
    cmd2 = dict(cmd, nonce="other")
    with pytest.raises(env.agent_mod.CommandRejected, match="bad signature"): a.verify_command(cmd2)
    t = dict(cmd, command="run_file_scan", params={"paths": ["/"]}, nonce="n3")
    with pytest.raises(env.agent_mod.CommandRejected, match="bad signature"): a.verify_command(t)
    uns = {k: v for k, v in cmd.items() if k != "sig"}
    with pytest.raises(env.agent_mod.CommandRejected, match="unsigned"): a.verify_command(uns)


def test_expired_and_future_commands_rejected(env):
    import af_signing
    a = env.mk(); a.register()
    def signed(issued, expires, nonce):
        sig = af_signing.sign_command(a.agent_id, 5, "ping", {}, nonce, issued, expires)
        return {"id": 5, "command": "ping", "params": {}, "nonce": nonce, "issued": issued, "expires": expires, "sig": sig}
    with pytest.raises(env.agent_mod.CommandRejected, match="expired"):
        a.verify_command(signed("2020-01-01T00:00:00+00:00", "2020-01-01T00:10:00+00:00", "e1"))
    with pytest.raises(env.agent_mod.CommandRejected, match="future"):
        a.verify_command(signed("2099-01-01T00:00:00+00:00", "2099-01-01T00:10:00+00:00", "e2"))


def test_command_for_another_agent_rejected(env):
    a = env.mk(); a.register()
    b = env.mk(); b.state["agent_uid"] = "other-uid"; b.agent_token = None; b.register()
    env.api.queue_command(b.agent_id, "ping", {}, "alice")
    cmd = b.poll()[0]
    with pytest.raises(env.agent_mod.CommandRejected): a.verify_command(cmd)     # signature binds the agent id


def test_pinned_key_overrides_tofu(env, tmp_path):
    other = tmp_path / "other.pem"
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    other.write_bytes(Ed25519PrivateKey.generate().public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    a = env.mk(manager_pubkey=str(other)); a.register()
    env.api.queue_command(a.agent_id, "ping", {}, "alice")
    a.step()
    r = last_cmd(env.api, a.agent_id)
    assert r["status"] == "failed" and "bad signature" in r["summary"]


# ------------------------------------------------------------------ live response gating
def test_live_response_disabled_by_default(env, tmp_path):
    f = tmp_path / "bad.bin"; f.write_bytes(b"x")
    a = env.mk(); a.register()
    cid, _ = env.api.queue_command(a.agent_id, "quarantine_file", {"path": str(f)}, "alice"); env.api.approve_command(cid, "bob")
    a.step()
    assert f.exists() and "live response is disabled" in last_cmd(env.api, a.agent_id)["summary"]


def test_quarantine_end_to_end_when_enabled(env, tmp_path):
    f = tmp_path / "bad.bin"; f.write_bytes(b"x")
    a = env.mk(allow_live_response=True); a.register()
    cid, st = env.api.queue_command(a.agent_id, "quarantine_file", {"path": str(f)}, "alice")
    a.step(); assert f.exists()                                                  # not approved yet -> not delivered
    env.api.approve_command(cid, "bob"); a.step()
    assert not f.exists() and last_cmd(env.api, a.agent_id)["status"] == "done"
    c = env.api.db(); row = c.execute("SELECT sha256 FROM agent_findings WHERE check_name='File Quarantined'").fetchone()
    assert len(row["sha256"]) == 64


def _recording_ctx(rc_fail_on=None):
    calls = []
    def runner(cmd, t=30):
        calls.append(cmd)
        return ("boom", 1) if rc_fail_on and cmd[:2] == rc_fail_on else ("", 0)
    return C.Ctx(system="Linux", runner=runner, files={}, tools=set(), psutil_mod=None), calls


def test_isolation_applies_then_watchdog_releases(env, monkeypatch):
    ctx, calls = _recording_ctx()
    a = env.mk(ctx=ctx, allow_live_response=True)
    monkeypatch.setattr(a, "_manager_ips", lambda: ["10.0.0.5"])
    findings, cov, inv, summary = a._isolate(30)
    assert (env.tmp / "agent" / "isolation.json").exists() and any(c[:2] == ["iptables", "-I"] for c in calls)
    d = json.loads((env.tmp / "agent" / "isolation.json").read_text()); d["expires"] = "2000-01-01T00:00:00+00:00"
    (env.tmp / "agent" / "isolation.json").write_text(json.dumps(d))
    calls.clear(); a.isolation_watchdog()
    assert ["iptables", "-X", "AF_ISOLATE"] in calls and not (env.tmp / "agent" / "isolation.json").exists()


def test_isolation_rolls_back_on_failure_and_refuses_without_manager_ip(env, monkeypatch):
    ctx, calls = _recording_ctx(rc_fail_on=["iptables", "-I"])
    a = env.mk(ctx=ctx, allow_live_response=True)
    monkeypatch.setattr(a, "_manager_ips", lambda: ["10.0.0.5"])
    with pytest.raises(RuntimeError, match="rolled back"): a._isolate(30)
    assert ["iptables", "-X", "AF_ISOLATE"] in calls and not (env.tmp / "agent" / "isolation.json").exists()
    monkeypatch.setattr(a, "_manager_ips", lambda: [])
    with pytest.raises(ValueError): a._isolate(30)


# ------------------------------------------------------------------ re-enrollment & hijack
def test_lost_state_gets_conflict_until_released(env):
    a = env.mk(); a.register()
    b = env.mk(token=env.api.get_enroll_token()); b.agent_token = None; b.agent_id = None   # reinstall: lost token, same uid
    assert b.register() == "conflict"
    env.api.release_agent(a.agent_id, 10, "admin")
    assert b.register() == "ok" and b.agent_id == a.agent_id


# ------------------------------------------------------------------ triage + artifact upload
def test_triage_collected_and_uploaded_with_custody(env):
    a = env.mk(ctx=C.Ctx(system="Linux", psutil_mod=None)); a.register()
    cid, _ = env.api.queue_command(a.agent_id, "collect_triage", {"upload": True}, "alice")
    a.step()
    r = last_cmd(env.api, a.agent_id); assert r["status"] == "done", r["summary"]
    c = env.api.db()
    f = c.execute("SELECT * FROM agent_findings WHERE check_name='Triage Package Collected'").fetchone()
    assert "upload ok" in __import__("af_vault").decrypt_text(f["details"], f"agent_findings.details|{a.agent_id}")
    cu = c.execute("SELECT * FROM custody_log WHERE action='artifact_received'").fetchone()
    assert cu["sha256"] == f["sha256"]
    inv = c.execute("SELECT data FROM agent_inventory").fetchone()
    assert "archive_sha256" in __import__("af_vault").decrypt_text(inv["data"], f"agent_inventory.data|{a.agent_id}")


def test_large_results_are_gzipped(env):
    a = env.mk(); a.register()
    big = {"status": "done", "summary": "s", "findings": [C.F("c", f"n{i}", "PASS", "Info", "x" * 200) for i in range(800)], "inventory": {}, "coverage": {}}
    env.api.queue_command(a.agent_id, "ping", {}, "alice"); cmd = a.poll()[0]
    sent = {}
    orig = a._req
    def spy(method, path, **kw):
        sent.update(kw.get("headers", {})); return orig(method, path, **kw)
    a._req = spy
    a.send_result(cmd["id"], big)
    assert sent.get("Content-Encoding") == "gzip"
    c = env.api.db(); assert c.execute("SELECT COUNT(*) n FROM agent_findings").fetchone()["n"] == 800


# ------------------------------------------------------------------ service installation (TLS flags used to be dropped)
def test_service_keeps_tls_flags_and_hides_token(env, tmp_path):
    ca = tmp_path / "ca.crt"; ca.write_text("x")
    class A: pass
    a = A(); a.manager = "https://m:8765"; a.ca_bundle = str(ca); a.client_cert = "web01.crt"; a.client_key = "web01.key"
    a.enroll_url = None; a.manager_pubkey = None; a.no_verify_tls = False; a.allow_live_response = True
    args = env.agent_mod.agent_args(a)
    assert "--ca-bundle" in args and "--client-cert" in args and "--client-key" in args and "--allow-live-response" in args
    assert all(os.path.isabs(x) for x in args if x.endswith((".crt", ".key")))
    unit = env.agent_mod.render_systemd_unit("/usr/bin/python3", "/opt/af/af_agent.py", args, "/etc/af_agent.env", "/opt/af")
    assert "--client-cert" in unit and "ProtectSystem=full" in unit and "CapabilityBoundingSet=" in unit and "NoNewPrivileges=true" in unit
    assert "AF_ENROLL_TOKEN" not in unit and "PrivateTmp=" not in unit
    weird = env.agent_mod.render_systemd_unit("/usr/bin/python3", "/opt/my dir/af_agent.py", ["--manager", "https://m; rm -rf /"], "/e", "/o")
    assert "'https://m; rm -rf /'" in weird                                       # shell-quoted, no injection


def test_versions_are_one_source():
    import af_version, af_agent, af_manager_api
    assert af_agent.AGENT_VERSION == af_version.AGENT_VERSION == af_manager_api.API_VERSION == af_version.__version__


def test_agent_never_uses_shell_or_world_readable_state():
    src = (ROOT / "af_agent.py").read_text() + (ROOT / "af_checks.py").read_text()
    assert "shell=True" not in src and "os.system" not in src


def test_single_file_bundle_runs(tmp_path):
    import subprocess, sys as _s
    sys.path.insert(0, str(ROOT))
    import build_agent
    pyz = build_agent.build(tmp_path / "af_agent.pyz")
    r = subprocess.run([_s.executable, str(pyz), "--help"], capture_output=True, text=True, cwd=tmp_path)
    assert r.returncode == 0 and "--enroll-url" in r.stdout and "--allow-live-response" in r.stdout
