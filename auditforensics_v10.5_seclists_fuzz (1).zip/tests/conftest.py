import os, sys, sqlite3
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def afhome(tmp_path, monkeypatch):
    home = tmp_path / "afhome"
    home.mkdir()
    monkeypatch.setenv("AF_HOME", str(home))
    monkeypatch.delenv("AF_DB_KEY", raising=False)
    monkeypatch.delenv("AF_KEK_BACKEND", raising=False)
    monkeypatch.delenv("AF_VAULT", raising=False)
    monkeypatch.delenv("AF_SYSLOG", raising=False)
    import af_vault
    monkeypatch.setattr(af_vault, "HOME", home)
    af_vault._cache.clear()
    yield home
    af_vault._cache.clear()


@pytest.fixture(autouse=True)
def _no_network_breach_check(monkeypatch):
    monkeypatch.setenv("AF_HIBP", "0")
