import gzip, hashlib, json, sys, importlib, datetime
import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def m(afhome, tmp_path, monkeypatch):
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    monkeypatch.delenv("AF_ENROLL_TOKEN", raising=False)
    sys.modules.pop("af_manager_api", None)
    import af_manager_api
    af_manager_api._REG_HITS.clear()
    return af_manager_api


@pytest.fixture()
def cl(m):
    return TestClient(m.app)


def reg(cl, m, host="web01", uid=None, token=None, ip="10.0.0.5", hdr=None):
    token = token or m.get_enroll_token()
    r = cl.post("/register", json={"enroll_token": token, "hostname": host, "os": "Linux", "arch": "x86_64",
                                    "version": "1", "ip": ip, "agent_uid": uid or ""}, headers=hdr or {})
    return r


def H(tok):
    return {"X-Agent-Token": tok}


# ------------------------------------------------------------------ enrollment
def test_register_ok_and_returns_pubkey(cl, m):
    r = reg(cl, m, uid="u1")
    assert r.status_code == 200
    d = r.json()
    assert d["agent_token"] and "BEGIN PUBLIC KEY" in d["command_pubkey"]
    c = m.db(); row = c.execute("SELECT token FROM agents WHERE id=?", (d["agent_id"],)).fetchone()
    assert row["token"].startswith("sha256:")


def test_bad_token_and_rate_limit(cl, m):
    assert reg(cl, m, token="x" * 20).status_code == 403
    codes = [reg(cl, m, token="y" * 20, host=f"h{i}").status_code for i in range(12)]
    assert 429 in codes


def test_token_single_use_and_expiry(cl, m):
    t = m.create_enroll_token(max_uses=1, ttl_hours=1)
    assert reg(cl, m, uid="a", token=t).status_code == 200
    assert reg(cl, m, uid="b", token=t, host="h2").status_code == 403           # exhausted
    t2 = m.create_enroll_token(max_uses=0, ttl_hours=1)
    c = m.db(); c.execute("UPDATE enrollment_tokens SET expires_at='2000-01-01T00:00:00+00:00' WHERE token=?", (t2,)); c.commit(); c.close()
    assert reg(cl, m, uid="c", token=t2, host="h3").status_code == 403           # expired


def test_token_tags_applied_and_revoked_tokens_die(cl, m):
    t = m.create_enroll_token(tags="prod,db", max_uses=5)
    aid = reg(cl, m, uid="t1", token=t).json()["agent_id"]
    c = m.db(); assert c.execute("SELECT tags FROM agents WHERE id=?", (aid,)).fetchone()["tags"] == "prod,db"
    m.rotate_enroll_token()
    assert reg(cl, m, uid="t2", token=t, host="h2").status_code == 403


def test_reenroll_hijack_blocked_then_release_allows(cl, m):
    first = reg(cl, m, uid="u1").json()
    again = reg(cl, m, uid="u1")                                                  # attacker with the enrollment token
    assert again.status_code == 409
    assert cl.post("/heartbeat", json={}, headers=H(first["agent_token"])).status_code == 200   # real agent unaffected
    m.release_agent(first["agent_id"], 10, actor="admin")
    ok = reg(cl, m, uid="u1")
    assert ok.status_code == 200 and ok.json()["agent_id"] == first["agent_id"]
    assert cl.post("/heartbeat", json={}, headers=H(first["agent_token"])).status_code == 401   # old token dead
    assert reg(cl, m, uid="u1").status_code == 409                                # release was single use


def test_reenroll_with_current_token_allowed(cl, m):
    first = reg(cl, m, uid="u9").json()
    r = reg(cl, m, uid="u9", hdr=H(first["agent_token"]))
    assert r.status_code == 200


def test_legacy_agent_without_uid_cannot_replace_existing(cl, m):
    first = reg(cl, m, host="old", ip="10.1.1.1").json()
    assert reg(cl, m, host="old", ip="10.1.1.1").status_code == 409


# ------------------------------------------------------------------ results
def _agent(cl, m, uid, host):
    d = reg(cl, m, uid=uid, host=host, ip="10.0.0." + str(abs(hash(uid)) % 200)).json()
    return d["agent_id"], d["agent_token"]


def _cmd(m, aid, cmd="ping", params=None):
    cid, st = m.queue_command(aid, cmd, params, actor="alice")
    return cid


def test_results_ownership_enforced(cl, m):
    a, ta = _agent(cl, m, "ua", "A"); b, tb = _agent(cl, m, "ub", "B")
    cid = _cmd(m, a)
    cl.get("/commands", headers=H(ta))                                           # A fetches -> running
    r = cl.post("/results", json={"command_id": cid, "status": "done", "findings": [
        {"category": "x", "check_name": "evil", "status": "PASS", "risk": "Info"}]}, headers=H(tb))
    assert r.status_code == 404
    c = m.db()
    assert c.execute("SELECT status FROM agent_commands WHERE id=?", (cid,)).fetchone()["status"] == "running"
    assert c.execute("SELECT COUNT(*) c FROM agent_findings").fetchone()["c"] == 0


def test_results_validation_and_sanitising(cl, m):
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a); cl.get("/commands", headers=H(ta))
    assert cl.post("/results", json={"command_id": cid, "status": "pwned"}, headers=H(ta)).status_code == 422
    big = "A" * 100000
    r = cl.post("/results", json={"command_id": cid, "status": "done", "result_id": "r1", "findings": [
        {"category": "c", "check_name": "n", "status": "weird", "risk": "SUPER", "details": big, "recommendation": "r", "mitre": "T1"}]},
        headers=H(ta))
    assert r.status_code == 200
    c = m.db(); row = c.execute("SELECT * FROM agent_findings").fetchone()
    assert row["status"] == "INFO" and row["risk"] == "Info"
    import af_vault
    d = af_vault.decrypt_text(row["details"], f"agent_findings.details|{a}")
    assert len(d) == 4000
    assert af_vault.decrypt_text(row["details"], "agent_findings.details|other").startswith("[encrypted")


def test_results_idempotent_and_no_double_complete(cl, m):
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a); cl.get("/commands", headers=H(ta))
    body = {"command_id": cid, "status": "done", "result_id": "same", "findings": [{"category": "c", "check_name": "n", "status": "FAIL", "risk": "High"}]}
    assert cl.post("/results", json=body, headers=H(ta)).json()["findings_saved"] == 1
    r2 = cl.post("/results", json=body, headers=H(ta)).json()
    assert r2.get("duplicate") is True
    c = m.db(); assert c.execute("SELECT COUNT(*) c FROM agent_findings").fetchone()["c"] == 1
    body["result_id"] = "different"
    assert cl.post("/results", json=body, headers=H(ta)).status_code == 409


def test_body_limits_and_gzip(cl, m, monkeypatch):
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a); cl.get("/commands", headers=H(ta))
    payload = json.dumps({"command_id": cid, "status": "done", "findings": []}).encode()
    r = cl.post("/results", content=gzip.compress(payload), headers={**H(ta), "Content-Encoding": "gzip", "Content-Type": "application/json"})
    assert r.status_code == 200
    bomb = gzip.compress(b"0" * (80 * 1024 * 1024))                                # > 64 MB when inflated
    r = cl.post("/results", content=bomb, headers={**H(ta), "Content-Encoding": "gzip", "Content-Type": "application/json"})
    assert r.status_code == 413
    r = cl.post("/results", content=b"x" * (65 * 1024 * 1024), headers={**H(ta), "Content-Type": "application/json"})
    assert r.status_code == 413


# ------------------------------------------------------------------ leases / commands
def test_lease_expiry_requeues_then_fails(cl, m):
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a)
    for attempt in range(1, m.MAX_ATTEMPTS + 1):
        got = cl.get("/commands", headers=H(ta)).json()["commands"]
        assert [x["id"] for x in got] == [cid]
        c = m.db(); c.execute("UPDATE agent_commands SET lease_until='2000-01-01T00:00:00+00:00' WHERE id=?", (cid,)); c.commit(); c.close()
    assert cl.get("/commands", headers=H(ta)).json()["commands"] == []
    c = m.db(); r = c.execute("SELECT status,summary FROM agent_commands WHERE id=?", (cid,)).fetchone()
    assert r["status"] == "failed" and "lease expired" in r["summary"]


def test_heartbeat_extends_lease(cl, m):
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a); cl.get("/commands", headers=H(ta))
    c = m.db(); c.execute("UPDATE agent_commands SET lease_until='2000-01-01T00:00:00+00:00' WHERE id=?", (cid,)); c.commit()
    cl.post("/heartbeat", json={}, headers=H(ta))
    assert c.execute("SELECT lease_until FROM agent_commands WHERE id=?", (cid,)).fetchone()["lease_until"] > "2001"


def test_commands_are_signed_and_expire(cl, m):
    import af_signing
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a, "run_file_scan", {"paths": ["/tmp"]})
    cmd = cl.get("/commands", headers=H(ta)).json()["commands"][0]
    pub = af_signing.public_pem(af_signing.CMD_KEY)
    msg = af_signing.command_message(a, cmd["id"], cmd["command"], cmd["params"], cmd["nonce"], cmd["issued"], cmd["expires"])
    assert af_signing.verify(pub, cmd["sig"], msg)
    cmd["params"]["paths"] = ["/etc"]
    msg2 = af_signing.command_message(a, cmd["id"], cmd["command"], cmd["params"], cmd["nonce"], cmd["issued"], cmd["expires"])
    assert not af_signing.verify(pub, cmd["sig"], msg2)


def test_long_poll_returns_empty_after_wait_and_instantly_with_work(cl, m):
    import time
    a, ta = _agent(cl, m, "ua", "A")
    t0 = time.time(); assert cl.get("/commands?wait=1", headers=H(ta)).json()["commands"] == []
    assert time.time() - t0 < 4
    _cmd(m, a); t0 = time.time()
    assert len(cl.get("/commands?wait=20", headers=H(ta)).json()["commands"]) == 1
    assert time.time() - t0 < 3


def test_param_validation_and_approval_workflow(cl, m):
    a, ta = _agent(cl, m, "ua", "A")
    with pytest.raises(ValueError): m.queue_command(a, "rm_rf", {})
    with pytest.raises(ValueError): m.queue_command(a, "ping", {"x": 1})
    with pytest.raises(ValueError): m.queue_command(a, "kill_process", {"pid": 1})
    with pytest.raises(ValueError): m.queue_command(a, "isolate_host", {"ttl_minutes": 99999})
    cid, st = m.queue_command(a, "kill_process", {"pid": 4242, "name": "evil"}, actor="alice")
    assert st == "awaiting_approval"
    assert cl.get("/commands", headers=H(ta)).json()["commands"] == []            # not delivered before approval
    with pytest.raises(ValueError): m.approve_command(cid, "alice")                # two-person rule
    m.approve_command(cid, "bob")
    assert cl.get("/commands", headers=H(ta)).json()["commands"][0]["id"] == cid
    cid2, _ = m.queue_command(a, "quarantine_file", {"path": "/tmp/x"}, actor="alice")
    m.deny_command(cid2, "bob")
    assert cl.get("/commands", headers=H(ta)).json()["commands"] == []


# ------------------------------------------------------------------ identity binding
class _Req:
    def __init__(self, fp): 
        class S: pass
        self.state = S(); self.state.peer_cert_fp = fp


def test_cert_binding_disabled_and_revocation(cl, m):
    from fastapi import HTTPException
    a, ta = _agent(cl, m, "ua", "A")
    c = m.db(); c.execute("UPDATE agents SET cert_fp='aa' WHERE id=?", (a,)); c.commit(); c.close()
    assert m.verify(ta, _Req("aa")) == a
    with pytest.raises(HTTPException): m.verify(ta, _Req("bb"))                    # stolen token + wrong cert
    with pytest.raises(HTTPException): m.verify(ta, _Req(None))                    # no cert at all
    m.revoke_agent_cert(a, "lost laptop")
    with pytest.raises(HTTPException): m.verify(ta, _Req("aa"))
    c = m.db(); c.execute("DELETE FROM revoked_certs"); c.execute("UPDATE agents SET cert_fp=NULL WHERE id=?", (a,)); c.commit(); c.close()
    assert m.verify(ta, None) == a
    m.set_agent_disabled(a, True)
    with pytest.raises(HTTPException): m.verify(ta, None)


def test_stats_is_agent_scoped(cl, m):
    a, ta = _agent(cl, m, "ua", "A"); _agent(cl, m, "ub", "B")
    assert set(cl.get("/stats", headers=H(ta)).json()) == {"agent_id", "pending"}


# ------------------------------------------------------------------ maintenance
def test_prune_and_audit_checkpoint(cl, m):
    a, ta = _agent(cl, m, "ua", "A")
    for i in range(8):
        m.audit("evt", a, "", str(i))
    c = m.db()
    c.execute("UPDATE api_audit SET ts='2000-01-01T00:00:00+00:00' WHERE id<=5")
    c.execute("INSERT INTO agent_findings (agent_id,command_id,timestamp) VALUES (?,?,?)", (a, 1, "2000-01-01T00:00:00+00:00"))
    for i in range(9):
        c.execute("INSERT INTO agent_inventory (agent_id,data,timestamp) VALUES (?,?,?)", (a, "d", m.utc_iso()))
    c.commit(); c.close()
    out = m.prune()
    assert out["findings"] == 1 and out["inventory"] == 9 - m.INVENTORY_KEEP and out["audit"] > 0
    assert m.verify_audit_chain()["ok"]


def test_rate_limit_dict_evicts_idle_ips(m):
    for i in range(50):
        m._rate_limit(f"1.1.1.{i}", limit=100)
    m._last_sweep[0] = 0
    import time
    for q in m._REG_HITS.values():
        q.clear(); q.append(time.time() - 1000)
    m._rate_limit("9.9.9.9", limit=100, window=60)
    assert len(m._REG_HITS) == 1


def test_artifact_upload_hash_checked(cl, m, afhome):
    a, ta = _agent(cl, m, "ua", "A")
    cid = _cmd(m, a, "collect_triage"); cl.get("/commands", headers=H(ta))
    data = b"PK-fake-zip" * 1000
    good = hashlib.sha256(data).hexdigest()
    assert cl.post(f"/artifacts/{cid}", content=data, headers={**H(ta), "X-Content-SHA256": "0" * 64}).status_code == 422
    r = cl.post(f"/artifacts/{cid}", content=data, headers={**H(ta), "X-Content-SHA256": good})
    assert r.status_code == 200 and r.json()["sha256"] == good
    c = m.db(); row = c.execute("SELECT * FROM custody_log").fetchone()
    assert row["sha256"] == good and row["row_hash"]
    import af_audit; assert af_audit.verify(m.DB_PATH, "custody_log")["ok"]
    b, tb = _agent(cl, m, "ub", "B")
    assert cl.post(f"/artifacts/{cid}", content=data, headers=H(tb)).status_code == 404   # not B's command
