import json, time
from datetime import datetime, timezone
import pytest
import af_scope as S

POL = {"allow": [], "deny": [], "max_hosts": 4096, "rate_per_sec": 0, "rate_per_host": 0, "require_ticket": False, "blackout": []}
def pol(**kw): return {**POL, **kw}
def fake_resolver(mapping):
    def r(host, _):
        if host not in mapping: raise OSError("nxdomain")
        return [(2, 1, 6, "", (a, 0)) for a in mapping[host]]
    return r


def test_huge_range_refused_before_allocation():
    import time as t
    t0 = t.time()
    with pytest.raises(S.ScopeError, match="16,777,214 hosts"): S.expand_ip_range("10.0.0.0/8", 4096)
    assert t.time() - t0 < 0.5                                         # counted, never expanded
    with pytest.raises(S.ScopeError): S.expand_ip_range("1.0.0.0-9.0.0.0", 4096)
    assert len(S.expand_ip_range("192.168.1.0/24", 4096)) == 254
    assert S.expand_ip_range("10.0.0.1-10.0.0.3") == ["10.0.0.1", "10.0.0.2", "10.0.0.3"]


def test_argument_injection_and_garbage_rejected():
    for bad in ("-f", "--help", "a b", "host;rm -rf /", "$(id)", "10.0.0.0/33", "", "10.0.0.5-10.0.0.1"):
        with pytest.raises(S.ScopeError): S.expand_ip_range(bad)
    assert S.expand_ip_range("db01.corp.local") == ["db01.corp.local"] and S.expand_ip_range("2001:db8::1") == ["2001:db8::1"]


def test_private_in_scope_public_needs_authorization():
    r = fake_resolver({"intranet": ["10.1.1.1"], "example.com": ["93.184.216.34"]})
    assert S.evaluate(["10.0.0.0/24", "intranet"], pol(), resolver=r).needs_authorization is False
    d = S.evaluate(["https://example.com/login"], pol(), resolver=r)
    assert d.allowed and d.needs_authorization and d.public_targets == ["https://example.com/login"]
    assert S.evaluate(["8.8.8.8"], pol(), resolver=r).needs_authorization
    assert S.evaluate(["ghost.invalid"], pol(), resolver=r).needs_authorization          # unresolvable = treated as external


def test_allow_and_deny_lists():
    r = fake_resolver({"app.corp.example": ["10.5.5.5"], "other.net": ["10.5.5.6"]})
    p = pol(allow=["10.0.0.0/8", "*.corp.example"], deny=["10.9.0.0/16", "secret.corp.example"])
    assert S.evaluate(["10.1.0.0/24", "app.corp.example"], p, resolver=r).allowed
    assert not S.evaluate(["192.168.0.0/24"], p, resolver=r).allowed
    d = S.evaluate(["10.9.1.1"], p, resolver=r); assert not d.allowed and "deny list" in d.reasons[0]
    assert not S.evaluate(["secret.corp.example"], p, resolver=fake_resolver({"secret.corp.example": ["10.5.5.9"]})).allowed
    assert not S.evaluate(["10.0.0.0/8"], pol(allow=["10.0.0.0/8"], max_hosts=100)).allowed       # inside scope but too big


def test_blackout_window():
    p = pol(blackout=[{"days": ["Mon"], "start": "08:00", "end": "18:00"}])
    mon_noon = datetime(2026, 10, 12, 12, 0, tzinfo=timezone.utc)          # a Monday
    assert S.in_blackout(p, mon_noon) and not S.in_blackout(p, datetime(2026, 10, 12, 20, 0, tzinfo=timezone.utc))
    assert not S.in_blackout(p, datetime(2026, 10, 13, 12, 0, tzinfo=timezone.utc))
    overnight = pol(blackout=[{"days": "*", "start": "22:00", "end": "06:00"}])
    assert S.in_blackout(overnight, datetime(2026, 10, 12, 23, 0, tzinfo=timezone.utc)) and S.in_blackout(overnight, datetime(2026, 10, 12, 3, 0, tzinfo=timezone.utc))
    assert not S.evaluate(["10.0.0.1"], p, now=mon_noon).allowed


def test_authorization_records(tmp_path):
    db = tmp_path / "h.db"
    with pytest.raises(S.ScopeError): S.record_authorization(db, "alice", "Web", ["https://x"], "ok")
    with pytest.raises(S.ScopeError): S.record_authorization(db, "alice", "Web", ["https://x"], "pentest SOW 2026-17", "", pol(require_ticket=True))
    rid = S.record_authorization(db, "alice", "Web", ["https://x"], "customer pentest per SOW 2026-17", "CHG-100", pol(require_ticket=True))
    row = S.list_authorizations(db)[0]
    assert row["id"] == rid and row["ticket"] == "CHG-100" and row["ts"].endswith("+00:00")


def test_policy_from_env_and_file(afhome, monkeypatch):
    (afhome / "scope.json").write_text(json.dumps({"allow": ["10.0.0.0/8"], "max_hosts": 50}))
    assert S.load_policy()["max_hosts"] == 50
    monkeypatch.setenv("AF_MAX_SCAN_HOSTS", "10"); monkeypatch.setenv("AF_SCAN_ALLOW", "172.16.0.0/12, *.lab")
    p = S.load_policy(); assert p["max_hosts"] == 10 and p["allow"] == ["172.16.0.0/12", "*.lab"]


def test_rate_limiter_enforces_rate():
    rl = S.RateLimiter(50, burst=1)
    t0 = time.monotonic()
    for _ in range(11): rl.acquire()
    assert time.monotonic() - t0 >= 0.18                                    # ~10 intervals of 20 ms
    t0 = time.monotonic()
    for _ in range(1000): S.RateLimiter(0).acquire()
    assert time.monotonic() - t0 < 0.1                                      # rate 0 = unlimited


def test_throttle_per_host(afhome, monkeypatch):
    monkeypatch.setenv("AF_SCAN_RATE_PER_HOST", "20"); S.reset_limits()
    t0 = time.monotonic()
    for _ in range(30): S.throttle("10.0.0.1")        # burst of 20, then 20/s
    assert time.monotonic() - t0 >= 0.4
    t0 = time.monotonic()
    for i in range(15): S.throttle(f"10.0.1.{i}")                           # different hosts do not share a bucket
    assert time.monotonic() - t0 < 0.1
    S.reset_limits()


def test_get_authorization_and_whatsapp_record(tmp_path):
    db = tmp_path / "h.db"
    rid = S.record_authorization(db, "alice", "Web", ["https://x"], "customer pentest per SOW 2026-17")
    row = S.get_authorization(db, rid)
    assert row["id"] == rid and row["username"] == "alice" and row["whatsapp_status"] is None
    assert S.get_authorization(db, 999) is None
    S.record_whatsapp_send(db, rid, "15551234567", "ok: template", "deadbeef")
    row = S.get_authorization(db, rid)
    assert row["whatsapp_to"] == "15551234567" and row["whatsapp_status"] == "ok: template" and row["pdf_sha256"] == "deadbeef"
    assert row["whatsapp_sent_at"].endswith("+00:00")
    S.record_whatsapp_send(db, rid, "15551234567", "FAILED: HTTP 401", "")
    assert S.get_authorization(db, rid)["pdf_sha256"] == "deadbeef"             # empty hash does not clobber the earlier one


def test_host_denied():
    p = pol(deny=["10.9.0.0/16", "secret.corp.example"])
    assert S.host_denied("x", ["10.9.1.1"], p) and S.host_denied("secret.corp.example", [], p)
    assert not S.host_denied("api.corp.example", ["10.1.1.1"], p)
    assert S.host_denied("x", [], None) is False       # default policy (empty deny list) -> never denied
