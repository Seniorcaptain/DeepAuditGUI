import hashlib
import pytest
import af_consent as C, af_whatsapp as W


RECORD = {"id": 7, "ts": "2026-10-13T10:00:00+00:00", "username": "alice", "scan_type": "Web Application",
          "targets": ["https://example.com"], "reason": "customer pentest per SOW 2026-17, owner approval on file", "ticket": "CHG-100"}


def test_canonical_text_is_deterministic_and_order_stable():
    a = C.canonical_text(RECORD)
    b = C.canonical_text(dict(RECORD))
    assert a == b
    changed = dict(RECORD, reason="different reason")
    assert C.canonical_text(changed) != a
    assert "targets: https://example.com" in a                 # list -> comma text, not repr


def test_sign_and_verify_roundtrip_and_tamper_detection(afhome):
    sig, pub, digest = C.sign_record(RECORD)
    assert C.verify_record(RECORD, sig, pub)
    assert digest == hashlib.sha256(C.canonical_text(RECORD).encode()).hexdigest()
    tampered = dict(RECORD, targets=["https://evil.example.com"])
    assert not C.verify_record(tampered, sig, pub)
    assert not C.verify_record(RECORD, sig, pub.replace("A", "B", 1))


def test_build_pdf_is_a_real_pdf_and_contains_the_record(afhome, tmp_path):
    assert C.pdf_available()
    data = C.build_pdf(RECORD, generated_by="alice")
    assert data[:4] == b"%PDF" and len(data) > 500
    f = tmp_path / "c.pdf"
    f.write_bytes(data)
    from pypdf import PdfReader
    text = "\n".join(p.extract_text() or "" for p in PdfReader(str(f)).pages)
    assert "#7" in text and "alice" in text and "CHG-100" in text and "example.com" in text and "Ed25519" in text


def test_build_pdf_escapes_html_special_characters(afhome):
    hostile = dict(RECORD, reason="<script>alert(1)</script> & \"quoted\"", username="bob<3")
    data = C.build_pdf(hostile)
    assert data[:4] == b"%PDF"                                  # must not raise / corrupt the XML markup reportlab parses internally


def test_pdf_requires_reportlab_message(monkeypatch):
    monkeypatch.setattr(C, "HAS_REPORTLAB", False)
    with pytest.raises(RuntimeError, match="reportlab"):
        C.build_pdf(RECORD)


# ------------------------------------------------------------------ WhatsApp
def test_normalize_and_mask_number():
    assert W.normalize_number("+1 (555) 123-4567") == "15551234567"
    assert W.normalize_number("15551234567") == "15551234567"
    assert W.normalize_number("12") is None and W.normalize_number("not a number") is None
    assert W.mask_number("+1 555 123 4567") == "*******4567"


def test_wa_me_link():
    assert W.wa_me_link("+1 555 123 4567") == "https://wa.me/15551234567"
    assert W.wa_me_link("+1 555 123 4567", "hello there") == "https://wa.me/15551234567?text=hello%20there"
    assert W.wa_me_link("bad") == ""


def test_not_configured_and_bad_number(monkeypatch):
    for k in ("AF_WHATSAPP_TOKEN", "AF_WHATSAPP_PHONE_ID", "AF_WHATSAPP_TEMPLATE"):
        monkeypatch.delenv(k, raising=False)
    r = W.send_consent_pdf("+15551234567", b"%PDF-1.4...")
    assert not r["ok"] and "not configured" in r["detail"]
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "t"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "123")
    r = W.send_consent_pdf("abc", b"%PDF")
    assert not r["ok"] and "does not look like a phone number" in r["detail"]


class R:
    def __init__(s, code=200, js=None, text=""): s.status_code, s._js, s.text = code, js or {}, text or str(js)
    def json(s): return s._js


class Http:
    def __init__(s, upload=R(200, {"id": "MEDIA1"}), send=R(200, {"messages": [{"id": "wamid.ABC"}]})):
        s.calls, s.upload, s.send = [], upload, send
    def post(s, url, **kw):
        s.calls.append((url, kw))
        return s.upload if url.endswith("/media") else s.send


def test_session_send_success(monkeypatch):
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "tok123"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "999")
    monkeypatch.delenv("AF_WHATSAPP_TEMPLATE", raising=False)
    h = Http()
    r = W.send_consent_pdf("+1 555 123 4567", b"%PDF-data", "scan_consent.pdf", "A scan consent record", http=h)
    assert r == {"ok": True, "detail": "", "message_id": "wamid.ABC", "method": "session"}
    media_call, msg_call = h.calls
    assert media_call[0].endswith("/999/media") and media_call[1]["files"]["file"][0] == "scan_consent.pdf"
    assert media_call[1]["headers"]["Authorization"] == "Bearer tok123"
    assert msg_call[1]["json"]["document"] == {"id": "MEDIA1", "filename": "scan_consent.pdf", "caption": "A scan consent record"}
    assert msg_call[1]["json"]["to"] == "15551234567"


def test_template_send_used_when_configured(monkeypatch):
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "t"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "1")
    monkeypatch.setenv("AF_WHATSAPP_TEMPLATE", "scan_consent_pdf"); monkeypatch.setenv("AF_WHATSAPP_TEMPLATE_LANG", "en_GB")
    h = Http()
    r = W.send_consent_pdf("+15551234567", b"%PDF", body_params=["Alice", "Web Application"], http=h)
    assert r["ok"] and r["method"] == "template"
    payload = h.calls[1][1]["json"]
    assert payload["template"] == {"name": "scan_consent_pdf", "language": {"code": "en_GB"},
                                   "components": [{"type": "header", "parameters": [{"type": "document", "document": {"id": "MEDIA1", "filename": "scan_consent.pdf"}}]},
                                                  {"type": "body", "parameters": [{"type": "text", "text": "Alice"}, {"type": "text", "text": "Web Application"}]}]}


def test_upload_failure_reported_and_message_never_sent(monkeypatch):
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "t"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "1")
    h = Http(upload=R(401, text="invalid token"))
    r = W.send_consent_pdf("+15551234567", b"%PDF", http=h)
    assert not r["ok"] and "upload failed" in r["detail"] and "401" in r["detail"]
    assert len(h.calls) == 1                                     # never tried to send a message with no media id


def test_send_failure_reported(monkeypatch):
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "t"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "1")
    h = Http(send=R(400, {"error": {"message": "Recipient has not opted in"}}))
    r = W.send_consent_pdf("+15551234567", b"%PDF", http=h)
    assert not r["ok"] and "400" in r["detail"] and r["message_id"] == ""


def test_network_exception_is_caught(monkeypatch):
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "t"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "1")
    class Boom:
        def post(s, *a, **k): raise ConnectionError("dns failure")
    r = W.send_consent_pdf("+15551234567", b"%PDF", http=Boom())
    assert not r["ok"] and "dns failure" in r["detail"]


def test_token_never_appears_in_detail_text(monkeypatch):
    monkeypatch.setenv("AF_WHATSAPP_TOKEN", "super-secret-token-value"); monkeypatch.setenv("AF_WHATSAPP_PHONE_ID", "1")
    h = Http(upload=R(401, text="super-secret-token-value leaked in error"))
    r = W.send_consent_pdf("+15551234567", b"%PDF", http=h)
    # the module itself never echoes the token into a message it builds; whatever the server chose to echo back is
    # the server's business, but our own code paths (headers we construct) are not logged anywhere here
    assert h.calls[0][1]["headers"]["Authorization"] == "Bearer super-secret-token-value"
