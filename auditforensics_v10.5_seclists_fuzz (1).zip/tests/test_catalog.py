from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
import sys
import pytest
import af_catalog as K, af_checks as C


@pytest.fixture(autouse=True)
def fresh(afhome):
    K.reload(); yield; K.reload()


def test_every_check_gets_a_stable_id_even_when_uncatalogued():
    assert K.resolve_id("Totally New", "Thing 42") == C.make_check_id("Totally New", "Thing 42")


def test_catalogued_check_resolves_and_enriches():
    r = {"Category": "SSH", "Check": "SSH Root Login", "Details": "x", "Recommendation": "", "MITRE": "", "Framework": "CIS:5.2.8"}
    K.enrich(r)
    assert r["CheckID"].startswith("AF-SSH") and "NIST-800-53:AC-6,AC-17" in r["Framework"] and "CIS:5.2.8" in r["Framework"]
    assert K.enrich(dict(r))["Framework"] == r["Framework"]                                 # idempotent


def test_user_catalog_overrides_and_regex_match(afhome):
    d = afhome / "catalog.d"; d.mkdir()
    (d / "mine.yaml").write_text("""
- id: ORG-0001
  category: Network
  match: ["re:^Network\\\\|Risky Port"]
  remediation: Close it per ORG-SEC-12.
  frameworks: {ISO-27001: ["A.8.20"]}
  cis_benchmark: "CIS 3.5.1"
  stig: V-1234
""")
    K.reload()
    r = K.enrich({"Category": "Network", "Check": "Risky Port 21 (FTP)", "Recommendation": ""})
    assert r["CheckID"] == "ORG-0001" and r["Recommendation"] == "Close it per ORG-SEC-12."
    assert "ISO-27001:A.8.20" in r["Framework"] and "CIS-Benchmark:CIS 3.5.1" in r["Framework"] and "DISA-STIG:V-1234" in r["Framework"]


def test_catalog_in_repo_is_complete():
    import subprocess
    r = subprocess.run([sys.executable, str(ROOT / "tools/gen_catalog.py"), "--check"], capture_output=True, text=True, cwd=ROOT)
    assert r.returncode == 0, r.stdout


def test_bad_yaml_is_ignored(afhome):
    d = afhome / "catalog.d"; d.mkdir(); (d / "bad.yaml").write_text("{{{ not yaml")
    K.reload(); assert K.resolve_id("A", "b")
