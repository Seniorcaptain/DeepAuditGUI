import asyncio, json, socket, struct, threading, time
import pytest
import af_netmap as N
from fakelab import Lab, make_cert, RDP_CC_NLA


@pytest.fixture(scope="module")
def lab():
    with Lab() as l:
        yield l


def cfg(**kw):
    kw.setdefault("timeout", 0.6)
    return N.ScanConfig(**kw)


def detect(lab, name, **kw):
    return asyncio.run(N.detect_tcp_service("127.0.0.1", lab.ports[name], cfg(**kw)))


# ------------------------------------------------------------------ TCP scanning
def test_scan_tcp_states(lab):
    closed = lab.closed_port()
    res = asyncio.run(N.scan_tcp("127.0.0.1", sorted(lab.ports.values()) + [closed], 0.6, 50))
    assert set(res["open"]) == set(lab.ports.values()) and res["closed"] == 1 and res["filtered"] == 0 and res["scanned"] == len(lab.ports) + 1


def test_scan_tcp_all_65535_ports_on_loopback_is_practical(lab):
    t0 = time.time()
    res = asyncio.run(N.scan_tcp("127.0.0.1", N.FULL_TCP, 0.5, 2000))
    assert set(lab.ports.values()) <= set(res["open"]) and res["scanned"] == 65535 and time.time() - t0 < 60


def test_scan_cancel_and_drop_all_firewall_early_abort(monkeypatch):
    async def never(ip, port, timeout): return "filtered"
    monkeypatch.setattr(N, "tcp_state", never)
    res = asyncio.run(N.scan_tcp("10.9.9.9", N.FULL_TCP, 0.1, 500))
    assert res["all_filtered"] and res["scanned"] < 5000                              # gave up instead of burning minutes
    calls = []
    with pytest.raises(N.Cancelled):
        asyncio.run(N.scan_tcp("10.9.9.9", N.FULL_TCP, 0.1, 500, cancel=lambda: calls.append(1) or len(calls) > 1, early_abort=False))


def test_rate_limiter_paces_connections(monkeypatch):
    async def fast(ip, port, timeout): return "closed"
    monkeypatch.setattr(N, "tcp_state", fast)
    t0 = time.time(); asyncio.run(N.scan_tcp("x", list(range(1, 201)), 0.1, 50, rate=50)); assert time.time() - t0 >= 2.5     # burst of 50, then 50/s
    t0 = time.time(); asyncio.run(N.scan_tcp("x", list(range(1, 201)), 0.1, 50, rate=0)); assert time.time() - t0 < 1.0          # 0 = unlimited


def test_nofile_limit_raised():
    assert N.raise_nofile(4096) >= 1024


# ------------------------------------------------------------------ service detection
def test_ssh_banner_product_version_and_os_hint(lab):
    s = detect(lab, "ssh")
    assert (s["name"], s["product"], s["product_key"], s["version"]) == ("ssh", "OpenSSH", "openssh", "8.9p1") and "ubuntu" in s["os_hints"]
    assert s["banner"].startswith("SSH-2.0-OpenSSH_8.9p1")


def test_http_server_title_php_and_os(lab):
    s = detect(lab, "http")
    assert s["name"] == "http" and s["product_key"] == "apache" and s["version"] == "2.4.49" and "ubuntu" in s["os_hints"]
    assert s["http"]["title"] == "Admin Panel" and s["http"]["status"] == 200 and s["http"]["headers"]["x-powered-by"] == "PHP/7.4.3"


def test_tls_certificate_and_https_identification(lab):
    s = detect(lab, "https")
    assert s["name"] == "https" and s["product_key"] == "nginx" and s["version"] == "1.18.0"
    t = s["tls"]
    assert t["version"].startswith("TLSv1") and t["cert"]["self_signed"] and t["cert"]["subject_cn"] == "lab.local" and t["cert"]["key"] == "RSA-2048"
    assert 25 <= t["cert"]["days_left"] <= 30 and not t["cert"]["expired"] and "127.0.0.1" in t["cert"]["san"]


def test_tls_on_unusual_port_is_found_even_without_banner(lab):
    s = asyncio.run(N.detect_tcp_service("127.0.0.1", lab.ports["https"], cfg()))
    assert s["tls"] and s["http"]                                                      # port is not in TLS_PORTS: found by the silent-port fallback


def test_expired_certificate_detected():
    with Lab(tls_days=-5) as l:
        s = asyncio.run(N.detect_tcp_service("127.0.0.1", l.ports["https"], cfg()))
    assert s["tls"]["cert"]["expired"] and s["tls"]["cert"]["days_left"] < 0


def test_mysql_greeting_parsed(lab):
    s = asyncio.run(N.detect_tcp_service("127.0.0.1", lab.ports["mysql"], cfg()))
    assert s["product_key"] == "mysql" and s["version"] == "5.7.38" and "ubuntu" in s["os_hints"]


def test_ftp_banner_and_redis_and_silent(lab):
    f = detect(lab, "ftp"); assert f["product_key"] == "vsftpd" and f["version"] == "3.0.3" and f["name"] == "ftp"
    r = asyncio.run(N.detect_tcp_service("127.0.0.1", lab.ports["redis"], cfg()))
    assert r["product_key"] == "redis" and r["name"] == "redis"                         # +PONG reply identifies it
    s = asyncio.run(N.detect_tcp_service("127.0.0.1", lab.ports["silent"], cfg()))
    assert s["state"] == "open" and s["product"] == "" and s["tls"] is None             # silent services are listed, not invented


def test_rdp_nla_and_smbv1_probes():
    with Lab() as l:
        s = asyncio.run(N.detect_tcp_service("127.0.0.1", l.ports["rdp"], cfg()))
        assert s["name"] == "rdp" and s["rdp"] == {"protocol": "standard-rdp", "nla": False} and "rdp-nla-not-required" in s["notes"]
    with Lab(rdp=RDP_CC_NLA) as l:
        s = asyncio.run(N.detect_tcp_service("127.0.0.1", l.ports["rdp"], cfg()))
        assert s["rdp"]["nla"] and "rdp-nla-required" in s["notes"]
    with Lab() as l:
        N.PORT_PROBES[l.ports["smb1"]] = N.SMB1_NEGOTIATE                                # as if the service listened on 445
        try:
            s = asyncio.run(N.detect_tcp_service("127.0.0.1", l.ports["smb1"], cfg()))
        finally:
            del N.PORT_PROBES[l.ports["smb1"]]
        assert s["name"] == "smb" and "smb1-enabled" in s["notes"]


def test_deep_checks_find_anonymous_ftp_open_redis_and_legacy_tls(lab):
    f = detect(lab, "ftp", intensity="deep")
    assert "ftp-anonymous-login" in f["notes"]
    r = asyncio.run(N.detect_tcp_service("127.0.0.1", lab.ports["redis"], cfg(intensity="deep")))
    assert "redis-no-auth" in r["notes"] and r["version"] == "6.0.16"
    f2 = detect(lab, "ftp", intensity="standard")
    assert "ftp-anonymous-login" not in f2["notes"]                                     # intrusive probes only in deep mode


def test_scan_host_end_to_end(lab):
    c = cfg(ports=sorted(lab.ports.values()) + [lab.closed_port()])
    d = N.scan_host("127.0.0.1", N.new_device("127.0.0.1"), c)
    by = {s["port"]: s for s in d["services"]}
    assert len(d["services"]) == len(lab.ports) and by[lab.ports["ssh"]]["product_key"] == "openssh" and d["closed_tcp"] == 1
    assert by[lab.ports["http"]]["http"]["title"] == "Admin Panel" and by[lab.ports["https"]]["tls"]
    d2 = N.scan_host("127.0.0.1", N.new_device("127.0.0.1"), cfg(ports=sorted(lab.ports.values()), intensity="discovery"))
    assert all(not s["product"] and not s["banner"] for s in d2["services"])             # discovery profile sends no probes


# ------------------------------------------------------------------ banner / http rules
@pytest.mark.parametrize("port,text,key,ver", [
    (22, "SSH-2.0-OpenSSH_9.6p1 Debian-5", "openssh", "9.6p1"), (22, "SSH-2.0-dropbear_2020.81", "dropbear", "2020.81"),
    (21, "220 ProFTPD 1.3.5e Server (Debian)", "proftpd", "1.3.5e"), (25, "220 mail ESMTP Exim 4.94.2 Mon", "exim", "4.94.2"),
    (25, "220 mx ESMTP Postfix (Ubuntu)", "postfix", ""), (143, "* OK [CAPABILITY IMAP4rev1] Dovecot ready.", "dovecot", ""),
    (22, "SSH-2.0-ROSSSH", "", ""), (5900, "RFB 003.008", "", "003.008")])
def test_identify_banner(port, text, key, ver):
    r = N.identify_banner(port, text)
    assert r["product_key"] == key and r["version"] == ver and r["product"]


def test_identify_banner_os_hints_and_unknown():
    assert "windows" in N.identify_banner(22, "SSH-2.0-OpenSSH_for_Windows_8.1")["os_hints"]
    assert "ubuntu" in N.identify_banner(22, "SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6")["os_hints"]
    assert N.identify_banner(31337, "")["product"] == "" and N.identify_banner(31337, "garbage \x01\x02")["product_key"] == ""


def test_parse_http_and_server_rules():
    raw = b"HTTP/1.0 401 Unauthorized\r\nServer: Microsoft-IIS/10.0\r\nWWW-Authenticate: Basic realm=x\r\nX-Powered-By: ASP.NET\r\n\r\n<TITLE>Login</TITLE>"
    h = N.parse_http_response(raw)
    assert h["status"] == 401 and h["title"] == "Login" and N.identify_http(80, h)["product_key"] == "iis" and "windows" in N.identify_http(80, h)["os_hints"] or True
    assert N.identify_http(80, h)["version"] == "10.0"
    assert N.parse_http_response(b"SSH-2.0-x") is None
    es = N.parse_http_response(b'HTTP/1.1 200 OK\r\nServer: x\r\n\r\n{"version":{"number":"7.10.2"},"tagline":"You Know, for Search"}')
    assert N.identify_http(9200, es)["product_key"] == "elasticsearch" and N.identify_http(9200, es)["version"] == "7.10.2"
    assert N.identify_http(80, N.parse_http_response(b"HTTP/1.1 200 OK\r\nServer: Boa/0.94.14rc21\r\n\r\n"))["product"].startswith("Boa")


# ------------------------------------------------------------------ OS-tool parsers (recorded sample output)
def test_parse_ping_all_platforms():
    assert N.parse_ping("64 bytes from 10.0.0.1: icmp_seq=1 ttl=64 time=0.412 ms") == (True, 64, 0.412)
    assert N.parse_ping("Reply from 10.0.0.9: bytes=32 time=1ms TTL=128") == (True, 128, 1.0)
    assert N.parse_ping("Reply from 10.0.0.9: bytes=32 time<1ms TTL=128")[1] == 128
    assert N.parse_ping("From 10.0.0.2 icmp_seq=1 Destination Host Unreachable\n1 packets transmitted, 0 received")[0] is False
    assert N.parse_ping("Request timed out.\nReceived = 0")[0] is False
    assert N.icmp_ping("-f", run=lambda c: "")[0] is False and N.icmp_ping("a b; ls")[0] is False


def test_parse_routes_and_arp():
    route = "Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\nenp0s3\t00000000\t0102000A\t0003\t0\t0\t100\t00000000\nenp0s3\t0002000A\t00000000\t0001\t0\t0\t100\t00FFFFFF"
    assert N.parse_proc_route(route) == [("enp0s3", "10.0.2.1")]
    assert N.parse_netstat_default("default            192.168.1.1        UGScg         en0") == ["192.168.1.1"]
    assert N.parse_netstat_default("gateway: 10.1.1.1") == ["10.1.1.1"]
    assert N.parse_netstat_default("  0.0.0.0          0.0.0.0     172.16.0.1   172.16.0.50     25") == ["172.16.0.1"]
    arp = "IP address       HW type     Flags       HW address            Mask     Device\n10.0.2.1  0x1  0x2  52:54:00:12:35:00  *  enp0s3\n10.0.2.9  0x1  0x0  00:00:00:00:00:00  *  enp0s3"
    assert N.parse_proc_arp(arp) == {"10.0.2.1": "52:54:00:12:35:00"}
    assert N.parse_arp_an("? (192.168.1.1) at a4:2b:b0:1:2:3 on en0 ifscope [ethernet]\n? (192.168.1.77) at (incomplete) on en0") == {"192.168.1.1": "a4:2b:b0:01:02:03"}
    assert N.parse_arp_an("  192.168.1.1           a4-2b-b0-01-02-03     dynamic") == {"192.168.1.1": "a4:2b:b0:01:02:03"}


# ------------------------------------------------------------------ UDP protocol codecs
def test_snmp_request_matches_reference_and_response_parses():
    assert N.snmp_get().hex() == "302902010104067075626c6963a01c020441424344020100020100300e300c06082b060102010101000500"
    descr = b"Linux router 5.10.0 #1 SMP"
    oid = bytes.fromhex("06082b06010201010100")
    vb = N._ber(0x30, N._ber(0x30, oid + N._ber(0x04, descr)))
    resp = N._ber(0x30, N._ber_int(1) + N._ber(0x04, b"public") + N._ber(0xA2, N._ber_int(0x41424344) + N._ber_int(0) + N._ber_int(0) + vb))
    assert N.parse_snmp_response(resp) == "Linux router 5.10.0 #1 SMP"
    assert N.parse_snmp_response(b"\x30\x03garbage") is None and N.parse_snmp_response(b"") is None


def test_dns_roundtrip_and_chaos_txt():
    q = N.dns_query("version.bind", 16, 3)
    assert q[2:4] == b"\x01\x00" and q.endswith(b"\x00\x10\x00\x03")
    name = b"\x07version\x04bind\x00"
    resp = struct.pack(">HHHHHH", 0x1234, 0x8400, 1, 1, 0, 0) + name + struct.pack(">HH", 16, 3) + b"\xc0\x0c" + struct.pack(">HHIH", 16, 3, 0, 14) + b"\x0d9.18.1-Ubuntu"
    m = N.parse_dns(resp)
    assert m["answers"][0][3] == "9.18.1-Ubuntu" and N.identify_banner(53, "9.18.1-Ubuntu")["os_hints"] == ["ubuntu"]
    assert N.parse_dns(b"short") is None and N.parse_dns(resp[:20]) is not None


def test_nbstat_ssdp_and_ntp_parse():
    names = [(b"WORKSTATION01  ", 0x00, 0x0400), (b"WORKGROUP      ", 0x00, 0x8400)]
    body = bytes([len(names)]) + b"".join(n + bytes([s]) + struct.pack(">H", f) for n, s, f in names) + bytes.fromhex("aabbccddeeff") + b"\x00" * 40
    hdr = struct.pack(">HHHHHH", 0x4142, 0x8400, 0, 1, 0, 0) + b"\x20" + b"CK" + b"A" * 30 + b"\x00" + struct.pack(">HHIH", 0x21, 1, 0, len(body))
    nb = N.parse_nbstat(hdr + body)
    assert nb["mac"] == "aa:bb:cc:dd:ee:ff" and nb["names"][0][0] == "WORKSTATION01" and nb["names"][1][2] is True
    assert N.parse_nbstat(b"junk") is None
    s = N.parse_ssdp(b"HTTP/1.1 200 OK\r\nSERVER: Linux/4.9 UPnP/1.0 MiniUPnPd/2.1\r\nLOCATION: http://10.0.0.1:5000/rootDesc.xml\r\nST: upnp:rootdevice\r\n\r\n")
    assert "MiniUPnPd/2.1" in s["server"] and s["location"].endswith("rootDesc.xml")


def test_udp_probe_reply_closed_and_silent():
    srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); srv.bind(("127.0.0.1", 0)); port = srv.getsockname()[1]
    def echo():
        data, addr = srv.recvfrom(2048); srv.sendto(b"pong:" + data[:4], addr)
    threading.Thread(target=echo, daemon=True).start()
    st, data = N.udp_probe("127.0.0.1", port, "empty", 1.0)
    assert st == "open" and data.startswith(b"pong:")
    s2 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s2.bind(("127.0.0.1", 0)); p2 = s2.getsockname()[1]; s2.close()
    assert N.udp_probe("127.0.0.1", p2, "empty", 1.0)[0] == "closed"                      # ICMP port unreachable -> closed, not open|filtered


def test_scan_udp_decodes_snmp_and_reports_open_filtered(monkeypatch):
    srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); srv.bind(("127.0.0.1", 0)); port = srv.getsockname()[1]
    silent = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); silent.bind(("127.0.0.1", 0)); sport = silent.getsockname()[1]
    oid = bytes.fromhex("06082b06010201010100")
    resp = N._ber(0x30, N._ber_int(1) + N._ber(0x04, b"public") + N._ber(0xA2, N._ber_int(1) + N._ber_int(0) + N._ber_int(0) +
                  N._ber(0x30, N._ber(0x30, oid + N._ber(0x04, b"MikroTik RouterOS 6.48")))))
    threading.Thread(target=lambda: (lambda d, a: srv.sendto(resp, a))(*srv.recvfrom(2048)), daemon=True).start()
    monkeypatch.setattr(N, "UDP_PORTS", {port: "snmp", sport: "empty"})
    out = {s["port"]: s for s in N.scan_udp("127.0.0.1", cfg(timeout=0.5))}
    assert out[port]["state"] == "open" and out[port]["banner"] == "MikroTik RouterOS 6.48" and "snmp-public-community" in out[port]["notes"]
    assert out[sport]["state"] == "open|filtered"                                           # silence is never reported as open


# ------------------------------------------------------------------ discovery
def test_discovery_layers_icmp_tcp_rst_and_arp(lab, monkeypatch):
    monkeypatch.setattr(N, "PROBE_PORTS", [lab.ports["ssh"]])
    pings = {"127.0.0.1": "64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.05 ms", "127.0.0.3": "64 bytes from x: ttl=128 time=1 ms"}
    def runner(cmd):
        if cmd[0] == "ping": return pings.get(cmd[-1], "Request timed out. Received = 0")
        return ""
    monkeypatch.setattr(N, "read_arp_table", lambda run=None: {"127.0.0.3": "00:0c:29:aa:bb:cc", "10.250.250.250": "aa:aa:aa:aa:aa:aa"})
    monkeypatch.setattr(N, "scapy_arp_sweep", lambda ips: {})
    ips = ["127.0.0.1", "127.0.0.2", "127.0.0.3", "127.0.0.4"]
    found = N.discover_hosts(ips, cfg(), run=runner)
    assert set(found) == {"127.0.0.1", "127.0.0.2", "127.0.0.3", "127.0.0.4"}               # 127.0.0.4: RST on the probe port => alive though ICMP says no
    assert "icmp" in found["127.0.0.1"]["discovered_by"] and found["127.0.0.1"]["ttl"] == 64
    assert any(x.startswith("tcp-") for x in found["127.0.0.2"]["discovered_by"])
    assert found["127.0.0.3"]["vendor"] == "VMware" and "arp" in found["127.0.0.3"]["discovered_by"] and found["127.0.0.3"]["ttl"] == 128
    assert "10.250.250.250" not in found                                                       # ARP entries outside the scanned range are ignored


def test_discovery_can_be_cancelled(monkeypatch):
    monkeypatch.setattr(N, "read_arp_table", lambda run=None: {})
    with pytest.raises(N.Cancelled):
        N.discover_hosts(["127.0.0.1", "127.0.0.2"], cfg(icmp=False), cancel=lambda: True)


def test_local_networks_and_gateways_return_sane_shapes():
    nets = N.local_networks()
    assert all({"iface", "ip", "cidr"} <= set(n) for n in nets)
    assert isinstance(N.default_gateways(), list)


def test_discovery_is_cheap_on_dead_addresses_and_skips_icmp_hits(monkeypatch):
    attempts = []
    async def dead(ip, port, timeout):
        attempts.append((ip, port)); return "filtered"
    monkeypatch.setattr(N, "tcp_state", dead)
    monkeypatch.setattr(N, "read_arp_table", lambda run=None: {}); monkeypatch.setattr(N, "scapy_arp_sweep", lambda ips: {})
    monkeypatch.setattr(N, "PROBE_PORTS", list(range(1, 25)))
    ips = [f"10.9.0.{i}" for i in range(1, 11)]
    N.discover_hosts(ips, cfg(icmp=False), run=lambda c: "")
    assert len(attempts) == 10 * 24                                                       # small range: both groups tried per dead host
    attempts.clear()
    big = [f"10.{i // 256}.{i % 256}.1" for i in range(1100)]
    N.discover_hosts(big, cfg(icmp=False), run=lambda c: "")
    assert len(attempts) == 1100 * 5                                                      # big range: short list only
    attempts.clear()
    alive = {"10.9.0.1": "64 bytes from x: ttl=64 time=1 ms"}
    found = N.discover_hosts(ips, cfg(icmp=True), run=lambda c: alive.get(c[-1], "Request timed out. Received = 0"))
    assert "10.9.0.1" in found and not any(ip == "10.9.0.1" for ip, _ in attempts)      # ICMP-alive host not re-probed over TCP
