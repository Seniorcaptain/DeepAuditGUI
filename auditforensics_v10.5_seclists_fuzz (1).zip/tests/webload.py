"""Load the engine half of auditforensics_web.py (everything before the Streamlit UI) without a Streamlit server."""
import os, sys, types
from unittest.mock import MagicMock
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / "auditforensics_web.py"
MARK = "# UI\n# ==========================================================================\nst.set_page_config"


class _St(types.ModuleType):
    def __init__(self):
        super().__init__("streamlit")
        self.session_state = {}
        self._stopped = False

    def cache_resource(self, *a, **k):
        return a[0] if a and callable(a[0]) else (lambda f: f)
    cache_data = cache_resource

    def stop(self):
        raise SystemExit("st.stop()")

    def __getattr__(self, name):
        m = MagicMock(name=f"st.{name}")
        setattr(self, name, m)
        return m


def load(home):
    os.environ.update(HOME=str(home), AF_HOME=str(Path(home) / ".auditforensics"), AF_HIBP="0", AF_INTEL="0", AF_SCHEDULER="0")
    sys.modules["streamlit"] = _St()
    for m in ("af_vault", "af_auth", "af_manager_api", "af_scope", "af_catalog", "af_integrations", "af_vuln", "af_audit", "af_util"):
        sys.modules.pop(m, None)
    import af_vault
    af_vault.HOME = Path(home) / ".auditforensics"; af_vault._cache.clear()
    src = SRC.read_text().split(MARK)[0]
    mod = types.ModuleType("afweb")
    mod.__file__ = str(SRC)
    sys.modules["afweb"] = mod
    exec(compile(src, str(SRC), "exec"), mod.__dict__)
    return mod
