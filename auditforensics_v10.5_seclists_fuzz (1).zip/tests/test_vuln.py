import json, sys
import pytest
import af_vuln as V


def test_cvss3_reference_vectors():
    assert V.cvss3_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H") == 9.8
    assert V.cvss3_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N") == 6.1
    assert V.cvss3_score("CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H") == 7.8
    assert V.cvss3_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:N") == 0.0
    assert V.cvss3_score("garbage") is None


def test_ecosystems():
    assert V.ecosystem_from_os_release({"ID": "debian", "VERSION_ID": "12"}) == "Debian:12"
    assert V.ecosystem_from_os_release({"ID": "ubuntu", "VERSION_ID": "22.04"}) == "Ubuntu:22.04:LTS"
    assert V.ecosystem_from_os_release({"ID": "ubuntu", "VERSION_ID": "23.10"}) == "Ubuntu:23.10"
    assert V.ecosystem_from_os_release({"ID": "alpine", "VERSION_ID": "3.19.1"}) == "Alpine:v3.19"
    assert V.ecosystem_from_os_release({"ID": "arch"}) is None


def test_priority_prefers_exploited_exposed_critical_assets():
    base = V.priority_score(7.5)
    assert V.priority_score(7.5, kev=True) > base + 2.5
    assert V.priority_score(7.5, epss=0.9) > V.priority_score(7.5, epss=0.01)
    assert V.priority_score(7.5, criticality="high", exposure="internet") > base + 2.4
    assert V.priority_score(7.5, criticality="low") < base
    assert 0 <= V.priority_score(10, True, 1, "critical", "internet") <= 10
    assert V.priority_label(9) == "Act now" and V.priority_label(3) == "Track"


VULN = {"id": "DSA-1-1", "aliases": ["CVE-2024-0001"], "summary": "openssl flaw",
        "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"}],
        "affected": [{"ranges": [{"type": "ECOSYSTEM", "events": [{"introduced": "0"}, {"fixed": "3.0.11-1~deb12u2"}]}]}]}


def test_parse_vuln_and_fallback_severity():
    p = V.parse_vuln(VULN)
    assert p["cves"] == ["CVE-2024-0001"] and p["cvss"] == 9.8 and p["severity"] == "Critical" and p["fixed"] == ["3.0.11-1~deb12u2"]
    q = V.parse_vuln({"id": "GHSA-x", "aliases": [], "database_specific": {"severity": "HIGH"}})
    assert q["severity"] == "High" and q["cvss"] == 8.0
    r = V.parse_vuln({"id": "DSA-2", "aliases": []}); assert r["severity"] == "Medium" and not r["severity_known"]


class R:
    def __init__(s, js, code=200): s._js, s.status_code = js, code
    def json(s): return s._js
    def raise_for_status(s): pass


class FakeOSV:
    def __init__(s): s.posts, s.gets = [], []
    def post(s, url, json=None, timeout=0):
        s.posts.append(json)
        res = []
        for q in json["queries"]:
            if q["package"]["name"] == "openssl" and "page_token" not in q:
                res.append({"vulns": [{"id": "DSA-1-1"}], "next_page_token": "p2"})
            elif q["package"]["name"] == "openssl":
                res.append({"vulns": [{"id": "DSA-1-2"}]})
            else:
                res.append({})
        return R({"results": res})
    def get(s, url, timeout=0):
        s.gets.append(url)
        i = url.rsplit("/", 1)[1]
        return R(VULN if i == "DSA-1-1" else {**VULN, "id": "DSA-1-2", "aliases": ["CVE-2024-0002"], "severity": []})


def test_osv_end_to_end_with_pagination_cache_and_source_names(afhome):
    osv = FakeOSV()
    inv = {"os_release": {"ID": "debian", "VERSION_ID": "12"},
           "packages": [{"name": "libssl3", "source": "openssl", "version": "3.0.9"}, {"name": "bash", "version": "5.2"}]}
    f = V.osv_findings(inv, {"criticality": "high", "exposure": "internet"}, kev={"CVE-2024-0002"}, epss={}, http=osv)
    assert osv.posts[0]["queries"][0]["package"] == {"name": "openssl", "ecosystem": "Debian:12"}        # source package name used
    assert len(osv.posts) == 2 and "page_token" in osv.posts[1]["queries"][0]                            # pagination followed
    assert len(f) == 1 and f[0]["check_name"] == "OSV: libssl3" and f[0]["risk"] == "Critical"
    assert "KEV" in f[0]["details"] and "fixed in 3.0.11-1~deb12u2" in f[0]["details"] and "Act now" in f[0]["details"]
    n_gets = len(osv.gets); V.osv_findings(inv, http=osv)
    assert len(osv.gets) == n_gets                                                                       # second run served from cache


def test_osv_skips_unsupported_or_empty(afhome):
    assert V.osv_findings({"os_release": {"ID": "arch"}, "packages": [{"name": "a", "version": "1"}]})[0]["status"] == "SKIPPED"
    assert V.osv_findings({"os_release": {"ID": "debian", "VERSION_ID": "12"}, "packages": []})[0]["status"] == "SKIPPED"


def test_epss_fn_is_applied_after_lookup(afhome):
    osv = FakeOSV()
    inv = {"os_release": {"ID": "debian", "VERSION_ID": "12"}, "packages": [{"name": "libssl3", "source": "openssl", "version": "3.0.9"}]}
    f = V.osv_findings(inv, http=osv, epss_fn=lambda cves: {c: (0.91, 0.99) for c in cves})
    assert "EPSS 0.91" in f[0]["details"]
