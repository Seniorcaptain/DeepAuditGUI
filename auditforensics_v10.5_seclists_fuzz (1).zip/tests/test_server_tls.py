import os, socket, ssl, sys, time
import pytest, requests


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


@pytest.fixture()
def tlsenv(afhome, tmp_path, monkeypatch):
    import af_pki
    pki = tmp_path / "pki"
    monkeypatch.setenv("AF_PKI_DIR", str(pki)); monkeypatch.delenv("AF_CA_PASSPHRASE", raising=False)
    af_pki.init_ca(pki)
    af_pki.issue_server(pki, "localhost", ["DNS:localhost", "IP:127.0.0.1"])
    monkeypatch.setenv("AF_TLS_CERT", str(pki / "server.crt")); monkeypatch.setenv("AF_TLS_KEY", str(pki / "server.key"))
    monkeypatch.setenv("AF_TLS_CLIENT_CA", str(pki / "ca.crt"))
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    monkeypatch.delenv("AF_ENROLL_TOKEN", raising=False)
    for m in ("af_manager_api", "af_api_server"):
        sys.modules.pop(m, None)
    import af_api_server
    return pki, af_api_server


def test_mtls_enroll_bind_and_revoke(tlsenv, monkeypatch):
    pki, srv = tlsenv
    import af_manager_api as api, af_pki
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    port, eport = free_port(), free_port()
    st = srv.start("127.0.0.1", port, eport)
    assert st["running"] and st["mtls"] and st["enroll_port"] == eport, st
    ca = str(pki / "ca.crt")
    # 1) without a client certificate the TLS handshake itself fails
    with pytest.raises((requests.exceptions.SSLError, requests.exceptions.ConnectionError)):   # TLS1.3 reports it after the handshake
        requests.get(f"https://localhost:{port}/health", verify=ca, timeout=5)
    # 2) bootstrap listener: token + CSR -> short-lived cert
    key = ec.generate_private_key(ec.SECP256R1())
    csr = x509.CertificateSigningRequestBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "x")])).sign(key, hashes.SHA256())
    body = {"enroll_token": api.get_enroll_token(), "hostname": "h1", "os": "Linux", "arch": "x", "version": "1", "ip": "10.0.0.9",
            "agent_uid": "uid-1", "csr_pem": csr.public_bytes(serialization.Encoding.PEM).decode()}
    r = requests.post(f"https://localhost:{eport}/enroll", json=body, verify=ca, timeout=10)
    assert r.status_code == 200, r.text
    d = r.json()
    cert_file, key_file = pki / "a.crt", pki / "a.key"
    cert_file.write_text(d["cert_pem"])
    key_file.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    cert = (str(cert_file), str(key_file)); hdr = {"X-Agent-Token": d["agent_token"]}
    # 3) mTLS listener: cert + token works, binding recorded
    assert requests.post(f"https://localhost:{port}/heartbeat", json={}, headers=hdr, cert=cert, verify=ca, timeout=10).status_code == 200
    c = api.db(); assert c.execute("SELECT cert_fp FROM agents").fetchone()["cert_fp"] == af_pki.cert_fingerprint(d["cert_pem"])
    # 4) a different (valid, CA-signed) cert + stolen token is rejected
    af_pki.issue_agent(pki, "other")
    other = (str(pki / "agents/other.crt"), str(pki / "agents/other.key"))
    assert requests.post(f"https://localhost:{port}/heartbeat", json={}, headers=hdr, cert=other, verify=ca, timeout=10).status_code == 401
    # 5) renewal swaps the cert and updates the binding
    key2 = ec.generate_private_key(ec.SECP256R1())
    csr2 = x509.CertificateSigningRequestBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "x")])).sign(key2, hashes.SHA256())
    rr = requests.post(f"https://localhost:{port}/pki/renew", json={"csr_pem": csr2.public_bytes(serialization.Encoding.PEM).decode()},
                       headers=hdr, cert=cert, verify=ca, timeout=10)
    assert rr.status_code == 200, rr.text
    assert requests.post(f"https://localhost:{port}/heartbeat", json={}, headers=hdr, cert=cert, verify=ca, timeout=10).status_code == 401  # old cert no longer bound
    (pki / "b.crt").write_text(rr.json()["cert_pem"])
    (pki / "b.key").write_bytes(key2.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    cert2 = (str(pki / "b.crt"), str(pki / "b.key"))
    assert requests.post(f"https://localhost:{port}/heartbeat", json={}, headers=hdr, cert=cert2, verify=ca, timeout=10).status_code == 200
    # 6) revocation
    api.revoke_agent_cert(d["agent_id"], "test")
    assert requests.post(f"https://localhost:{port}/heartbeat", json={}, headers=hdr, cert=cert2, verify=ca, timeout=10).status_code == 401
    srv.stop()


def test_plaintext_refused_on_non_loopback(afhome, tmp_path, monkeypatch):
    for k in ("AF_TLS_CERT", "AF_TLS_KEY", "AF_TLS_CLIENT_CA", "AF_ALLOW_PLAINTEXT"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    for m in ("af_manager_api", "af_api_server"):
        sys.modules.pop(m, None)
    import af_api_server as srv
    st = srv.start("0.0.0.0", free_port())
    assert not st["running"] and "plain HTTP" in st["error"]
    monkeypatch.setenv("AF_ALLOW_PLAINTEXT", "1")
    st = srv.start("127.0.0.1", free_port())
    assert st["running"] and st["scheme"] == "http"
    srv.stop()


def test_port_in_use_is_reported(afhome, tmp_path, monkeypatch):
    for k in ("AF_TLS_CERT", "AF_TLS_KEY", "AF_TLS_CLIENT_CA"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("AF_DB_PATH", str(tmp_path / "h.db"))
    for m in ("af_manager_api", "af_api_server"):
        sys.modules.pop(m, None)
    import af_api_server as srv
    s = socket.socket(); s.bind(("127.0.0.1", 0)); s.listen(); p = s.getsockname()[1]
    st = srv.start("127.0.0.1", p)
    s.close()
    assert not st["running"] and "cannot listen" in st["error"]
