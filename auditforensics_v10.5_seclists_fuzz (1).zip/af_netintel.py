#!/usr/bin/env python3
"""Turns raw scan data into understanding: what is each device, what is risky, how is it connected, what changed.

Everything here is a heuristic with a stated reason. OS and device-type guesses carry a confidence and the evidence
used, so an analyst can overrule them; they are never presented as fact.
"""
import csv, io, ipaddress, json, math
from xml.sax.saxutils import escape

import af_oui

INITIAL_TTLS = (32, 64, 128, 255)
RISK_RANK = {"Info": 0, "Low": 1, "Medium": 2, "High": 3, "Critical": 4}
DB_PORTS = {3306: "MySQL", 5432: "PostgreSQL", 1433: "MSSQL", 1521: "Oracle", 27017: "MongoDB", 6379: "Redis", 9200: "Elasticsearch",
            11211: "Memcached", 5984: "CouchDB", 9042: "Cassandra", 50000: "DB2"}
ADMIN_PORTS = {2375: "Docker API", 2376: "Docker TLS API", 10250: "Kubelet", 2379: "etcd", 6443: "Kubernetes API", 5985: "WinRM", 5986: "WinRM (TLS)",
               623: "IPMI", 902: "VMware", 8500: "Consul", 4505: "Salt master", 9000: "management UI"}


# ---------------------------------------------------------------- liveness confidence
def alive_confidence(dev):
    """high: ICMP/ARP/broadcast answer or an open port (a real conversation). low: *only* TCP resets, which a firewall or
    transparent proxy can send on behalf of hosts that do not exist."""
    by = dev.get("discovered_by", [])
    strong = any(b in ("icmp", "arp", "arp-sweep", "ssdp", "mdns") or b.startswith("tcp-open") for b in by)
    if strong or _open(dev) or _open(dev, "udp") or dev.get("netbios"):
        return "high"
    return "low" if by else "unknown"


# ---------------------------------------------------------------- TTL / OS
def initial_ttl(ttl):
    return next((i for i in INITIAL_TTLS if ttl <= i), 255) if ttl else None


def hops_from_ttl(ttl):
    i = initial_ttl(ttl)
    return (i - ttl) if i else None


def _open(dev, proto="tcp"):
    return [s for s in (dev.get("services", []) if proto == "tcp" else dev.get("udp", [])) if s.get("state") == "open"]


def _ports(dev):
    return {s["port"] for s in _open(dev)}


def guess_os(dev):
    """-> (os_name, confidence 0-100, [reasons]). Scores several independent signals and reports the evidence."""
    sc, why = {}, {}

    def add(k, n, reason):
        sc[k] = sc.get(k, 0) + n
        why.setdefault(k, []).append(reason)
    ttl = dev.get("ttl")
    if ttl:
        base = initial_ttl(ttl)
        add({32: "Windows", 64: "Linux/Unix", 128: "Windows", 255: "Network device"}[base], 2, f"TTL {ttl} (initial {base})")
    ports = _ports(dev)
    hints = set(dev.get("os_hints", [])) | {h for s in _open(dev) for h in s.get("os_hints", [])}
    for h, label in (("windows", "Windows"), ("ubuntu", "Linux"), ("debian", "Linux"), ("raspbian", "Linux"), ("centos", "Linux"), ("rhel", "Linux"),
                     ("freebsd", "FreeBSD/Unix"), ("routeros", "Network device"), ("cisco", "Network device"), ("embedded-linux", "Linux"),
                     ("synology", "Linux"), ("qnap", "Linux"), ("unix", "Linux/Unix")):
        if h in hints:
            add(label, 5, f"service banner mentions {h}")
    for p, why_ in ((445, "SMB"), (135, "MS-RPC"), (3389, "RDP"), (5985, "WinRM"), (139, "NetBIOS session")):
        if p in ports:
            add("Windows", 2, f"{why_} port {p} open")
    if any(s.get("product_key") == "iis" for s in _open(dev)):
        add("Windows", 5, "Microsoft IIS")
    if dev.get("netbios"):
        add("Windows", 3, "NetBIOS name service answered")
    if 62078 in ports:
        add("macOS/iOS", 5, "lockdownd port 62078 (iPhone/iPad sync service)")
    v = (dev.get("vendor") or "").lower()
    for key, label in (("apple", "macOS/iOS"), ("microsoft", "Windows"), ("cisco", "Network device"), ("mikrotik", "Network device"),
                       ("ubiquiti", "Network device"), ("raspberry", "Linux"), ("synology", "Linux"), ("qnap", "Linux")):
        if key in v:
            add(label, 2, f"MAC vendor {dev['vendor']}")
    if not sc:
        return "", 0, []
    best = max(sc, key=sc.get)
    total = sum(sc.values())
    name = best
    if best == "Linux":
        distro = next((d for d in ("ubuntu", "debian", "raspbian", "centos", "rhel") if d in hints), "")
        name = f"Linux ({distro.capitalize() if distro != 'rhel' else 'RHEL'})" if distro else "Linux"
    conf = min(95, int(40 + 55 * sc[best] / max(total, 1) * min(1.0, sc[best] / 6)))
    return name, conf, why[best]


# ---------------------------------------------------------------- device type
VENDOR_TYPES = [("hewlett", "Printer"), ("canon", "Printer"), ("epson", "Printer"), ("brother", "Printer"), ("xerox", "Printer"), ("ricoh", "Printer"),
                ("lexmark", "Printer"), ("kyocera", "Printer"), ("hikvision", "IP Camera/NVR"), ("dahua", "IP Camera/NVR"), ("axis", "IP Camera/NVR"),
                ("synology", "NAS/Storage"), ("qnap", "NAS/Storage"), ("ubiquiti", "Network device"), ("mikrotik", "Router/Gateway"),
                ("cisco", "Network device"), ("tp-link", "Network device"), ("netgear", "Network device"), ("d-link", "Network device"),
                ("zyxel", "Network device"), ("aruba", "Network device"), ("fortinet", "Firewall/VPN"), ("palo alto", "Firewall/VPN"),
                ("sonicwall", "Firewall/VPN"), ("raspberry", "IoT/Embedded"), ("espressif", "IoT/Embedded"), ("sonos", "IoT/Embedded"),
                ("apple", "Apple device"), ("samsung", "Mobile/Smart device"), ("vmware", "Virtual machine"), ("qemu", "Virtual machine"),
                ("hyper-v", "Virtual machine"), ("virtualbox", "Virtual machine")]


def classify(dev):
    """-> (type, [reasons]). Highest-scoring rule wins; reasons list the evidence."""
    sc, why = {}, {}

    def add(k, n, reason):
        sc[k] = sc.get(k, 0) + n
        why.setdefault(k, []).append(reason)
    ports, svcs = _ports(dev), _open(dev)
    titles = " ".join((s.get("http") or {}).get("title", "") + " " + (s.get("http") or {}).get("server", "") for s in svcs).lower()
    udp = {s["port"] for s in dev.get("udp", []) if s.get("state") == "open"}
    osname = dev.get("os", "")
    v = (dev.get("vendor") or "").lower()
    if dev.get("gateway"):
        add("Router/Gateway", 8, "default gateway of a scanned network")
    if ports & {9100, 515, 631}:
        add("Printer", 5, f"print service ports {sorted(ports & {9100, 515, 631})}")
    if any(k in titles for k in ("printer", "laserjet", "officejet", "imageclass", "brother", "epson")):
        add("Printer", 4, "web UI title mentions a printer")
    if ports & {554, 8554} or "ipcam" in titles or "hikvision" in titles or "dahua" in titles or "nvr" in titles:
        add("IP Camera/NVR", 5, "RTSP / camera web UI")
    if {88, 389} <= ports and (445 in ports or 636 in ports) or {88, 464} <= ports:
        add("Domain Controller", 8, "Kerberos + LDAP/SMB on the same host")
    if ports & {3389, 135, 139, 445, 5985} and "Windows" in osname:
        add("Windows host", 4, "Windows services (SMB/RDP/RPC/WinRM)")
        if 3389 in ports and not ports & {80, 443, 22} and 445 not in ports:
            add("Windows workstation", 2, "RDP without server services")
    if ports & {902, 8006} or any(k in titles for k in ("esxi", "vsphere", "proxmox", "xenserver")):
        add("Hypervisor", 7, "hypervisor management ports or web UI")
    if ports & set(DB_PORTS):
        add("Database server", 5, f"database ports {sorted(ports & set(DB_PORTS))}")
    if ports & {2375, 2376} or any("docker" in (s.get("product_key") or "") for s in svcs):
        add("Container host", 5, "Docker API exposed")
    if ports & {6443, 10250, 2379}:
        add("Kubernetes node", 6, "Kubernetes API / kubelet / etcd ports")
    if ports & {80, 443, 8080, 8443} and any(s.get("product_key") in ("apache", "nginx", "iis", "tomcat", "lighttpd", "caddy", "haproxy") for s in svcs):
        add("Web server", 3, "known web server software")
    if ports & {25, 465, 587, 110, 143, 993, 995}:
        add("Mail server", 4, "mail ports open")
    if any(k in titles for k in ("synology", "qnap", "diskstation", "readynas", "truenas", "freenas")) or {2049, 445, 548} <= ports:
        add("NAS/Storage", 5, "NAS web UI or NFS+SMB+AFP")
    if 62078 in ports:
        add("Apple mobile device", 7, "iPhone/iPad lockdownd port 62078")
    if ports & {1883, 8883, 5683} and len(ports) <= 6:
        add("IoT/Embedded", 4, "MQTT/CoAP with few open ports")
    if any("upnp" in str(s.get("banner", "")).lower() or "miniupnpd" in str(s.get("banner", "")).lower() for s in svcs):
        add("Router/Gateway", 2, "UPnP gateway daemon")
    if "snmp-public-community" in {n for s in dev.get("udp", []) for n in s.get("notes", [])}:
        add("Network device", 1, "answers SNMP")
    for key, label in VENDOR_TYPES:
        if key in v:
            add(label, 3, f"MAC vendor {dev['vendor']}")
    if dev.get("ssdp_server") and "upnp" in dev["ssdp_server"].lower():
        add("IoT/Embedded", 1, "advertises UPnP")
    if not sc and osname.startswith("Linux") and 22 in ports:
        add("Linux server", 3, "Linux with SSH")
    if not sc and "Windows" in osname:
        add("Windows host", 2, "Windows fingerprint")
    if not sc and ports:
        add("Server", 1, f"{len(ports)} open port(s)")
    if not sc:
        return "Unknown", ["no identifying services; host answered only discovery probes"]
    best = max(sc, key=sc.get)
    # network gear and routers often run Linux: prefer the more specific hardware label over a generic OS label
    return best, why[best]


def enrich_devices(devices, gateways=()):
    """Run all inference passes in place."""
    gws = set(gateways)
    for d in devices:
        d["gateway"] = d["gateway"] or d["ip"] in gws
        if d.get("ttl") and d.get("hops") is None:
            d["hops"] = hops_from_ttl(d["ttl"])
        d["os"], d["os_conf"], d["os_reasons"] = guess_os(d)
        d["dtype"], d["dtype_reasons"] = classify(d)
        d["virtual"] = af_oui.is_virtual(d["mac"]) if d.get("mac") else False
        d["name"] = (d.get("hostnames") or [""])[0] or next(iter((d.get("names") or {}).values()), "")
    return devices


# ---------------------------------------------------------------- findings
def F(host, category, check, status, risk, details, rec="", mitre="", port=None, proto="tcp"):
    return {"host": host, "category": category, "check": check, "status": status, "risk": risk, "details": details, "recommendation": rec,
            "mitre": mitre, "port": port, "proto": proto}


def device_findings(dev):
    """Exposure and misconfiguration findings for one device (CVE findings are separate: cve_findings)."""
    ip, out = dev["ip"], []
    pub = dev.get("public")
    bump = lambda r: {"Low": "Medium", "Medium": "High", "High": "Critical"}.get(r, r) if pub else r      # exposed to the internet = one level worse
    for s in _open(dev):
        p, name, notes = s["port"], s.get("name", ""), set(s.get("notes", []))
        tag = f"{ip}:{p}/{name or 'tcp'}"
        if name == "telnet" or p == 23:
            out.append(F(ip, "Network Exposure", "Telnet Service Open", "FAIL", bump("High"), f"{tag}: cleartext remote login", "Disable Telnet; use SSH", "T1021", p))
        if name == "ftp" or p == 21:
            out.append(F(ip, "Network Exposure", "Cleartext FTP Open", "WARNING", bump("Medium"), f"{tag}: credentials and data cross the network unencrypted", "Use SFTP/FTPS", "T1071", p))
        if "ftp-anonymous-login" in notes:
            out.append(F(ip, "Network Exposure", "Anonymous FTP Login", "FAIL", bump("High"), f"{tag}: anonymous login accepted", "Disable anonymous access", "T1078", p))
        if "smb1-enabled" in notes:
            out.append(F(ip, "Network Exposure", "SMBv1 Enabled", "FAIL", bump("High"), f"{tag}: SMBv1 negotiated (EternalBlue family)", "Disable SMBv1", "T1210", p))
        if name == "smb" and pub:
            out.append(F(ip, "Network Exposure", "SMB Exposed to Internet", "FAIL", "Critical", f"{tag}: SMB reachable on a public address", "Block 445 at the perimeter", "T1133", p))
        if name == "rdp":
            if "rdp-nla-not-required" in notes:
                out.append(F(ip, "Network Exposure", "RDP Without NLA", "FAIL", bump("High"), f"{tag}: Network Level Authentication not required", "Require NLA", "T1021.001", p))
            if pub:
                out.append(F(ip, "Network Exposure", "RDP Exposed to Internet", "FAIL", "Critical", f"{tag}: RDP reachable on a public address", "Put RDP behind a VPN / gateway", "T1133", p))
        if name == "vnc":
            out.append(F(ip, "Network Exposure", "VNC Exposed", "WARNING", bump("High"), f"{tag}: remote desktop service reachable", "Restrict or tunnel VNC", "T1021.005", p))
        if p in DB_PORTS or s.get("product_key") in ("mysql", "mariadb", "postgresql", "redis", "elasticsearch", "mongodb"):
            out.append(F(ip, "Network Exposure", f"Database Service Reachable ({DB_PORTS.get(p, name)})", "WARNING", bump("High"),
                         f"{tag}: database port reachable from the scanner's network", "Bind to localhost / restrict with a firewall", "T1046", p))
        if p in ADMIN_PORTS and p not in DB_PORTS:
            out.append(F(ip, "Network Exposure", f"Management Interface Reachable ({ADMIN_PORTS[p]})", "WARNING", bump("High"), f"{tag}: administrative interface reachable",
                         "Restrict to management networks", "T1133", p))
        for note, check, risk, rec in (("redis-no-auth", "Redis Without Authentication", "Critical", "Set requirepass / bind to localhost"),
                                       ("docker-api-no-auth", "Docker API Without Authentication", "Critical", "Never expose the Docker socket over TCP unauthenticated"),
                                       ("elasticsearch-no-auth", "Elasticsearch Without Authentication", "Critical", "Enable security / restrict access")):
            if note in notes:
                out.append(F(ip, "Network Exposure", check, "FAIL", risk, f"{tag}: answers without credentials", rec, "T1190", p))
        if "http-basic-auth-cleartext" in notes:
            out.append(F(ip, "Network Exposure", "Basic Authentication Over HTTP", "WARNING", bump("Medium"), f"{tag}: credentials sent in clear text", "Serve over HTTPS", "T1040", p))
        tls = s.get("tls") or {}
        cert = tls.get("cert") or {}
        if cert:
            if cert.get("expired"):
                out.append(F(ip, "TLS", "Expired Certificate", "FAIL", "High", f"{tag}: expired {cert['not_after'][:10]} (CN {cert.get('subject_cn')})", "Renew the certificate", "T1557", p))
            elif cert.get("days_left", 999) < 30:
                out.append(F(ip, "TLS", "Certificate Expiring Soon", "WARNING", "Medium", f"{tag}: {cert['days_left']} day(s) left", "Renew the certificate", "", p))
            if cert.get("self_signed"):
                out.append(F(ip, "TLS", "Self-Signed Certificate", "WARNING", "Low", f"{tag}: self-signed (CN {cert.get('subject_cn')})", "Use a CA-issued certificate for user-facing services", "T1557", p))
            if cert.get("key", "").startswith("RSA-") and int(cert["key"][4:]) < 2048:
                out.append(F(ip, "TLS", "Weak Certificate Key", "FAIL", "High", f"{tag}: {cert['key']}", "Use RSA >= 2048 or ECDSA", "T1600", p))
            if any(x in (cert.get("sig_alg") or "").lower() for x in ("md5", "sha1")):
                out.append(F(ip, "TLS", "Weak Certificate Signature", "WARNING", "Medium", f"{tag}: {cert['sig_alg']}", "Reissue with SHA-256", "", p))
        legacy = next((n.split(":", 1)[1] for n in notes if n.startswith("tls-legacy:")), "")
        if legacy:
            out.append(F(ip, "TLS", "Legacy TLS Protocols Accepted", "FAIL", "Medium", f"{tag}: accepts {legacy}", "Disable TLS 1.0/1.1", "T1557", p))
    for s in _open(dev, "udp"):
        if "snmp-public-community" in s.get("notes", []):
            out.append(F(ip, "Network Exposure", "SNMP Default Community 'public'", "FAIL", bump("High"), f"{ip}:161/udp answers with community 'public': {s.get('banner', '')[:80]}",
                         "Change community strings / use SNMPv3", "T1602", 161, "udp"))
        if s["port"] == 11211:
            out.append(F(ip, "Network Exposure", "Memcached UDP Open", "FAIL", bump("High"), f"{ip}:11211/udp answers (amplification / data exposure)", "Disable UDP or firewall it", "T1498", 11211, "udp"))
        if s["port"] == 69:
            out.append(F(ip, "Network Exposure", "TFTP Open", "WARNING", bump("Medium"), f"{ip}:69/udp answers: unauthenticated file transfer", "Restrict TFTP", "T1105", 69, "udp"))
    n_open = len(_open(dev))
    if n_open > 50:
        out.append(F(ip, "Network Exposure", "Unusually Many Open Ports", "WARNING", "Medium", f"{ip}: {n_open} open TCP ports (honeypot, port-forwarding catch-all or misconfiguration)", "Verify the host", "T1046"))
    if pub and n_open:
        out.append(F(ip, "Network Exposure", "Public Address With Open Services", "WARNING", "Medium", f"{ip}: {n_open} service(s) reachable on a public address", "Confirm each is intended to be internet-facing", "T1133"))
    return out


def cve_findings(dev):
    out = []
    for c in dev.get("cves", []):
        sev = c["severity"]
        flags = (" KEV (actively exploited)" if c.get("kev") else "") + (f" EPSS {c['epss']:.2f}" if c.get("epss") else "")
        note = ("; distro may have backported the fix - verify the package version" if c.get("backport_risk") else "") + "; version taken from the banner (unverified)"
        out.append(F(dev["ip"], "Vulnerability", f"{c['cve']} in {c['product']} {c['version']}", "FAIL", sev,
                     f"{dev['ip']}:{c['port']}/{c['proto']} {c['product']} {c['version']}: CVSS {c['score']}{',' if flags else ''}{flags}; priority {c['priority']}/10 ({c['priority_label']}){note}. {c['summary'][:160]}",
                     f"Patch or upgrade {c['product']}; confirm exposure", "T1190", c["port"], c["proto"]))
    return out


def all_findings(devices):
    out = []
    for d in devices:
        out += device_findings(d) + cve_findings(d)
    return out


def device_risk(dev):
    r = max([RISK_RANK.get(f["risk"], 0) for f in dev.get("findings", []) if f["status"] in ("FAIL", "WARNING")] + [0])
    return {v: k for k, v in RISK_RANK.items()}[r]


# ---------------------------------------------------------------- topology
def subnet_of(ip, prefix=24):
    try:
        a = ipaddress.ip_address(ip)
        return str(ipaddress.ip_network(f"{ip}/{prefix if a.version == 4 else 64}", strict=False))
    except ValueError:
        return "unknown"


def build_topology(devices, gateways=(), scanner_ip="", local_cidrs=(), traces=None):
    """Graph of the scanned network. nodes: scanner / subnet / gateway / hop / device. ``traces`` = {target_ip: [hop ips]}."""
    nodes, edges, seen = {}, [], set()

    def node(i, kind, label, **kw):
        nodes.setdefault(i, {"id": i, "kind": kind, "label": label, **kw})
        return i

    def edge(a, b, kind="link"):
        if a != b and (a, b) not in seen and (b, a) not in seen:
            seen.add((a, b)); edges.append({"source": a, "target": b, "kind": kind})
    scanner = node("scanner", "scanner", f"Scanner {scanner_ip}".strip(), ip=scanner_ip)
    local = [ipaddress.ip_network(c, strict=False) for c in local_cidrs]
    by_ip = {d["ip"]: d for d in devices}
    for g in gateways:
        node(f"dev:{g}", "gateway", by_ip.get(g, {}).get("name") or g, ip=g, dtype="Router/Gateway")
    for d in devices:
        net = next((str(n) for n in local if ipaddress.ip_address(d["ip"]) in n), subnet_of(d["ip"]))
        sn = node(f"net:{net}", "subnet", net)
        kind = "gateway" if d["ip"] in gateways or d.get("gateway") else "device"
        dn = node(f"dev:{d['ip']}", kind, d.get("name") or d["ip"], ip=d["ip"], dtype=d.get("dtype", ""), os=d.get("os", ""), risk=device_risk(d),
                  mac=d.get("mac", ""), vendor=d.get("vendor", ""), cves=len(d.get("cves", [])), ports=len(_open(d)), subnet=net, hops=d.get("hops"))
        nodes[dn].update(kind=kind)
        edge(sn, dn, "member")
    for sid, sn in [(i, n) for i, n in nodes.items() if n["kind"] == "subnet"]:
        is_local = any(ipaddress.ip_network(sn["label"], strict=False).overlaps(n) for n in local) if local and sn["label"] != "unknown" else False
        gw = next((g for g in gateways if g in by_ip and by_ip[g]["ip"] and f"dev:{g}" in nodes and nodes[f"dev:{g}"].get("subnet") == sn["label"]), None)
        if is_local or not local:
            edge(scanner, sid, "attached")
        if gw:
            edge(sid, f"dev:{gw}", "gateway")
    for target, hops in (traces or {}).items():
        prev = scanner
        for h in hops:
            if not h or h in ("*",):
                continue
            hid = f"dev:{h}" if f"dev:{h}" in nodes else node(f"hop:{h}", "hop", h, ip=h)
            edge(prev, hid, "route")
            prev = hid
        if f"dev:{target}" in nodes:
            edge(prev, f"dev:{target}", "route")
    # hosts with no path yet but a TTL-derived distance: attach to the nearest gateway
    gw_nodes = [i for i, n in nodes.items() if n["kind"] == "gateway"]
    linked = {e["target"] for e in edges} | {e["source"] for e in edges}
    for i, n in list(nodes.items()):
        if n["kind"] == "subnet" and i not in linked:
            edge(gw_nodes[0] if gw_nodes else scanner, i, "inferred")
    return {"nodes": list(nodes.values()), "edges": edges}


def layout(top, width=1.0):
    """Deterministic layout without extra dependencies: scanner centre, gateways/hops on an inner ring, each subnet a
    cluster with its devices on a circle. -> {node_id: (x, y)}."""
    pos, nodes = {"scanner": (0.0, 0.0)}, {n["id"]: n for n in top["nodes"]}
    subnets = sorted(i for i, n in nodes.items() if n["kind"] == "subnet")
    inner = sorted(i for i, n in nodes.items() if n["kind"] in ("gateway", "hop"))
    for k, i in enumerate(inner):
        a = 2 * math.pi * k / max(len(inner), 1)
        pos[i] = (0.35 * math.cos(a), 0.35 * math.sin(a))
    members = {s: sorted(e["target"] for e in top["edges"] if e["source"] == s and e["kind"] == "member" and nodes[e["target"]]["kind"] == "device") for s in subnets}
    for k, s in enumerate(subnets):
        a = 2 * math.pi * k / max(len(subnets), 1) + 0.3
        R = 1.0 if len(subnets) > 1 else 0.8
        cx, cy = R * math.cos(a), R * math.sin(a)
        pos[s] = (cx, cy)
        m = members[s]
        r = 0.12 + 0.05 * math.sqrt(len(m))
        for j, d in enumerate(m):
            b = 2 * math.pi * j / max(len(m), 1)
            pos[d] = (cx + r * math.cos(b), cy + r * math.sin(b))
    for i in nodes:
        pos.setdefault(i, (0.0, 0.0))
    return pos


def topology_graphml(top):
    keys = ("kind", "label", "ip", "dtype", "os", "risk", "vendor", "mac")
    x = ['<?xml version="1.0" encoding="UTF-8"?>', '<graphml xmlns="http://graphml.graphdrawing.org/xmlns">']
    x += [f'<key id="{k}" for="node" attr.name="{k}" attr.type="string"/>' for k in keys]
    x += ['<key id="ekind" for="edge" attr.name="kind" attr.type="string"/>', '<graph id="network" edgedefault="undirected">']
    for n in top["nodes"]:
        x.append(f'<node id="{escape(n["id"])}">' + "".join(f'<data key="{k}">{escape(str(n.get(k, "")))}</data>' for k in keys) + "</node>")
    for i, e in enumerate(top["edges"]):
        x.append(f'<edge id="e{i}" source="{escape(e["source"])}" target="{escape(e["target"])}"><data key="ekind">{escape(e["kind"])}</data></edge>')
    return "\n".join(x + ["</graph>", "</graphml>"])


def topology_dot(top):
    q = lambda s: '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'
    shape = {"scanner": "doublecircle", "subnet": "box", "gateway": "diamond", "hop": "circle", "device": "ellipse"}
    col = {"Critical": "red", "High": "orange", "Medium": "gold", "Low": "lightgreen", "Info": "white"}
    out = ["graph network {"]
    for n in top["nodes"]:
        out.append(f'  {q(n["id"])} [label={q(n["label"] + (chr(10) + n["dtype"] if n.get("dtype") else ""))}, shape={shape.get(n["kind"], "ellipse")}, style=filled, fillcolor={q(col.get(n.get("risk", "Info"), "white"))}];')
    out += [f'  {q(e["source"])} -- {q(e["target"])};' for e in top["edges"]]
    return "\n".join(out + ["}"])


# ---------------------------------------------------------------- change detection
def _sig(d):
    return {"ports": {(s["port"], s.get("proto", "tcp")) for s in d.get("services", []) + d.get("udp", []) if s.get("state") == "open"},
            "cves": {c["cve"] for c in d.get("cves", [])}, "mac": (d.get("mac") or "").lower(), "os": d.get("os", "")}


def diff_scans(prev, cur, scanned_ips=None):
    """prev/cur = lists of device dicts. 'gone' only counts hosts that were inside this scan's address range."""
    p, c = {d["ip"]: d for d in prev}, {d["ip"]: d for d in cur}
    scope = set(scanned_ips) if scanned_ips is not None else None
    new = [c[i] for i in c if i not in p]
    gone = [p[i] for i in p if i not in c and (scope is None or i in scope)]
    changed, mac_conflicts = [], []
    for ip in c.keys() & p.keys():
        a, b = _sig(p[ip]), _sig(c[ip])
        ch = {"ip": ip, "opened": sorted(b["ports"] - a["ports"]), "closed": sorted(a["ports"] - b["ports"]), "new_cves": sorted(b["cves"] - a["cves"]),
              "fixed_cves": sorted(a["cves"] - b["cves"]), "os_changed": (a["os"], b["os"]) if a["os"] and b["os"] and a["os"] != b["os"] else None}
        if a["mac"] and b["mac"] and a["mac"] != b["mac"]:
            ch["mac_changed"] = (a["mac"], b["mac"])
            mac_conflicts.append(ip)
        if any(ch.get(k) for k in ("opened", "closed", "new_cves", "fixed_cves", "os_changed", "mac_changed")):
            changed.append(ch)
    return {"new": new, "gone": gone, "changed": changed, "mac_conflicts": mac_conflicts}


def diff_findings(diff):
    out = []
    for d in diff["new"]:
        if alive_confidence(d) == "low":
            out.append(F(d["ip"], "Asset Change", "Possible New Device (low confidence)", "INFO", "Low",
                         f"{d['ip']} answered only with TCP resets; a firewall may be answering for an absent host", "Confirm with ARP/ICMP from the same segment", "T1200"))
            continue
        out.append(F(d["ip"], "Asset Change", "New Device On Network", "WARNING", "Medium",
                     f"{d['ip']} ({d.get('dtype', 'Unknown')}, {d.get('vendor') or 'unknown vendor'}, MAC {d.get('mac') or '-'}) was not present in the previous scan",
                     "Confirm the device is authorised (rogue-device check)", "T1200"))
    for ch in diff["changed"]:
        if ch.get("mac_changed"):
            out.append(F(ch["ip"], "Asset Change", "MAC Address Changed For IP", "FAIL", "High",
                         f"{ch['ip']}: MAC {ch['mac_changed'][0]} -> {ch['mac_changed'][1]} (IP conflict, device replacement or ARP spoofing)", "Investigate immediately", "T1557.002"))
        if ch["opened"]:
            out.append(F(ch["ip"], "Asset Change", "New Open Ports", "WARNING", "Medium", f"{ch['ip']}: newly open {[f'{p}/{pr}' for p, pr in ch['opened']]}", "Confirm the change is expected", "T1046"))
        if ch["new_cves"]:
            out.append(F(ch["ip"], "Asset Change", "New Vulnerabilities", "FAIL", "High", f"{ch['ip']}: new CVEs {ch['new_cves'][:8]}", "Patch", "T1190"))
    for d in diff["gone"]:
        out.append(F(d["ip"], "Asset Change", "Device No Longer Seen", "INFO", "Info", f"{d['ip']} ({d.get('name') or d.get('dtype', '')}) did not respond this time", "Confirm it was decommissioned or is merely offline"))
    return out


# ---------------------------------------------------------------- exports
def _csv(rows, cols):
    b = io.StringIO()
    w = csv.DictWriter(b, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
    return b.getvalue()


def _cell(v):
    s = str(v if v is not None else "")
    return "'" + s if s[:1] in "=+-@\t\r" and s else s            # CSV/formula injection guard (banners are attacker-controlled)


def devices_csv(devices):
    rows = [{"ip": d["ip"], "name": _cell(d.get("name", "")), "mac": d.get("mac", ""), "vendor": _cell(d.get("vendor", "")), "type": d.get("dtype", ""),
             "os": d.get("os", ""), "os_confidence": d.get("os_conf", 0), "open_tcp": len(_open(d)), "open_udp": len(_open(d, "udp")),
             "cves": len(d.get("cves", [])), "kev": sum(1 for c in d.get("cves", []) if c.get("kev")), "risk": device_risk(d),
             "discovered_by": ";".join(d.get("discovered_by", [])), "alive_confidence": alive_confidence(d), "public": d.get("public", False)} for d in devices]
    return _csv(rows, ["ip", "name", "mac", "vendor", "type", "os", "os_confidence", "open_tcp", "open_udp", "cves", "kev", "risk", "discovered_by", "alive_confidence", "public"])


def services_csv(devices):
    rows = [{"ip": d["ip"], "port": s["port"], "proto": s.get("proto", "tcp"), "state": s.get("state"), "service": s.get("name"), "product": _cell(s.get("product", "")),
             "version": _cell(s.get("version", "")), "banner": _cell(s.get("banner", "")), "tls_version": (s.get("tls") or {}).get("version", ""),
             "cert_cn": _cell(((s.get("tls") or {}).get("cert") or {}).get("subject_cn", "")), "cert_expires": ((s.get("tls") or {}).get("cert") or {}).get("not_after", ""),
             "http_title": _cell((s.get("http") or {}).get("title", "")), "notes": ";".join(s.get("notes", []))}
            for d in devices for s in d.get("services", []) + d.get("udp", [])]
    return _csv(rows, ["ip", "port", "proto", "state", "service", "product", "version", "banner", "tls_version", "cert_cn", "cert_expires", "http_title", "notes"])


def cves_csv(devices):
    rows = [{"ip": d["ip"], "name": _cell(d.get("name", "")), "port": c["port"], "product": _cell(c["product"]), "version": _cell(c["version"]), "cve": c["cve"], "cvss": c["score"],
             "severity": c["severity"], "kev": c.get("kev", False), "epss": c.get("epss", 0), "priority": c.get("priority", 0), "priority_label": c.get("priority_label", ""),
             "confidence": c["confidence"], "backport_risk": c.get("backport_risk", False), "summary": _cell(c["summary"])} for d in devices for c in d.get("cves", [])]
    return _csv(rows, ["ip", "name", "port", "product", "version", "cve", "cvss", "severity", "kev", "epss", "priority", "priority_label", "confidence", "backport_risk", "summary"])


def scan_json(meta, devices, topology=None):
    return json.dumps({"meta": meta, "devices": devices, "topology": topology}, indent=1, default=str)
