import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import af_agent

if __name__ == "__main__":
    af_agent.main()
