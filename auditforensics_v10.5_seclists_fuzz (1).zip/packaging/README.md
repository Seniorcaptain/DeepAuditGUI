# Packaging the agent

* `python build_agent.py` -> `af_agent.pyz` (needs Python + `pip install -r requirements-agent.txt` on the endpoint)
* Python-free binary (tested on Linux x86_64; build on each target OS - PyInstaller does not cross-compile):

      pip install pyinstaller
      pyinstaller --onefile --name af_agent --paths . --hidden-import af_checks --hidden-import af_version \
          --collect-submodules cryptography.hazmat.primitives packaging/agent_entry.py

  Result: `dist/af_agent` (~15 MB). Windows/macOS binaries were not built here; code-sign them before deployment.
