#!/usr/bin/env python3
"""AuditForensics PKI - private CA + server and per-agent client certificates for mutual TLS.

  python af_pki.py init-ca
  python af_pki.py issue-server --cn manager.corp.local --san DNS:manager.corp.local --san IP:10.0.0.5
  python af_pki.py issue-agent  --name web01            (legacy: key generated here and copied to the endpoint)
  python af_pki.py sign-csr     --csr web01.csr --name web01   (preferred: the agent keeps its key; see --enroll-url)
  Encrypt the CA key:  init-ca --encrypt-key  (passphrase from AF_CA_PASSPHRASE or a prompt)
Manager:  AF_TLS_CERT=<dir>/server.crt AF_TLS_KEY=<dir>/server.key AF_TLS_CLIENT_CA=<dir>/ca.crt   (mTLS required)
Agent:    python af_agent.py --manager https://host:8765 --ca-bundle ca.crt --client-cert web01.crt --client-key web01.key
Leaf private keys are written mode 600. The CA key is passphrase-encrypted when AF_CA_PASSPHRASE / --encrypt-key
is used (strongly recommended); otherwise protect it offline.
Controls: NIST SC-8/SC-12/SC-23/IA-3, ISO 27001 A.8.24/A.8.20, SOC 2 CC6.1/CC6.7, HIPAA 164.312(e)(1).
"""
import argparse, datetime, getpass, hashlib, ipaddress, os, sys
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

DEFAULT_DIR = Path(os.environ.get("AF_HOME") or (Path.home() / ".auditforensics")) / "pki"


def _write(path, data, private=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600 if private else 0o644)
    with os.fdopen(fd, "wb") as f:
        f.write(data)


def _key_pem(k):
    return k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


def _name(cn):
    return x509.Name([x509.NameAttribute(NameOID.ORGANIZATION_NAME, "AuditForensics"),
                      x509.NameAttribute(NameOID.COMMON_NAME, cn)])


def _ca_pass(passphrase=None):
    p = passphrase if passphrase is not None else os.environ.get("AF_CA_PASSPHRASE")
    return p.encode() if p else None


def _ca_key_pem(k, passphrase):
    enc = serialization.BestAvailableEncryption(passphrase) if passphrase else serialization.NoEncryption()
    return k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, enc)


def _load_ca(d, passphrase=None):
    d = Path(d)
    raw = (d / "ca.key").read_bytes()
    pw = _ca_pass(passphrase)
    try:
        key = serialization.load_pem_private_key(raw, pw)
    except TypeError:
        raise SystemExit("CA key is passphrase-protected: set AF_CA_PASSPHRASE (or pass the passphrase)")
    except ValueError:
        raise SystemExit("could not decrypt the CA key: wrong passphrase?")
    return key, x509.load_pem_x509_certificate((d / "ca.crt").read_bytes())


def cert_fingerprint(cert):
    """SHA-256 of the DER encoding, lowercase hex. Accepts a Certificate, PEM bytes/str or DER bytes."""
    if isinstance(cert, str):
        cert = cert.encode()
    if isinstance(cert, (bytes, bytearray)):
        cert = (x509.load_pem_x509_certificate(bytes(cert)) if b"BEGIN CERTIFICATE" in cert
                else x509.load_der_x509_certificate(bytes(cert)))
    return hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).hexdigest()


def cert_days_left(pem):
    c = x509.load_pem_x509_certificate(pem if isinstance(pem, bytes) else pem.encode())
    return (c.not_valid_after_utc - datetime.datetime.now(datetime.timezone.utc)).total_seconds() / 86400


def init_ca(d=DEFAULT_DIR, cn="AuditForensics Private CA", days=1825, passphrase=None):
    d = Path(d)
    if (d / "ca.key").exists():
        raise SystemExit(f"CA already exists in {d} (refusing to overwrite)")
    key = ec.generate_private_key(ec.SECP256R1())
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(_name(cn)).issuer_name(_name(cn)).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5))
            .not_valid_after(now + datetime.timedelta(days=days))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True, content_commitment=False,
                                         key_encipherment=False, data_encipherment=False, key_agreement=False,
                                         encipher_only=False, decipher_only=False), critical=True)
            .sign(key, hashes.SHA256()))
    _write(d / "ca.key", _ca_key_pem(key, _ca_pass(passphrase)), True)
    _write(d / "ca.crt", cert.public_bytes(serialization.Encoding.PEM))
    return d / "ca.crt"


def _issue(d, name, server, sans, days, passphrase=None):
    d = Path(d)
    ca_key, ca = _load_ca(d, passphrase)
    key = ec.generate_private_key(ec.SECP256R1())
    now = datetime.datetime.now(datetime.timezone.utc)
    b = (x509.CertificateBuilder().subject_name(_name(name)).issuer_name(ca.subject).public_key(key.public_key())
         .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5))
         .not_valid_after(now + datetime.timedelta(days=days))
         .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
         .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=False, crl_sign=False, content_commitment=False,
                                      key_encipherment=False, data_encipherment=False, key_agreement=False,
                                      encipher_only=False, decipher_only=False), critical=True)
         .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH if server else ExtendedKeyUsageOID.CLIENT_AUTH]),
                        critical=False))
    if server:
        alts = []
        for s in sans or [f"DNS:{name}"]:
            kind, _, val = s.partition(":")
            alts.append(x509.IPAddress(ipaddress.ip_address(val)) if kind.upper() == "IP" else x509.DNSName(val))
        b = b.add_extension(x509.SubjectAlternativeName(alts), critical=False)
    cert = b.sign(ca_key, hashes.SHA256())
    sub = d if server else d / "agents"
    stem = "server" if server else name
    _write(sub / f"{stem}.key", _key_pem(key), True)
    _write(sub / f"{stem}.crt", cert.public_bytes(serialization.Encoding.PEM))
    return sub / f"{stem}.crt", sub / f"{stem}.key"


def issue_server(d=DEFAULT_DIR, cn="localhost", sans=None, days=397, passphrase=None):
    return _issue(d, cn, True, sans, days, passphrase)


def issue_agent(d=DEFAULT_DIR, name="agent", days=397, passphrase=None):
    return _issue(d, name, False, None, days, passphrase)


MAX_AGENT_CERT_DAYS = 397
DEFAULT_AGENT_CERT_DAYS = int(os.environ.get("AF_AGENT_CERT_DAYS", "30"))


def sign_csr(d, csr_pem, name, days=None, passphrase=None):
    """Sign an agent-generated CSR. The subject and extensions come from US, never from the CSR, so an agent
    cannot request a CA certificate or another agent's name. Returns (cert_pem_bytes, fingerprint, serial_hex)."""
    days = max(1, min(int(days or DEFAULT_AGENT_CERT_DAYS), MAX_AGENT_CERT_DAYS))
    csr = x509.load_pem_x509_csr(csr_pem if isinstance(csr_pem, bytes) else csr_pem.encode())
    if not csr.is_signature_valid:
        raise ValueError("CSR signature invalid")
    pub = csr.public_key()
    if isinstance(pub, ec.EllipticCurvePublicKey):
        if pub.curve.name not in ("secp256r1", "secp384r1"):
            raise ValueError("unsupported EC curve")
    elif isinstance(pub, rsa.RSAPublicKey):
        if pub.key_size < 2048:
            raise ValueError("RSA key must be at least 2048 bits")
    else:
        raise ValueError("unsupported public key type")
    ca_key, ca = _load_ca(d, passphrase)
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(_name(name)).issuer_name(ca.subject).public_key(pub)
            .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(minutes=5))
            .not_valid_after(now + datetime.timedelta(days=days))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=False, crl_sign=False, content_commitment=False,
                                         key_encipherment=False, data_encipherment=False, key_agreement=False,
                                         encipher_only=False, decipher_only=False), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
            .sign(ca_key, hashes.SHA256()))
    return cert.public_bytes(serialization.Encoding.PEM), cert_fingerprint(cert), format(cert.serial_number, "x")


def main():
    p = argparse.ArgumentParser(description="AuditForensics PKI")
    p.add_argument("--dir", default=str(DEFAULT_DIR))
    sub = p.add_subparsers(dest="cmd", required=True)
    ic = sub.add_parser("init-ca"); ic.add_argument("--encrypt-key", action="store_true")
    s = sub.add_parser("issue-server"); s.add_argument("--cn", required=True); s.add_argument("--san", action="append")
    a_ = sub.add_parser("issue-agent"); a_.add_argument("--name", required=True)
    sc = sub.add_parser("sign-csr"); sc.add_argument("--csr", required=True); sc.add_argument("--name", required=True)
    sc.add_argument("--days", type=int, default=DEFAULT_AGENT_CERT_DAYS)
    a = p.parse_args()
    if a.cmd == "init-ca":
        pw = None
        if a.encrypt_key and not os.environ.get("AF_CA_PASSPHRASE"):
            pw = getpass.getpass("CA key passphrase: ")
            if pw != getpass.getpass("Repeat: "):
                sys.exit("passphrases differ")
        print("CA certificate:", init_ca(a.dir, passphrase=pw))
    elif a.cmd == "sign-csr":
        pem, fp, serial = sign_csr(a.dir, Path(a.csr).read_text(), a.name, a.days)
        out = Path(a.csr).with_suffix(".crt"); out.write_bytes(pem)
        print("certificate:", out, "sha256:", fp, "serial:", serial)
    elif a.cmd == "issue-server":
        print("server cert/key:", *issue_server(a.dir, a.cn, a.san))
    else:
        print("agent cert/key:", *issue_agent(a.dir, a.name))


if __name__ == "__main__":
    main()
