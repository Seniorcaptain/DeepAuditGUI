#!/usr/bin/env python3
"""Send the signed consent PDF over WhatsApp using Meta's WhatsApp Cloud API (Graph API).

Configuration (environment only - never stored in the database, never logged):
  AF_WHATSAPP_TOKEN          permanent or system-user access token for the WhatsApp Business app
  AF_WHATSAPP_PHONE_ID       the sending phone number's ID (Graph API id, not the phone number itself)
  AF_WHATSAPP_API_VERSION    default v21.0
  AF_WHATSAPP_TEMPLATE       name of an approved message *template* that has a Document header component. Required
                             to message someone who has not written to the business number in the last 24 hours -
                             WhatsApp only allows business-initiated conversations to start with a pre-approved
                             template. Leave unset to always send a freeform/session document message (works only
                             inside that 24-hour window, e.g. replying to someone who just messaged in).
  AF_WHATSAPP_TEMPLATE_LANG  template language code, default en_US

Without AF_WHATSAPP_TOKEN/AF_WHATSAPP_PHONE_ID set, ``send_consent_pdf`` returns ok=False with a clear reason;
the caller should fall back to ``wa_me_link`` (a click-to-chat link; WhatsApp's own links cannot attach a file, so
the person downloads the PDF and attaches it manually) plus a plain PDF download.
"""
import os
import re
from urllib.parse import quote

GRAPH = "https://graph.facebook.com"


def configured():
    return bool(os.environ.get("AF_WHATSAPP_TOKEN") and os.environ.get("AF_WHATSAPP_PHONE_ID"))


def _version():
    return os.environ.get("AF_WHATSAPP_API_VERSION", "v21.0")


def _base():
    return f"{GRAPH}/{_version()}/{os.environ['AF_WHATSAPP_PHONE_ID']}"


def _token():
    return os.environ.get("AF_WHATSAPP_TOKEN", "")


def normalize_number(raw):
    """-> digits-only E.164 (no leading '+') or None if it doesn't look like a phone number with a country code."""
    digits = re.sub(r"[^\d+]", "", str(raw or "")).lstrip("+")
    return digits if re.fullmatch(r"\d{8,15}", digits) else None


def mask_number(raw):
    n = normalize_number(raw) or re.sub(r"\D", "", str(raw or ""))
    return ("*" * max(0, len(n) - 4)) + n[-4:] if n else ""


def wa_me_link(number, text=""):
    """Click-to-chat link. Cannot attach a file (WhatsApp does not support that in a link); text can point the
    recipient at what to expect and ask them to request the PDF, or confirm one was sent another way."""
    n = normalize_number(number)
    if not n:
        return ""
    return f"https://wa.me/{n}" + (f"?text={quote(text)}" if text else "")


def upload_media(pdf_bytes, filename="scan_consent.pdf", http=None, timeout=60):
    """-> (media_id, error). error is '' on success."""
    import requests
    http = http or requests
    try:
        r = http.post(f"{_base()}/media", headers={"Authorization": f"Bearer {_token()}"},
                      data={"messaging_product": "whatsapp", "type": "application/pdf"},
                      files={"file": (filename, pdf_bytes, "application/pdf")}, timeout=timeout)
    except Exception as e:
        return None, f"{type(e).__name__}: {str(e)[:150]}"
    if r.status_code != 200:
        return None, f"upload failed: HTTP {r.status_code} {r.text[:200]}"
    try:
        return r.json()["id"], ""
    except (ValueError, KeyError):
        return None, "upload failed: no media id in the response"


def _post_message(payload, http=None, timeout=30):
    import requests
    http = http or requests
    try:
        r = http.post(f"{_base()}/messages", headers={"Authorization": f"Bearer {_token()}", "Content-Type": "application/json"},
                      json=payload, timeout=timeout)
    except Exception as e:
        return False, f"{type(e).__name__}: {str(e)[:150]}", None
    ok = r.status_code == 200
    detail = "" if ok else f"HTTP {r.status_code} {r.text[:250]}"
    try:
        body = r.json()
    except ValueError:
        body = None
    return ok, detail, body


def send_document_session(to, media_id, filename, caption="", http=None):
    payload = {"messaging_product": "whatsapp", "to": to, "type": "document",
               "document": {"id": media_id, "filename": filename, "caption": caption[:1024]}}
    return _post_message(payload, http)


def send_document_template(to, media_id, filename, template, lang, body_params=None, http=None):
    components = [{"type": "header", "parameters": [{"type": "document", "document": {"id": media_id, "filename": filename}}]}]
    if body_params:
        components.append({"type": "body", "parameters": [{"type": "text", "text": str(p)} for p in body_params]})
    payload = {"messaging_product": "whatsapp", "to": to, "type": "template",
               "template": {"name": template, "language": {"code": lang}, "components": components}}
    return _post_message(payload, http)


def send_consent_pdf(to_raw, pdf_bytes, filename="scan_consent.pdf", caption="", body_params=None, http=None):
    """-> {ok, detail, message_id, method}. Never raises; a failure is always reported, never silent."""
    if not configured():
        return {"ok": False, "detail": "WhatsApp is not configured (set AF_WHATSAPP_TOKEN and AF_WHATSAPP_PHONE_ID)",
                "message_id": "", "method": ""}
    to = normalize_number(to_raw)
    if not to:
        return {"ok": False, "detail": f"'{to_raw}' does not look like a phone number with a country code (digits only, 8-15 of them)",
                "message_id": "", "method": ""}
    try:
        media_id, err = upload_media(pdf_bytes, filename, http)
        if not media_id:
            return {"ok": False, "detail": err, "message_id": "", "method": ""}
        template = os.environ.get("AF_WHATSAPP_TEMPLATE", "")
        if template:
            ok, detail, resp = send_document_template(to, media_id, filename, template,
                                                       os.environ.get("AF_WHATSAPP_TEMPLATE_LANG", "en_US"), body_params, http)
            method = "template"
        else:
            ok, detail, resp = send_document_session(to, media_id, filename, caption, http)
            method = "session"
        msgs = (resp or {}).get("messages") or []
        return {"ok": ok, "detail": detail, "message_id": msgs[0].get("id", "") if msgs else "", "method": method}
    except Exception as e:                                 # belt and braces: a bug here must not crash the caller
        return {"ok": False, "detail": f"{type(e).__name__}: {str(e)[:150]}", "message_id": "", "method": ""}
