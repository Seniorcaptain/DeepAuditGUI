#!/usr/bin/env python3
"""MAC address -> vendor lookup.

Coverage is only as good as the registry you load. Built in: virtualisation platforms, Raspberry Pi and a few
well-known prefixes. For real coverage load the IEEE registry once (cached 30 days):
    af_oui.refresh()                     # downloads https://standards-oui.ieee.org/oui/oui.csv to AF_HOME/oui.csv
or drop an `oui.csv` (IEEE), a Wireshark `manuf`, or nmap's `nmap-mac-prefixes` into AF_HOME.
Locally-administered ("randomised / private") MACs - modern phones and laptops - are flagged because they have no vendor.
"""
import csv, re, time
from functools import lru_cache
from pathlib import Path

from af_util import af_home

BUILTIN = {
    "000C29": "VMware", "005056": "VMware", "000569": "VMware", "080027": "VirtualBox (Oracle)", "00155D": "Microsoft Hyper-V",
    "525400": "QEMU/KVM", "00163E": "Xen", "B827EB": "Raspberry Pi Foundation", "DCA632": "Raspberry Pi Trading",
    "E45F01": "Raspberry Pi Trading", "00000C": "Cisco Systems", "024200": "Docker (locally administered)",
}
VIRTUAL_VENDORS = ("vmware", "virtualbox", "hyper-v", "qemu", "xen", "docker")
IEEE_URL = "https://standards-oui.ieee.org/oui/oui.csv"


def norm(mac):
    return re.sub(r"[^0-9A-Fa-f]", "", str(mac or "")).upper()


def is_randomized(mac):
    """Locally-administered bit set in the first octet -> not a manufacturer-assigned address."""
    h = norm(mac)
    return len(h) >= 2 and bool(int(h[:2], 16) & 0x02)


@lru_cache(maxsize=1)
def _table():
    t = dict(BUILTIN)
    d = af_home()
    for p in (d / "oui.csv", d / "manuf", d / "nmap-mac-prefixes"):
        if not p.exists():
            continue
        try:
            if p.suffix == ".csv":
                for row in csv.reader(p.read_text(errors="replace").splitlines()):
                    if len(row) >= 3 and re.fullmatch(r"[0-9A-Fa-f]{6}", row[1].strip()):
                        t[row[1].strip().upper()] = row[2].strip()
            else:
                for ln in p.read_text(errors="replace").splitlines():
                    if ln.startswith("#") or not ln.strip():
                        continue
                    m = re.match(r"^([0-9A-Fa-f]{2}(?:[:\-]?[0-9A-Fa-f]{2}){2})(?:/\d+)?(?:\s+|$)(.*)$", ln.strip())
                    if not m or not m.group(2):
                        continue
                    rest = m.group(2)
                    if p.name == "manuf":                       # Wireshark: "<prefix>\t<short>\t<long name>"
                        parts = [x.strip() for x in re.split(r"\t+", ln.strip())]
                        rest = parts[2] if len(parts) >= 3 else parts[1]
                    t[norm(m.group(1))] = rest.strip()
        except OSError:
            continue
    return t


def reload():
    _table.cache_clear()


def lookup(mac):
    """-> vendor name or '' (unknown)."""
    h = norm(mac)
    if len(h) < 6:
        return ""
    return _table().get(h[:6], "")


def describe(mac):
    """-> (vendor, note). Note explains empty vendors."""
    v = lookup(mac)
    if v:
        return v, ""
    if is_randomized(mac):
        return "", "randomised/private MAC (typical of phones and modern laptops)"
    return "", "vendor not in the loaded registry"


def is_virtual(mac):
    v = lookup(mac).lower()
    return any(x in v for x in VIRTUAL_VENDORS)


def refresh(http=None, max_age_days=30, force=False):
    """Download the IEEE registry to AF_HOME/oui.csv (needs internet). Returns the path or None."""
    p = af_home() / "oui.csv"
    if p.exists() and not force and time.time() - p.stat().st_mtime < max_age_days * 86400:
        return p
    import requests
    http = http or requests
    r = http.get(IEEE_URL, timeout=60, headers={"User-Agent": "AuditForensics"})
    if r.status_code != 200 or "Assignment" not in r.text[:200]:
        return None
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(r.text)
    reload()
    return p
