# AuditForensics v10.5 — Install & Run Guide

> **Authorised use only.** Scan and deploy agents only on systems you own or have written permission to test.

## 1. What is in the folder

| File | Purpose | Needed? |
|---|---|---|
| `auditforensics_web.py` | The application (Streamlit UI, scanners, compliance, scheduler) | **Yes** |
| `af_auth.py`, `af_audit.py`, `af_util.py`, `af_version.py` | Login/roles/MFA/SSO, tamper-evident audit chain, UTC helpers, version | **Yes** |
| `af_scope.py` | Scan guardrails: scope, size caps, authorization records, rate limits | **Yes** (scans are refused without it) |
| `af_checks.py`, `af_catalog.py`, `checks_catalog.yaml` | Shared host checks, stable check IDs, framework mappings | **Yes** |
| `af_manager_api.py`, `af_api_server.py`, `af_worker.py` | Agent API, standalone API server, background worker | For agents |
| `af_signing.py`, `af_vault.py`, `af_pki.py` | Ed25519 signing, encryption at rest, private CA | Recommended |
| `af_integrations.py`, `af_vuln.py` | SIEM/ticket/alert export; OSV vulnerability matching | Optional |
| `af_netmap.py`, `af_netintel.py`, `af_netjob.py`, `af_netcve.py`, `af_oui.py` | Network Map: discovery/ports/services, OS+device inference, topology/diff/jobs, CVEs, MAC vendors | For the 🌐 Network Map tab |
| `af_subdomains.py` | Subdomain discovery (crt.sh + DNS brute force) for Web Application scans | For subdomain scanning |
| `af_consent.py`, `af_whatsapp.py` | Signed consent PDFs; WhatsApp Cloud API delivery | For the consent form's PDF/WhatsApp options |
| `af_agent.py` (+ `af_checks.py`, `af_version.py`) or `af_agent.pyz` | Endpoint agent | Endpoints only |
| `requirements*.txt`, `requirements.lock` | Core / optional / dev / agent deps; hash-pinned lock | **Yes** |
| `build_agent.py`, `packaging/`, `Dockerfile`, `docker-compose.yml`, `start.sh`, `start.bat` | Packaging and launchers | Convenience |
| `tests/`, `.github/workflows/ci.yml`, `tools/gen_catalog.py` | Test suite, CI, catalog generator | Development |

Keep all `.py` files and `checks_catalog.yaml` **in the same folder**.

## 2. Prerequisites
* **Python 3.10+** (tested on 3.12), `pip`, `venv` (Debian/Ubuntu: `sudo apt install python3-venv python3-pip`)
* Internet for first install, CVE/OSV lookups and threat intel (NVD, OSV.dev, CISA KEV, FIRST EPSS)
* Optional build tools only if a package fails to compile (see `requirements-optional.txt`)

## 3. Install
```bash
python3 -m venv venv && source venv/bin/activate          # Windows: py -m venv venv ; venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install --require-hashes -r requirements.lock          # reproducible, hash-checked (linux / py3.12 lock)
#   or: pip install -r requirements.txt                    # any platform
pip install -r requirements-optional.txt                   # optional scan modules; drop lines that fail to build
pytest -q                                                  # optional: pip install -r requirements-dev.txt first
```
`cryptography` must be **>= 50** (older 48.x releases have published advisories; the original `<49` cap blocked the fixes).

## 4. Optional API keys
`NVD_API_KEY` (faster CVE lookups) · `GROQ_API_KEY` / `OPENAI_API_KEY` / `GEMINI_API_KEY` for AI summaries. Findings are redacted
before leaving the machine, treated as untrusted data in the prompt, and every send is logged. For fully local summaries run
Ollama and set `AF_OLLAMA_MODEL=llama3.1` (`AF_OLLAMA_URL` optional); `AF_AI_LOCAL_ONLY=1` forbids cloud providers.
Model names: `AF_GROQ_MODEL`, `AF_OPENAI_MODEL`, `AF_GEMINI_MODEL`.

## 5. First run
```bash
./start.sh        # start.bat on Windows   -> http://127.0.0.1:8501
```
**First administrator:** the first screen asks for a **setup code**. It is printed in the server console and stored in
`~/.auditforensics/setup_code` (mode 600), so only someone with access to the host can claim the account. Headless alternative:
`AF_ADMIN_USER` + `AF_ADMIN_PASSWORD` (min 12 chars; passwords are also checked against breached-password lists — HIBP k-anonymity
range query, fails open offline; or `AF_BREACHED_FILE=<sorted SHA-1 list>` for fully offline).

In **🔐 Account**: enable MFA (you receive **10 one-time recovery codes** — store them), create users, assign roles:

| Role | Can do |
|---|---|
| `admin` | everything incl. users, tokens, agent administration, schedules, risk acceptance, live-response requests/approvals |
| `analyst` | scans, agent commands (not live response), attestations, exports |
| `auditor` | read-only + exports |

Sensitive actions (user admin, MFA changes, token rotation, clearing history, agent release/disable/revoke, live response,
key rotation) require **re-authentication** (password + MFA; valid `AF_STEPUP_MIN`=5 min). Permissions are enforced inside each
action, not only by greying out buttons. Lockout, idle timeout and the audit trail work as before; the audit trail is now
**hash-chained** (Account → Audit trail → *Verify*; set `AF_SYSLOG=udp://siem:514` to mirror it off-box).

**SSO (OpenID Connect, needs Streamlit ≥ 1.42):** configure `[auth]` in `.streamlit/secrets.toml`, then
`AF_SSO=1`, `AF_SSO_ROLE_CLAIM=groups`, `AF_SSO_ROLE_MAP='{"af-admins":"admin","af-analysts":"analyst"}'`,
`AF_SSO_DEFAULT_ROLE=auditor` (or `none` to deny unmapped users), optional `AF_SSO_ONLY=1`. SAML is not built in (use an OIDC bridge).

## 6. Scanning safely
* **Scope policy** (`~/.auditforensics/scope.json` or env, see `af_scope.py`): allow/deny lists, `max_hosts` (default 4096 — a typo like
  `10.0.0.0/8` is refused before anything runs), UTC blackout windows, per-target/global rate limits (`AF_SCAN_RATE_PER_HOST` default 100/s).
* Private ranges are in scope by default. **Public / external targets require a recorded authorization** (reason + optional/required
  ticket); see History → *Scan authorizations*.
* **Coverage:** every scan reports checks that crashed (`ERROR`) or could not run (`SKIPPED`: permissions, missing tools, timeouts) under
  category *Scan Coverage*, plus a banner. A check that did not run is never reported as a pass.

## 6c. Consent PDF and WhatsApp delivery
Every public-target scan authorization (the form shown in Scan and in Network Map) can be turned into a signed PDF
and optionally sent over WhatsApp right away, or later from **History → 📝 Scan authorizations** (works for a
record with no scan run yet too).

* **PDF**: who authorized, when, scan type, targets, reason, ticket, Ed25519 signature and public key, SHA-256 of the
  record. Needs `reportlab` (`pip install reportlab`, or `requirements-optional.txt`); without it the download button
  is replaced with that instruction.
* **WhatsApp**: uses Meta's WhatsApp Cloud API. Configure:

  | Variable | Meaning |
  |---|---|
  | `AF_WHATSAPP_TOKEN` | permanent / system-user access token |
  | `AF_WHATSAPP_PHONE_ID` | the sending number's Graph API phone ID (not the phone number) |
  | `AF_WHATSAPP_API_VERSION` | default `v21.0` |
  | `AF_WHATSAPP_TEMPLATE` | name of an **approved** template with a Document header, needed to message someone who hasn't written to the business number in the last 24 hours (WhatsApp's rule, not this app's) |
  | `AF_WHATSAPP_TEMPLATE_LANG` | default `en_US` |

  Without a template configured, sending only works inside that 24-hour window (a session/freeform message).
  **Not configured?** The panel shows a `wa.me` click-to-chat link instead - WhatsApp links cannot carry a file
  attachment, so you download the PDF and attach it yourself in the chat that opens.
  Every attempt (success or failure) is recorded on the authorization row and in the audit trail; the phone number
  is masked to its last 4 digits wherever it is logged or displayed in a list.

  **This could not be tested against the real Meta Graph API from the environment it was built in** (no network
  access to `graph.facebook.com`); it is unit-tested against a fake HTTP client that mimics the documented
  request/response shapes for media upload and message send.

## 6b. Network Map (discovery, ports, services, CVEs, topology)
Open **🌐 Network Map**. *Use my attached networks* fills in your own subnet(s); you can also enter CIDRs, ranges (`10.0.5.10-10.0.5.40`) or hosts.

| Setting | What it does |
|---|---|
| **Profile** | *Discovery only* (find hosts) · *Quick* (~100 well-known service ports) · *Standard* (ports 1-1024 + known service ports, plus UDP) · *Full* (**all 65,535 TCP ports** + common UDP) |
| **Probing level** | *discovery* sends nothing beyond connects · *standard* identifies services (banners, HTTP titles/headers, TLS certificates, RDP/SMB/Redis/MySQL/PostgreSQL/… handshakes) · *deep* adds safe misconfiguration checks (anonymous FTP, unauthenticated Redis / Docker API / Elasticsearch, legacy TLS) |
| **Speed** | *Gentle* (fragile printers/IoT) · *Normal* · *Fast* |
| **UDP ports** | DNS (BIND version), NTP, SNMP (default community), NetBIOS (names + MAC), SSDP/UPnP, mDNS, TFTP, memcached |
| **Look up CVEs** | maps identified product+version to NVD CVEs, enriches with CISA KEV + EPSS, ranks by priority (set `NVD_API_KEY` for ~10x faster lookups) |
| **Trace routes** | maps hops to remote subnets for the topology graph |
| **Use nmap** | if `nmap` is installed, adds its service/OS fingerprinting (OS detection needs root) |

**How hosts are found:** several independent signals are combined — ICMP echo, TCP connect (an *open* port **or** an actively refused port proves a host exists even when ping is blocked), ARP/neighbour table (and an ARP sweep with scapy + root), SSDP and mDNS responders, NetBIOS, reverse DNS. Each device records how it was found, and an **Alive** confidence: *high* (ICMP/ARP/broadcast answer or an open port) or *low* (only TCP resets). Some firewalls and proxies reset connections for hosts that do not exist; when many hosts look like that the scan shows a warning.

**What you get:** a device inventory (IP, name, MAC + vendor, OS guess, device type with the *evidence* behind each guess, ports, services, TLS, CVEs, risk), per-device detail, a network-wide CVE view, a topology graph (subnets, gateways, hops), **change detection** against the previous scan of the same targets (new devices, devices no longer seen, newly open ports, new CVEs, a MAC that changed for the same IP = possible ARP spoofing), a persistent asset inventory, findings you can push into **Results / Compliance / History** with one click, and exports (CSV, JSON, GraphML, Graphviz DOT). New High/Critical findings go through your configured integrations (SIEM, tickets, alerts).

**Guardrails (always on):** the scope policy applies (default 4,096 hosts per scan; public targets need a recorded authorization; allow/deny lists; blackout windows), an administrator can raise the host limit per scan (audited), scans run as cancellable background jobs (one at a time), rate limits per host/globally, and everything is recorded in the audit trail.

**Honest limits**
* **Versions come from banners and are unverified.** Linux distributions backport fixes without changing the version string, so a CVE listed for `OpenSSH 8.9p1 Ubuntu-…` may already be patched (flagged *backport possible*), and a server can hide or fake its banner. Services that expose no version are listed but cannot be mapped to CVEs. A failed NVD lookup is reported as failed, never as "no CVEs".
* OS and device type are heuristics (TTL, banners, ports, MAC vendor, names) shown with confidence and reasons.
* MAC vendors: only virtualisation platforms are built in. Click **Download IEEE MAC vendor list** (needs internet) for full coverage. Phones/laptops often use randomised MACs that have no vendor.
* UDP silence is reported as `open|filtered`, never as open. A host that drops every packet cannot be seen by any scanner; ARP from the same segment is the most reliable way to find those.
* Needs no root. Root adds an ARP sweep and (with nmap) OS fingerprints. IPv4 sweeps only; IPv6 hosts can be scanned if you enter them explicitly.
* Windows/macOS: ICMP, ARP-table and route parsing are implemented from the platforms' documented output formats and unit-tested on samples, but were not run on those systems.

### Subdomain discovery (Web Application scans)
Tick **Also discover and scan subdomains** under the Web Application scan type. It finds names two ways - certificate
transparency (crt.sh, passive) and DNS brute force against a built-in word list (~250 common names) plus any you add -
resolves each one, and reports:
* **in-scope hosts**, which are actively scanned the same way the main target is (headers, CORS, methods, etc.);
* **third-party-hosted names** (CNAME to GitHub Pages, Shopify, Azure App Service, AWS, Netlify, ...) - listed but
  **not actively scanned by default** (tick *Scan third-party-hosted names too* to include them), since they are not
  the target's own infrastructure;
* **possible subdomain takeovers** - a CNAME to a takeover-prone platform that no longer resolves, meaning the name
  could potentially be claimed by someone else - reported regardless of the setting above, since the report itself
  is the useful part.

Wildcard DNS (a zone that answers for everything) is detected and brute-force noise from it is filtered out. Every
discovered name is still checked against the scope deny list before it is touched. The written authorization you
record for the main target is worded to explicitly cover discovered subdomains, so there is one consent step, not
one per subdomain. A scan is capped (default 40) to the subdomains it actively probes; the rest are still listed.

**Honest limits:** crt.sh is public, free and sometimes slow or rate-limited (reported, not silently ignored).
Resolution uses whatever your `/etc/resolv.conf` names, falling back to 1.1.1.1 / 8.8.8.8, so every probed name is
visible to that resolver like any DNS lookup. The brute-force list is not exhaustive. This feature could not be
tested against the live crt.sh service or real DNS from the environment it was built in; it is unit-tested against
a fake certificate-transparency response and a local fake DNS server.

## 7. Agents

### Architecture
Run the manager **as its own service** (recommended) so UI restarts do not interrupt agents or schedules:
```bash
python af_api_server.py     # agent API (+ enrollment listener when TLS and a CA exist)
python af_worker.py         # fleet schedules, lease requeue, retention pruning
AF_EXTERNAL_API=1 AF_EXTERNAL_WORKER=1 ./start.sh    # UI only
```
Without those variables the UI still starts the API embedded (loopback only by default). Local-machine scheduled scans always run
inside the UI process. Failure to bind a port, a refused plaintext config, or a missing module is shown in the Agents tab.

### Network exposure (changed)
The API binds **127.0.0.1** by default and **refuses plain HTTP on any other address** (`AF_API_HOST`) unless `AF_ALLOW_PLAINTEXT=1`
(lab only). For real use enable TLS (section 8).

### Enrolling an agent
1. **🛰️ Agents** → copy the enrollment token. Tokens now **expire (24 h) and are limited-use (10)** by default and can carry tags
   (*Manage enrollment tokens*). The token is **never** exported to the environment of scan subprocesses.
2. Copy `af_agent.py` + `af_checks.py` + `af_version.py` — or `python build_agent.py` → `af_agent.pyz` — to the endpoint;
   `pip install -r requirements-agent.txt`.
3. Run (token via environment, never on the command line):
```bash
AF_ENROLL_TOKEN='<token>' python3 af_agent.py --manager https://MANAGER:8765 --ca-bundle ca.crt --enroll-url https://MANAGER:8766
```
   With `--enroll-url` the agent **generates its own private key**, sends a CSR and receives a **short-lived (30 day) client certificate
   that renews automatically**. The legacy path (`--client-cert/--client-key` from `af_pki.py issue-agent`) still works.
4. Service: add `--install-service` (keeps every option except the token; hardened systemd unit with a capability bound).
   Windows: the script prints the `nssm` commands. Agent state lives in `~/.af_agent` (service: `/var/lib/af_agent`), rotating log in `agent.log`.
5. Re-installing an agent that lost its state: an administrator must **release** it (Agents → *Agent administration*) — a leaked
   enrollment token can no longer take over an existing identity. `disable` and `revoke certificate` are there too.

Commands are Ed25519-signed with nonce + expiry (public key trusted on first enrollment; pin with `--manager-pubkey`). Results are
retried, spooled to disk when the manager is down, gzip-compressed, and idempotent. Commands whose agent died are requeued (3 tries).

### Live response and forensics
`kill_process`, `quarantine_file`, `isolate_host` need an **admin to request and a different admin to approve**, and the agent must be
started with `--allow-live-response`. Isolation always keeps the manager reachable, auto-releases after its TTL (also after a reboot)
and rolls back on failure. `collect_triage` builds a read-only artifact package with a SHA-256 manifest and uploads it with hash
verification; each receipt is written to the hash-chained **custody log**. `run_ioc_sweep` (SHA-256 / YARA), `run_scap` (OpenSCAP)
and OSV-based package matching (Agents → *Vulnerability matching*, uses asset criticality and exposure) are available too.
Memory acquisition is **not** implemented.

## 8. Production hardening
```bash
export AF_CA_PASSPHRASE='...'                                   # encrypts the CA key (from a secret manager)
python af_pki.py init-ca --encrypt-key
python af_pki.py issue-server --cn manager.example.local --san DNS:manager.example.local --san IP:10.0.0.5
export AF_TLS_CERT=~/.auditforensics/pki/server.crt AF_TLS_KEY=~/.auditforensics/pki/server.key
export AF_TLS_CLIENT_CA=~/.auditforensics/pki/ca.crt            # client certificates mandatory on the agent port
```
The enrollment listener (`AF_ENROLL_PORT`, default 8766) is TLS-only so agents without a certificate can enroll; it needs the CA key
online on the manager (hence the passphrase). Agent certificates are bound to the agent identity: a stolen token with a different
certificate is rejected, and a revoked certificate stops working immediately.

**Encryption at rest** (`python af_vault.py status`): envelope encryption, AES-256-GCM, key IDs, context-bound ciphertexts.
Key-encryption key from `AF_DB_KEY` (passphrase), the OS keyring (`AF_KEK_BACKEND=keyring`) or `vault.key`. Rotate with
`python af_vault.py rotate && python af_vault.py reencrypt` (or in the UI); that also upgrades legacy `enc:v1` data.
**Lost key = lost data; back it up separately.** KMS/HSM wrapping is not implemented.

**Evidence:** compliance packs now include `manifest.json.sig` (Ed25519) and the public key; see `VERIFY.txt` in the pack.

**Integrations:** `~/.auditforensics/integrations.json` (see `af_integrations.py`): syslog CEF/OCSF, Splunk HEC, Slack/webhook, email,
Jira, ServiceNow. New High/Critical findings and drift alert with a 24 h de-duplication window; secrets come from environment variables.

**UI exposure:** `start.sh` binds 127.0.0.1; use a TLS reverse proxy or VPN. Keep `AF_UI_AUTH` unset.
**Files:** `~/.auditforensics/` is owner-only. Keep it out of cloud-sync folders.

## 9. Keep it running
systemd units (adjust paths/user):
```ini
# /etc/systemd/system/af-api.service        ExecStart=/opt/af/venv/bin/python af_api_server.py
# /etc/systemd/system/af-worker.service     ExecStart=/opt/af/venv/bin/python af_worker.py
# /etc/systemd/system/af-ui.service         ExecStart=/opt/af/venv/bin/streamlit run auditforensics_web.py --server.address 127.0.0.1 --server.port 8501 --server.headless true
[Service]
User=af
WorkingDirectory=/opt/af
EnvironmentFile=/etc/af/af.env        # chmod 600: AF_DB_KEY, AF_CA_PASSPHRASE, AF_TLS_*, AF_EXTERNAL_API=1 ... 
Restart=always
```
Docker: `docker compose up -d` (see `docker-compose.yml`; the image has not been built in the authoring environment).

## 10. Smoke-test checklist
- [ ] Setup code accepted; wrong password rejected; MFA enrolled and recovery codes saved
- [ ] `auditor` cannot scan; a permission change is refused server-side
- [ ] `10.0.0.0/8` is refused; a public target asks for authorization
- [ ] Local scan finishes; Results shows no unexplained *Scan Coverage* errors; History → Trend draws
- [ ] Compliance pack contains `poam.csv`, `manifest.json`, `manifest.json.sig`, `sbom.cdx.json`
- [ ] Agents tab: token with expiry; test agent *online*; `ping` + `run_local_audit` complete with a coverage line
- [ ] A second `register` with the same token for an existing agent returns *409*
- [ ] `python af_vault.py status` → mode, primary key; *Verify audit chain* buttons say intact

## 11. Troubleshooting
| Symptom | Fix |
|---|---|
| Agents tab: "refusing to serve … plain HTTP" | Configure TLS (§8), bind to 127.0.0.1, or `AF_ALLOW_PLAINTEXT=1` for a lab |
| Agents tab: "cannot listen on …" | Port in use: change `AF_AGENT_API_PORT` / `AF_ENROLL_PORT` |
| Agent: `409 already enrolled` | Release the agent in Agents → Agent administration, then restart it |
| Agent: `403 Invalid enroll token` | Token expired, used up or rotated: copy the current one |
| Agent: `rejected by agent: bad signature / replayed / expired` | Wrong pinned key, replay, or clock skew > 5 min: fix time sync |
| Agent: `certificate verify failed` | Use `--ca-bundle ca.crt`; the SAN must match the manager host/IP |
| Findings show `[encrypted: wrong key, or ciphertext was moved/tampered]` | `AF_DB_KEY`/`vault.key`/keyring changed, or rows were edited |
| Locked out | Wait 15 min or `python -c "import af_auth,os;af_auth.update_user(os.path.expanduser('~/.auditforensics/history.db'),'USER','cli',failed_count=0,locked_until=0)"` |
| Lost the only admin password (app stopped) | `python -c "import af_auth,os;db=os.path.expanduser('~/.auditforensics/history.db');af_auth.update_user(db,'USER','cli',pw_hash=af_auth.hash_password('NEW-LONG-PASSPHRASE'),must_change_pw=1)"` |
| Scheduled scans never run | The UI process must run (local schedules); fleet schedules need the UI or `af_worker.py` |

## 12. Environment variable reference
| Variable | Default | Meaning |
|---|---|---|
| `AF_UI_AUTH` | `1` | `0` disables login (lab only) |
| `AF_ADMIN_USER` / `AF_ADMIN_PASSWORD` | – | headless first admin |
| `AF_REQUIRE_MFA`, `AF_MAX_LOGIN_FAILS`, `AF_LOCKOUT_MIN`, `AF_UI_IDLE_MIN`, `AF_MIN_PW`, `AF_STEPUP_MIN` | 0 / 5 / 15 / 30 / 12 / 5 | login policy |
| `AF_HIBP`, `AF_BREACHED_FILE` | `1`, – | breached-password check (online range query / offline list) |
| `AF_SSO`, `AF_SSO_ONLY`, `AF_SSO_PROVIDER`, `AF_SSO_ROLE_CLAIM`, `AF_SSO_ROLE_MAP`, `AF_SSO_DEFAULT_ROLE` | `0` … | OpenID Connect sign-in |
| `AF_API_HOST` / `AF_AGENT_API_PORT` | `127.0.0.1` / `8765` | agent API bind |
| `AF_ALLOW_PLAINTEXT` | `0` | allow plain HTTP on a non-loopback address |
| `AF_TLS_CERT` / `AF_TLS_KEY` / `AF_TLS_CLIENT_CA` | – | HTTPS / mutual TLS |
| `AF_ENROLL_PORT`, `AF_PKI_DIR`, `AF_AGENT_CERT_DAYS`, `AF_CA_PASSPHRASE` | `8766`, `~/.auditforensics/pki`, `30`, – | CSR enrollment / CA |
| `AF_ENROLL_TTL_HOURS`, `AF_ENROLL_MAX_USES` | `24`, `10` | defaults for auto-created tokens |
| `AF_EXTERNAL_API`, `AF_EXTERNAL_WORKER` | `0` | run API / fleet scheduler outside the UI |
| `AF_TRUSTED_PROXIES` | – | proxies whose `X-Forwarded-For` is trusted (rate limiting) |
| `AF_LEASE_SECONDS`, `AF_MAX_ATTEMPTS`, `AF_CMD_TTL_SECONDS` | `300`, `3`, `900` | command leases / signature lifetime |
| `AF_MAX_BODY_MB`, `AF_MAX_ARTIFACT_MB` | `64`, `512` | request size limits |
| `AF_RETENTION_DAYS`, `AF_AUDIT_RETENTION_DAYS`, `AF_INVENTORY_KEEP` | `365`, `730`, `5` | pruning |
| `AF_DB_KEY`, `AF_KEK_BACKEND`, `AF_VAULT` | – / auto / `1` | encryption at rest |
| `AF_SCAN_ALLOW`, `AF_SCAN_DENY`, `AF_MAX_SCAN_HOSTS`, `AF_SCAN_RATE`, `AF_SCAN_RATE_PER_HOST`, `AF_SCAN_REQUIRE_TICKET` | – / – / `4096` / `0` / `100` / `0` | scan guardrails |
| `AF_SYSLOG` | – | mirror audit rows to syslog (`udp://`, `tcp://`, `unix://`) |
| `NVD_API_KEY` | – | faster CVE lookups (also used by the Network Map) |
| `AF_WHATSAPP_TOKEN`, `AF_WHATSAPP_PHONE_ID`, `AF_WHATSAPP_API_VERSION`, `AF_WHATSAPP_TEMPLATE`, `AF_WHATSAPP_TEMPLATE_LANG` | – | WhatsApp delivery of consent PDFs |
| `AF_AI_REDACT`, `AF_AI_LOCAL_ONLY`, `AF_OLLAMA_URL`, `AF_OLLAMA_MODEL`, `AF_GROQ_MODEL`, `AF_OPENAI_MODEL`, `AF_GEMINI_MODEL` | `1`, `0`, … | AI summaries |
| `AF_DB_PATH`, `AF_HOME` | `~/.auditforensics/history.db`, `~/.auditforensics` | data locations |
| `AF_ALLOW_LIVE_RESPONSE` (agent) | `0` | same as `--allow-live-response` |
| `AF_INTEL`, `AF_SLA_DAYS`, `AF_MAX_EXCEPTION_DAYS`, `AF_EVIDENCE_KEY`, `AF_SCHEDULER`, `NVD_API_KEY` | as before | unchanged |

## 13. Upgrading from v10.0–10.4
Copy the new files over the old ones and keep `~/.auditforensics/`. Automatic: schema migrations, legacy plaintext agent tokens hashed on
first use, naive-local timestamps in agents/commands/schedules/exceptions converted to UTC, old `enc:v1` data stays readable.
**Behaviour changes to plan for:**
1. The agent API binds **127.0.0.1** and refuses plain HTTP elsewhere → set TLS or `AF_API_HOST`+`AF_ALLOW_PLAINTEXT=1` (lab).
2. Existing enrollment tokens are treated as legacy (no expiry): **rotate once**. Re-enrolling an existing agent now needs an admin release.
3. Agents need `af_checks.py` (or the `.pyz`). Old agents (1.3.x) still work against the new manager but without signed commands.
4. `scans.timestamp` values from older releases stay in local time; new ones are UTC. Run `python af_vault.py reencrypt` to upgrade old data.
5. `cryptography` ≥ 50; admins need a second admin to approve live-response actions; a setup code is required only on a fresh database.
