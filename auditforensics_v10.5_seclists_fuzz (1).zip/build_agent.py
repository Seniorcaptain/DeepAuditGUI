#!/usr/bin/env python3
"""Build a single-file agent: python build_agent.py  ->  af_agent.pyz   (run with: python3 af_agent.pyz --manager ...)

The bundle contains af_agent.py, af_checks.py and af_version.py, so an endpoint needs only Python 3.9+ plus
`pip install requests psutil cryptography`. For a Python-free binary use PyInstaller on the bundle:
    pip install pyinstaller && pyinstaller --onefile --name af_agent agent_entry.py   (see packaging/README.md)
"""
import shutil, sys, tempfile, zipapp
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = ["af_agent.py", "af_checks.py", "af_version.py"]


def build(out=None):
    out = Path(out or ROOT / "af_agent.pyz")
    with tempfile.TemporaryDirectory() as d:
        for f in FILES:
            shutil.copy(ROOT / f, Path(d) / f)
        (Path(d) / "__main__.py").write_text("import af_agent\naf_agent.main()\n")
        zipapp.create_archive(d, out, interpreter="/usr/bin/env python3", compressed=True)
    out.chmod(0o755)
    return out


if __name__ == "__main__":
    print("built", build(sys.argv[1] if len(sys.argv) > 1 else None))
