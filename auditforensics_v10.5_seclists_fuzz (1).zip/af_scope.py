#!/usr/bin/env python3
"""Scan guardrails: scope allow/deny lists, size caps, blackout windows, authorization records, rate limits.

Configuration: AF_HOME/scope.json and/or environment
  {"allow": ["10.0.0.0/8", "*.corp.example"], "deny": ["10.9.0.0/16"], "max_hosts": 4096,
   "rate_per_sec": 0, "rate_per_host": 100, "require_ticket": false,
   "blackout": [{"days": ["Mon","Tue","Wed","Thu","Fri"], "start": "08:00", "end": "18:00"}]}   (times are UTC)
  AF_SCAN_ALLOW / AF_SCAN_DENY (comma lists), AF_MAX_SCAN_HOSTS, AF_SCAN_RATE, AF_SCAN_RATE_PER_HOST
Defaults: private/loopback targets are in scope, anything public needs a recorded authorization, and a single
scan may not exceed 4096 hosts (so a typo like 10.0.0.0/8 cannot exhaust memory or hammer a network).
"""
import fnmatch, ipaddress, json, os, re, socket, sqlite3, threading, time
from dataclasses import dataclass, field
from datetime import datetime
from urllib.parse import urlparse

from af_util import af_home, utc_iso, utcnow

DEFAULT_MAX_HOSTS = 4096
_HOST_RE = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$")


class ScopeError(ValueError):
    """Target rejected by policy or malformed."""


# ---------------------------------------------------------------- policy
def load_policy():
    p = {"allow": [], "deny": [], "max_hosts": DEFAULT_MAX_HOSTS, "rate_per_sec": 0.0, "rate_per_host": 100.0,
         "require_ticket": False, "blackout": []}
    try:
        p.update(json.loads((af_home() / "scope.json").read_text()))
    except (OSError, ValueError):
        pass
    env = os.environ
    if env.get("AF_SCAN_ALLOW"):
        p["allow"] = [x.strip() for x in env["AF_SCAN_ALLOW"].split(",") if x.strip()]
    if env.get("AF_SCAN_DENY"):
        p["deny"] = [x.strip() for x in env["AF_SCAN_DENY"].split(",") if x.strip()]
    for key, var, cast in (("max_hosts", "AF_MAX_SCAN_HOSTS", int), ("rate_per_sec", "AF_SCAN_RATE", float),
                           ("rate_per_host", "AF_SCAN_RATE_PER_HOST", float)):
        if env.get(var):
            p[key] = cast(env[var])
    if env.get("AF_SCAN_REQUIRE_TICKET") == "1":
        p["require_ticket"] = True
    return p


# ---------------------------------------------------------------- parsing / expansion
def _valid_host(h):
    if not h or h.startswith("-") or not _HOST_RE.match(h):
        raise ScopeError(f"invalid host name or address: {h!r}")
    return h


def parse_range(spec):
    """-> (kind, payload, count) without expanding. kind: net | span | host."""
    spec = (spec or "").strip()
    if "/" in spec:
        try:
            net = ipaddress.ip_network(spec, strict=False)
        except ValueError:
            raise ScopeError(f"invalid network: {spec!r}")
        n = net.num_addresses - (2 if net.version == 4 and net.prefixlen < 31 else 0)
        return "net", net, max(n, 1)
    if re.fullmatch(r"[0-9.]+\s*-\s*[0-9.]+", spec):
        try:
            s, e = (int(ipaddress.IPv4Address(x.strip())) for x in spec.split("-", 1))
        except ValueError:
            raise ScopeError(f"invalid range: {spec!r}")
        if e < s:
            raise ScopeError("range end is before its start")
        return "span", (s, e), e - s + 1
    try:
        ipaddress.ip_address(spec)
    except ValueError:
        _valid_host(spec)
    return "host", spec, 1


def expand_ip_range(range_str, max_hosts=None):
    """Expand a CIDR / dash range / single target to a list, refusing oversized ranges *before* allocating anything
    and rejecting anything that is not an IP or a plain host name (blocks argument injection such as '-f')."""
    cap = max_hosts or load_policy()["max_hosts"]
    kind, payload, count = parse_range(range_str)
    if count > cap:
        raise ScopeError(f"{range_str!r} expands to {count:,} hosts, above the limit of {cap:,}. Split the range, "
                         f"or raise AF_MAX_SCAN_HOSTS / scope.json max_hosts deliberately.")
    if kind == "net":
        return [str(i) for i in payload.hosts()] or [str(payload.network_address)]
    if kind == "span":
        s, e = payload
        return [str(ipaddress.IPv4Address(i)) for i in range(s, e + 1)]
    return [payload]


# ---------------------------------------------------------------- evaluation
@dataclass
class Decision:
    allowed: bool = True
    needs_authorization: bool = False
    hosts: int = 0
    reasons: list = field(default_factory=list)
    public_targets: list = field(default_factory=list)


def _entry_matches(entry, host, addrs):
    entry = entry.strip()
    if "/" in entry:
        try:
            net = ipaddress.ip_network(entry, strict=False)
            return any(ipaddress.ip_address(a) in net for a in addrs if _same_family(a, net))
        except ValueError:
            return False
    try:
        ip = ipaddress.ip_address(entry)
        return any(a == str(ip) for a in addrs)
    except ValueError:
        return bool(host) and fnmatch.fnmatch(host.lower(), entry.lower())


def _same_family(addr, net):
    try:
        return ipaddress.ip_address(addr).version == net.version
    except ValueError:
        return False


def _target_host(t):
    t = t.strip()
    if "://" in t:
        return urlparse(t).hostname or ""
    return t


def _resolve(host, resolver):
    try:
        return sorted({ai[4][0].split("%")[0] for ai in resolver(host, None)})
    except OSError:
        return []


def in_blackout(policy, now=None):
    now = now or utcnow()
    for w in policy.get("blackout", []):
        days = w.get("days", "*")
        if days != "*" and now.strftime("%a") not in days:
            continue
        s, e = w.get("start", "00:00"), w.get("end", "23:59")
        cur = now.strftime("%H:%M")
        if (s <= cur <= e) if s <= e else (cur >= s or cur <= e):
            return f"scans are blocked right now by a blackout window ({','.join(days) if days != '*' else 'daily'} {s}-{e} UTC)"
    return ""


def evaluate(targets, policy=None, now=None, resolver=socket.getaddrinfo):
    """Check a list of targets (CIDR, range, IP, host name or URL) against the scope policy."""
    pol = policy or load_policy()
    d = Decision()
    bl = in_blackout(pol, now)
    if bl:
        d.allowed = False
        d.reasons.append(bl)
    for raw in targets:
        t = _target_host(raw)
        if not t:
            continue
        try:
            kind, payload, count = parse_range(t)
        except ScopeError as e:
            d.allowed = False; d.reasons.append(str(e)); continue
        d.hosts += count
        host = payload if kind == "host" else ""
        if kind == "net":
            addrs, public = [str(payload.network_address), str(payload.broadcast_address)], not (payload.is_private or payload.is_loopback or payload.is_link_local)
        elif kind == "span":
            addrs = [str(ipaddress.IPv4Address(payload[0])), str(ipaddress.IPv4Address(payload[1]))]
            public = any(ipaddress.ip_address(a).is_global for a in addrs)
        else:
            try:
                ipaddress.ip_address(host); addrs = [host]
            except ValueError:
                addrs = _resolve(host, resolver)
                if not addrs:
                    d.needs_authorization = True
                    d.reasons.append(f"{host}: does not resolve - treated as external")
            public = (not addrs) or any(ipaddress.ip_address(a).is_global for a in addrs)
        if any(_entry_matches(e, host, addrs) for e in pol["deny"]):
            d.allowed = False; d.reasons.append(f"{raw}: matches the deny list"); continue
        if pol["allow"] and not any(_entry_matches(e, host, addrs) for e in pol["allow"]):
            d.allowed = False; d.reasons.append(f"{raw}: outside the allowed scope"); continue
        if public:
            d.needs_authorization = True
            d.public_targets.append(raw)
    if d.hosts > pol["max_hosts"]:
        d.allowed = False
        d.reasons.append(f"{d.hosts:,} hosts exceeds the per-scan limit of {pol['max_hosts']:,}")
    if d.public_targets:
        d.reasons.append("public / external targets: written authorization must be recorded first")
    return d


# ---------------------------------------------------------------- authorization records
def init_authorizations(path):
    c = sqlite3.connect(str(path), timeout=30)
    c.execute("""CREATE TABLE IF NOT EXISTS scan_authorizations (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, username TEXT,
                 scan_type TEXT, targets TEXT, reason TEXT, ticket TEXT)""")
    cols = {r[1] for r in c.execute("PRAGMA table_info(scan_authorizations)")}
    for col, ddl in (("whatsapp_to", "TEXT"), ("whatsapp_status", "TEXT"), ("whatsapp_sent_at", "TEXT"), ("pdf_sha256", "TEXT")):
        if col not in cols:
            c.execute(f"ALTER TABLE scan_authorizations ADD COLUMN {col} {ddl}")
    c.commit(); c.close()


def record_authorization(path, username, scan_type, targets, reason, ticket="", policy=None):
    pol = policy or load_policy()
    if len((reason or "").strip()) < 10:
        raise ScopeError("describe why you are authorised to scan these targets (at least 10 characters)")
    if pol["require_ticket"] and not (ticket or "").strip():
        raise ScopeError("a ticket / change reference is required by policy")
    init_authorizations(path)
    c = sqlite3.connect(str(path), timeout=30)
    cur = c.execute("INSERT INTO scan_authorizations (ts,username,scan_type,targets,reason,ticket) VALUES (?,?,?,?,?,?)",
                    (utc_iso(), username, scan_type, json.dumps(list(targets))[:2000], reason.strip()[:500], (ticket or "").strip()[:100]))
    c.commit(); rid = cur.lastrowid; c.close()
    return rid


def list_authorizations(path, limit=200):
    init_authorizations(path)
    c = sqlite3.connect(str(path), timeout=30); c.row_factory = sqlite3.Row
    rows = [dict(r) for r in c.execute("SELECT * FROM scan_authorizations ORDER BY id DESC LIMIT ?", (limit,))]
    c.close()
    return rows


def get_authorization(path, rid):
    init_authorizations(path)
    c = sqlite3.connect(str(path), timeout=30); c.row_factory = sqlite3.Row
    row = c.execute("SELECT * FROM scan_authorizations WHERE id=?", (rid,)).fetchone()
    c.close()
    return dict(row) if row else None


def record_whatsapp_send(path, rid, to, status, pdf_sha256=""):
    """Persist the outcome of a consent-PDF WhatsApp send (or attempt) against its authorization row."""
    init_authorizations(path)
    c = sqlite3.connect(str(path), timeout=30)
    c.execute("UPDATE scan_authorizations SET whatsapp_to=?, whatsapp_status=?, whatsapp_sent_at=?, pdf_sha256=COALESCE(NULLIF(?,''),pdf_sha256) WHERE id=?",
             (to, status, utc_iso(), pdf_sha256, rid))
    c.commit(); c.close()


def host_denied(host, addrs, policy=None):
    """True if a host name or any of its addresses match the scope deny list. For checking items discovered
    *during* an already-authorised scan (e.g. subdomains) without re-running the full evaluate()/authorization
    logic (size cap, public-target prompt) for each one."""
    pol = policy or load_policy()
    return any(_entry_matches(e, host, addrs or []) for e in pol["deny"])


# ---------------------------------------------------------------- rate limiting
class RateLimiter:
    """Token bucket. rate <= 0 means unlimited."""

    def __init__(self, rate, burst=None):
        self.rate, self.burst = float(rate), float(burst or max(rate, 1))
        self.tokens, self.t, self.lock = self.burst, time.monotonic(), threading.Lock()

    def acquire(self):
        if self.rate <= 0:
            return
        while True:
            with self.lock:
                now = time.monotonic()
                self.tokens = min(self.burst, self.tokens + (now - self.t) * self.rate)
                self.t = now
                if self.tokens >= 1:
                    self.tokens -= 1
                    return
                wait = (1 - self.tokens) / self.rate
            time.sleep(wait)


_global = [None]
_per_host = {}
_lock = threading.Lock()


def throttle(host=""):
    """Call before every outbound probe (connect, request). Applies the global and per-target limits."""
    pol = load_policy() if _global[0] is None else None
    with _lock:
        if _global[0] is None:
            _global[0] = (RateLimiter(pol["rate_per_sec"]), pol["rate_per_host"])
        g, per = _global[0]
        lim = _per_host.setdefault(host, RateLimiter(per)) if host and per > 0 else None
    g.acquire()
    if lim:
        lim.acquire()


def reset_limits():
    with _lock:
        _global[0] = None
        _per_host.clear()
