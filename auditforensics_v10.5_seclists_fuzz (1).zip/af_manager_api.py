#!/usr/bin/env python3
"""AuditForensics Manager API - FastAPI service for agents.

Security model (v10.5):
  * agent tokens are stored as SHA-256; with mutual TLS an agent is also bound to its certificate fingerprint
  * enrollment tokens are short-lived / limited-use and may carry tags; re-enrolling an existing agent needs an
    admin release (or the agent's current token) so a leaked token cannot hijack an identity
  * /results only accepts data for commands that belong to the calling agent; sizes and fields are bounded
  * commands are Ed25519-signed with nonce + expiry; leases requeue work from crashed agents
  * second HTTPS listener (enroll_app) issues short-lived client certificates from agent-generated CSRs
"""
import asyncio, collections, datetime, gzip, hashlib, hmac, ipaddress, json, os, secrets, sqlite3, threading, time, uuid, zlib
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

import af_audit, af_signing
from af_util import af_home, parse_ts, utc_iso, utcnow
from af_version import API_VERSION

DB_PATH = Path(os.environ.get("AF_DB_PATH") or (Path.home() / ".auditforensics" / "history.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
try:
    import af_vault as _vault
except Exception:
    _vault = None

MAX_FINDINGS_PER_POST = 50000
MAX_BODY = int(float(os.environ.get("AF_MAX_BODY_MB", "64")) * 1024 * 1024)
MAX_ARTIFACT = int(float(os.environ.get("AF_MAX_ARTIFACT_MB", "512")) * 1024 * 1024)
LEASE_SECONDS = int(os.environ.get("AF_LEASE_SECONDS", "300"))
MAX_ATTEMPTS = int(os.environ.get("AF_MAX_ATTEMPTS", "3"))
CMD_TTL_SECONDS = int(os.environ.get("AF_CMD_TTL_SECONDS", "900"))
RETENTION_DAYS = int(os.environ.get("AF_RETENTION_DAYS", "365"))
AUDIT_RETENTION_DAYS = int(os.environ.get("AF_AUDIT_RETENTION_DAYS", "730"))
INVENTORY_KEEP = int(os.environ.get("AF_INVENTORY_KEEP", "5"))
ENROLL_TTL_HOURS = float(os.environ.get("AF_ENROLL_TTL_HOURS", "24"))
ENROLL_MAX_USES = int(os.environ.get("AF_ENROLL_MAX_USES", "10"))
_DEFAULT_TOKENS = {"", "change-me-in-ui"}
_REG_HITS = collections.defaultdict(collections.deque)
_REG_LOCK = threading.Lock()
_last_sweep = [0.0]

STATUSES = {"PASS", "FAIL", "WARNING", "INFO", "ERROR", "SKIPPED", "N/A", "ACCEPTED"}
RISKS = {"critical": "Critical", "high": "High", "medium": "Medium", "low": "Low", "info": "Info"}
FIELD_CAPS = {"category": 100, "check_name": 300, "details": 4000, "recommendation": 2000, "mitre": 100,
              "check_id": 80, "sha256": 64}

# command name -> long-running lease multiplier
LEASE_MULT = {"run_scap": 4, "collect_triage": 4, "run_ioc_sweep": 4, "run_file_scan": 2, "run_local_audit": 2}
LIVE_RESPONSE = {"kill_process", "quarantine_file", "isolate_host", "release_isolation"}
SIMPLE_COMMANDS = {"ping", "collect_inventory", "run_local_audit", "run_network_scan", "run_process_scan",
                   "run_service_scan", "release_isolation"}


def _enc(s, aad=""):
    return _vault.encrypt_text(s, aad) if _vault else s


def _h(token):
    """Agent tokens are stored as SHA-256 (CWE-256): a DB leak no longer yields usable credentials."""
    return "sha256:" + hashlib.sha256(token.encode()).hexdigest()


# ---------------------------------------------------------------- request plumbing
def client_ip(request):
    peer = request.client.host if request.client else "?"
    trusted = {x.strip() for x in os.environ.get("AF_TRUSTED_PROXIES", "").split(",") if x.strip()}
    if peer in trusted:
        xff = [x.strip() for x in request.headers.get("x-forwarded-for", "").split(",") if x.strip()]
        for hop in reversed(xff):
            if hop not in trusted:
                return hop
    return peer


def _rate_limit(ip, limit=10, window=60):
    now = time.time()
    with _REG_LOCK:
        if now - _last_sweep[0] > window:                 # evict idle IPs so the dict cannot grow without bound
            _last_sweep[0] = now
            for k in [k for k, q in _REG_HITS.items() if not q or now - q[-1] > window]:
                del _REG_HITS[k]
        q = _REG_HITS[ip]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            raise HTTPException(429, "Too many enrollment attempts")
        q.append(now)


class BodyLimitMiddleware:
    """Pure-ASGI body cap + gzip request support (decompression is size-limited: no zip bombs)."""

    def __init__(self, app, default_limit=MAX_BODY, path_limits=None):
        self.app, self.default, self.paths = app, default_limit, path_limits or {}

    def _limit(self, path):
        for prefix, lim in self.paths.items():
            if path.startswith(prefix):
                return lim
        return self.default

    async def _reject(self, send, code, msg):
        body = json.dumps({"detail": msg}).encode()
        await send({"type": "http.response.start", "status": code,
                    "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode())]})
        await send({"type": "http.response.body", "body": body})

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        limit = self._limit(scope["path"])
        headers = dict(scope["headers"])
        cl = headers.get(b"content-length")
        if cl and cl.isdigit() and int(cl) > limit:
            return await self._reject(send, 413, "request body too large")
        if headers.get(b"content-encoding", b"").lower() == b"gzip":
            d, out, raw = zlib.decompressobj(16 + zlib.MAX_WBITS), bytearray(), 0
            while True:
                m = await receive()
                if m["type"] != "http.request":
                    break
                raw += len(m.get("body", b""))
                if raw > limit:
                    return await self._reject(send, 413, "request body too large")
                try:
                    out += d.decompress(m.get("body", b""), limit + 1 - len(out))
                except zlib.error:
                    return await self._reject(send, 400, "invalid gzip body")
                if len(out) > limit or d.unconsumed_tail:
                    return await self._reject(send, 413, "decompressed body too large")
                if not m.get("more_body"):
                    break
            scope = dict(scope)
            scope["headers"] = [(k, v) for k, v in scope["headers"] if k not in (b"content-encoding", b"content-length")] \
                + [(b"content-length", str(len(out)).encode())]
            sent = [False]

            async def replay():
                if not sent[0]:
                    sent[0] = True
                    return {"type": "http.request", "body": bytes(out), "more_body": False}
                return await receive()
            return await self.app(scope, replay, send)
        total = [0]

        async def limited():
            m = await receive()
            if m["type"] == "http.request":
                total[0] += len(m.get("body", b""))
                if total[0] > limit:
                    raise HTTPException(413, "request body too large")
            return m
        return await self.app(scope, limited, send)


app = FastAPI(title="AuditForensics Manager API", version=API_VERSION)
app.add_middleware(BodyLimitMiddleware, default_limit=MAX_BODY, path_limits={"/artifacts/": MAX_ARTIFACT})


# ---------------------------------------------------------------- database
def db():
    c = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
    c.execute("PRAGMA journal_mode=WAL")
    c.row_factory = sqlite3.Row
    return c


def _add_col(c, table, col, ddl):
    if col not in {r[1] for r in c.execute(f"PRAGMA table_info({table})")}:
        c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")


def audit(event, agent_id="", ip="", detail=""):
    af_audit.append(DB_PATH, "api_audit", ts=utc_iso(), event=event, agent_id=agent_id, ip=ip, detail=str(detail)[:300])


def init_tables():
    c = db()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS agents (
            id TEXT PRIMARY KEY, hostname TEXT, os TEXT, os_full TEXT,
            arch TEXT, agent_version TEXT, ip TEXT, token TEXT UNIQUE,
            registered_at TEXT, last_seen TEXT, status TEXT DEFAULT 'offline',
            tags TEXT DEFAULT '', cpu REAL DEFAULT 0, memory REAL DEFAULT 0,
            disk REAL DEFAULT 0, uptime INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS agent_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id TEXT NOT NULL,
            command TEXT NOT NULL, params TEXT DEFAULT '{}',
            status TEXT DEFAULT 'pending', created_at TEXT, started_at TEXT,
            completed_at TEXT, summary TEXT
        );
        CREATE TABLE IF NOT EXISTS agent_findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id TEXT NOT NULL,
            command_id INTEGER, category TEXT, check_name TEXT, status TEXT,
            risk TEXT, details TEXT, recommendation TEXT, mitre TEXT, timestamp TEXT
        );
        CREATE TABLE IF NOT EXISTS agent_inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT, agent_id TEXT NOT NULL,
            data TEXT, timestamp TEXT
        );
        CREATE TABLE IF NOT EXISTS api_audit (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT,
            event TEXT, agent_id TEXT, ip TEXT, detail TEXT);
        CREATE TABLE IF NOT EXISTS enrollment_tokens (
            token TEXT PRIMARY KEY, created_at TEXT, description TEXT);
        CREATE TABLE IF NOT EXISTS result_receipts (result_id TEXT PRIMARY KEY, agent_id TEXT, command_id INTEGER, ts TEXT);
        CREATE TABLE IF NOT EXISTS revoked_certs (fingerprint TEXT PRIMARY KEY, agent_id TEXT, reason TEXT, ts TEXT);
        CREATE TABLE IF NOT EXISTS custody_log (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, agent_id TEXT,
            command_id INTEGER, action TEXT, actor TEXT, detail TEXT, sha256 TEXT);
        CREATE TABLE IF NOT EXISTS audit_checkpoints (tbl TEXT, last_hash TEXT, ts TEXT, deleted INTEGER);
        CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);
        CREATE INDEX IF NOT EXISTS idx_commands_status ON agent_commands(status);
        CREATE INDEX IF NOT EXISTS idx_findings_agent ON agent_findings(agent_id);
    """)
    for t, col, ddl in [
        ("agents", "agent_uid", "TEXT"), ("agents", "cert_fp", "TEXT"), ("agents", "reenroll_until", "TEXT"),
        ("agents", "disabled", "INTEGER DEFAULT 0"), ("agents", "criticality", "TEXT DEFAULT 'medium'"),
        ("agents", "exposure", "TEXT DEFAULT 'internal'"),
        ("agent_commands", "attempts", "INTEGER DEFAULT 0"), ("agent_commands", "lease_until", "TEXT"),
        ("agent_commands", "coverage", "TEXT"), ("agent_commands", "requested_by", "TEXT"),
        ("agent_commands", "approved_by", "TEXT"),
        ("agent_findings", "check_id", "TEXT"), ("agent_findings", "sha256", "TEXT"),
        ("enrollment_tokens", "expires_at", "TEXT"), ("enrollment_tokens", "max_uses", "INTEGER DEFAULT 0"),
        ("enrollment_tokens", "uses", "INTEGER DEFAULT 0"), ("enrollment_tokens", "tags", "TEXT DEFAULT ''"),
        ("enrollment_tokens", "revoked", "INTEGER DEFAULT 0"), ("enrollment_tokens", "created_by", "TEXT"),
    ]:
        _add_col(c, t, col, ddl)
    for t in ("api_audit", "custody_log"):
        af_audit.ensure_chain_columns(c, t)
    c.commit()
    # one-time: legacy naive-local timestamps -> UTC for the operational tables
    from af_util import migrate_naive_to_utc
    migrate_naive_to_utc(c, "agents", ["registered_at", "last_seen"])
    migrate_naive_to_utc(c, "agent_commands", ["created_at", "started_at", "completed_at"])
    c.close()


init_tables()


# ---------------------------------------------------------------- enrollment tokens
def create_enroll_token(ttl_hours=None, max_uses=None, tags="", description="", created_by="system"):
    ttl = ENROLL_TTL_HOURS if ttl_hours is None else ttl_hours
    uses = ENROLL_MAX_USES if max_uses is None else max_uses
    tok = secrets.token_urlsafe(24)
    exp = (utcnow() + datetime.timedelta(hours=ttl)).isoformat(timespec="seconds") if ttl else None
    c = db()
    c.execute("INSERT INTO enrollment_tokens (token,created_at,description,expires_at,max_uses,uses,tags,revoked,created_by) "
              "VALUES (?,?,?,?,?,0,?,0,?)", (tok, utc_iso(), description, exp, int(uses), tags, created_by))
    c.commit(); c.close()
    audit("enroll_token_created", "", "", f"by={created_by} ttl_h={ttl} max_uses={uses} tags={tags}")
    return tok


def _token_valid_clause():
    return "revoked=0 AND (expires_at IS NULL OR expires_at>?) AND (max_uses=0 OR uses<max_uses)"


def list_enroll_tokens(active_only=False):
    c = db()
    rows = [dict(r) for r in c.execute("SELECT * FROM enrollment_tokens ORDER BY created_at DESC LIMIT 200")]
    c.close()
    now = utc_iso()
    for r in rows:
        r["active"] = bool(not r["revoked"] and (not r["expires_at"] or r["expires_at"] > now)
                           and (not r["max_uses"] or (r["uses"] or 0) < r["max_uses"]))
        r["legacy"] = r["expires_at"] is None and not r["max_uses"]
    return [r for r in rows if r["active"]] if active_only else rows


def get_enroll_token():
    """Newest still-valid token, or a fresh default one (24 h, 10 uses unless configured)."""
    act = list_enroll_tokens(active_only=True)
    return act[0]["token"] if act else create_enroll_token(description="Auto-created")


def rotate_enroll_token(created_by="system", **kw):
    """Revoke every outstanding token and issue a new one."""
    c = db(); c.execute("UPDATE enrollment_tokens SET revoked=1"); c.commit(); c.close()
    return create_enroll_token(description="Rotated", created_by=created_by, **kw)


def revoke_enroll_token(token, actor="system"):
    c = db(); c.execute("UPDATE enrollment_tokens SET revoked=1 WHERE token=?", (token,)); c.commit(); c.close()
    audit("enroll_token_revoked", "", "", f"by={actor}")


def current_enroll_tokens():
    """Valid enrollment tokens (strings). Fails closed on default/short tokens. AF_ENROLL_TOKEN is honoured only
    as a bootstrap fallback when the database holds no valid token (headless API deployments)."""
    toks = [r["token"] for r in list_enroll_tokens(active_only=True)]
    env = os.environ.get("AF_ENROLL_TOKEN")
    if not toks and env:
        toks.append(env)
    return [x for x in toks if x not in _DEFAULT_TOKENS and len(x) >= 16]


def _match_and_consume(c, presented):
    """Constant-time match against valid tokens, then atomically consume one use. -> tags string or None."""
    good = None
    for t in current_enroll_tokens():
        if hmac.compare_digest(presented.encode(), t.encode()):
            good = t
    if good is None:
        return None
    row = c.execute("SELECT tags FROM enrollment_tokens WHERE token=?", (good,)).fetchone()
    if row is None:                                      # env bootstrap token: not stored, not consumable
        return ""
    cur = c.execute(f"UPDATE enrollment_tokens SET uses=uses+1 WHERE token=? AND {_token_valid_clause()}", (good, utc_iso()))  # nosec B608 - identifiers come from internal constants, values are bound
    c.commit()
    return (row["tags"] or "") if cur.rowcount == 1 else None


# ---------------------------------------------------------------- models
class RegisterRequest(BaseModel):
    enroll_token: str = Field(max_length=256)
    hostname: str = Field(max_length=253)
    os: str = Field(max_length=100)
    os_full: str = Field("", max_length=300)
    arch: str = Field(max_length=50)
    version: str = Field(max_length=40)
    ip: str = Field(max_length=64)
    agent_uid: str = Field("", max_length=64)


class EnrollRequest(RegisterRequest):
    csr_pem: str = Field("", max_length=8192)


class HeartbeatRequest(BaseModel):
    cpu: float = 0
    memory: float = 0
    disk: float = 0
    uptime: int = 0


class ResultRequest(BaseModel):
    command_id: int
    status: Literal["done", "failed"]
    summary: str = Field("", max_length=2000)
    findings: List[Dict[str, Any]] = []
    inventory: Dict[str, Any] = {}
    result_id: str = Field("", max_length=64)
    coverage: Dict[str, Any] = {}


class RenewRequest(BaseModel):
    csr_pem: str = Field(max_length=8192)


# ---------------------------------------------------------------- auth of agent requests
def _peer_fp(request):
    try:
        return getattr(request.state, "peer_cert_fp", None)
    except Exception:
        return None


def verify(x_agent_token: Optional[str], request: Optional[Request] = None):
    if not x_agent_token:
        raise HTTPException(401, "Missing token")
    c = db()
    r = c.execute("SELECT id, cert_fp, disabled FROM agents WHERE token=?", (_h(x_agent_token),)).fetchone()
    if not r:   # legacy plaintext row: match once, then migrate to hash
        r = c.execute("SELECT id, cert_fp, disabled FROM agents WHERE token=?", (x_agent_token,)).fetchone()
        if r:
            c.execute("UPDATE agents SET token=? WHERE id=?", (_h(x_agent_token), r["id"]))
            c.commit()
    peer = _peer_fp(request) if request is not None else None
    revoked = bool(peer and c.execute("SELECT 1 FROM revoked_certs WHERE fingerprint=?", (peer,)).fetchone())
    c.close()
    if not r:
        raise HTTPException(401, "Invalid token")
    if r["disabled"]:
        raise HTTPException(401, "Agent disabled")
    if revoked:
        audit("cert_revoked_denied", r["id"], "", peer[:16])
        raise HTTPException(401, "Client certificate revoked")
    if r["cert_fp"] and (not peer or not hmac.compare_digest(peer, r["cert_fp"])):
        audit("cert_mismatch", r["id"], "", f"presented={str(peer)[:16]}")
        raise HTTPException(401, "Client certificate does not match this agent")
    return r["id"]


# ---------------------------------------------------------------- enrollment
def _find_existing(c, hostname, ip, agent_uid):
    if agent_uid:
        return c.execute("SELECT * FROM agents WHERE agent_uid=?", (agent_uid,)).fetchone()
    return c.execute("SELECT * FROM agents WHERE hostname=? AND ip=? AND (agent_uid IS NULL OR agent_uid='')",
                     (hostname, ip)).fetchone()


def _enroll_core(req, ip, peer_fp=None, current_token=None, cert_fp=None):
    """Shared by /register and /enroll. Returns (agent_id, agent_token, tags)."""
    c = db()
    try:
        if not current_enroll_tokens() or not any(
                hmac.compare_digest(req.enroll_token.encode(), t.encode()) for t in current_enroll_tokens()):
            audit("register_denied", "", ip, req.hostname)
            raise HTTPException(403, "Invalid enroll token")
        now = utc_iso()
        ex = _find_existing(c, req.hostname, req.ip, req.agent_uid)
        if ex:
            released = ex["reenroll_until"] and ex["reenroll_until"] > now
            owns = False
            if current_token:
                row = c.execute("SELECT id FROM agents WHERE token=?", (_h(current_token),)).fetchone()
                owns = bool(row and row["id"] == ex["id"])
            if not (released or owns):
                audit("register_conflict", ex["id"], ip, f"{req.hostname} already enrolled")
                raise HTTPException(409, "Agent already enrolled. Ask an administrator to release it "
                                         "(Agents tab) or present the current agent token.")
        tags = _match_and_consume(c, req.enroll_token)
        if tags is None:
            audit("register_denied", "", ip, "token exhausted")
            raise HTTPException(403, "Invalid enroll token")
        tok = secrets.token_urlsafe(32)
        if ex:
            aid = ex["id"]
            c.execute("""UPDATE agents SET hostname=?,os=?,os_full=?,arch=?,agent_version=?,ip=?,token=?,last_seen=?,
                         status='online',reenroll_until=NULL,cert_fp=?,agent_uid=COALESCE(NULLIF(?,''),agent_uid) WHERE id=?""",
                      (req.hostname, req.os, req.os_full, req.arch, req.version, req.ip, _h(tok), now,
                       cert_fp or peer_fp, req.agent_uid, aid))
        else:
            aid = str(uuid.uuid4())
            c.execute("""INSERT INTO agents (id,hostname,os,os_full,arch,agent_version,ip,token,registered_at,last_seen,
                         status,tags,agent_uid,cert_fp) VALUES (?,?,?,?,?,?,?,?,?,?,'online',?,?,?)""",
                      (aid, req.hostname, req.os, req.os_full, req.arch, req.version, req.ip, _h(tok), now, now,
                       tags, req.agent_uid, cert_fp or peer_fp))
        c.commit()
    finally:
        c.close()
    audit("register" if not ex else "re-register", aid, ip, req.hostname)
    return aid, tok, tags


@app.post("/register")
def register(req: RegisterRequest, request: Request, x_agent_token: Optional[str] = Header(None)):
    ip = client_ip(request)
    _rate_limit(ip)
    aid, tok, _ = _enroll_core(req, ip, peer_fp=_peer_fp(request), current_token=x_agent_token)
    return {"agent_id": aid, "agent_token": tok, "command_pubkey": af_signing.public_pem(af_signing.CMD_KEY),
            "manager_time": utc_iso()}


@app.post("/heartbeat")
def heartbeat(req: HeartbeatRequest, request: Request, x_agent_token: Optional[str] = Header(None)):
    aid = verify(x_agent_token, request)
    now = utc_iso()
    lease = (utcnow() + datetime.timedelta(seconds=LEASE_SECONDS)).isoformat(timespec="seconds")
    c = db()
    c.execute("UPDATE agents SET last_seen=?,status='online',cpu=?,memory=?,disk=?,uptime=? WHERE id=?",
              (now, req.cpu, req.memory, req.disk, req.uptime, aid))
    c.execute("UPDATE agent_commands SET lease_until=? WHERE agent_id=? AND status='running'", (lease, aid))  # alive -> keep lease
    c.commit(); c.close()
    return {"ok": True, "manager_time": now}


# ---------------------------------------------------------------- commands
def requeue_stale(c=None):
    """Commands 'running' past their lease go back to pending (up to MAX_ATTEMPTS), then fail."""
    own = c is None
    c = c or db()
    now = utc_iso()
    n = 0
    for r in c.execute("SELECT id, attempts FROM agent_commands WHERE status='running' AND lease_until IS NOT NULL AND lease_until<?",
                       (now,)).fetchall():
        if (r["attempts"] or 0) >= MAX_ATTEMPTS:
            c.execute("UPDATE agent_commands SET status='failed', completed_at=?, summary='lease expired (agent stopped responding)' WHERE id=?",
                      (now, r["id"]))
        else:
            c.execute("UPDATE agent_commands SET status='pending', lease_until=NULL WHERE id=?", (r["id"],))
        n += 1
    # pending commands that nobody collected for too long are expired rather than run late
    cutoff = (utcnow() - datetime.timedelta(days=7)).isoformat(timespec="seconds")
    c.execute("UPDATE agent_commands SET status='failed', summary='expired before delivery' WHERE status='pending' AND created_at<?", (cutoff,))
    c.commit()
    if own:
        c.close()
    return n


def _fetch_commands(aid):
    c = db()
    try:
        requeue_stale(c)
        rows = c.execute("""SELECT id,command,params,attempts FROM agent_commands
            WHERE agent_id=? AND status='pending' ORDER BY created_at ASC LIMIT 100""", (aid,)).fetchall()
        out, now = [], utcnow()
        for r in rows:
            mult = LEASE_MULT.get(r["command"], 1)
            lease = (now + datetime.timedelta(seconds=LEASE_SECONDS * mult)).isoformat(timespec="seconds")
            c.execute("UPDATE agent_commands SET status='running',started_at=?,lease_until=?,attempts=COALESCE(attempts,0)+1 WHERE id=? AND status='pending'",
                      (now.isoformat(timespec="seconds"), lease, r["id"]))
            params = json.loads(r["params"] or "{}")
            nonce = secrets.token_hex(12)
            issued = now.isoformat(timespec="seconds")
            expires = (now + datetime.timedelta(seconds=CMD_TTL_SECONDS * mult)).isoformat(timespec="seconds")
            out.append({"id": r["id"], "command": r["command"], "params": params, "nonce": nonce, "issued": issued,
                        "expires": expires, "sig": af_signing.sign_command(aid, r["id"], r["command"], params, nonce, issued, expires)})
        c.commit()
        return out
    finally:
        c.close()


@app.get("/commands")
async def commands(request: Request, wait: int = 0, x_agent_token: Optional[str] = Header(None)):
    """Long-poll: with ?wait=N (max 25) the request is held until a command is queued, so idle agents cost one
    request every N seconds instead of one every few seconds."""
    aid = await run_in_threadpool(verify, x_agent_token, request)
    deadline = time.monotonic() + max(0, min(int(wait), 25))
    while True:
        out = await run_in_threadpool(_fetch_commands, aid)
        if out or time.monotonic() >= deadline:
            return {"commands": out}
        await asyncio.sleep(2)


def _clip(v, n):
    return str(v if v is not None else "")[:n]


def sanitize_finding(f):
    st = _clip(f.get("status"), 12).upper()
    risk = RISKS.get(_clip(f.get("risk"), 12).lower(), "Info")
    out = {k: _clip(f.get(k, ""), n) for k, n in FIELD_CAPS.items()}
    out["status"] = st if st in STATUSES else "INFO"
    out["risk"] = risk
    return out


@app.post("/results")
def results(req: ResultRequest, request: Request, x_agent_token: Optional[str] = Header(None)):
    aid = verify(x_agent_token, request)
    if len(req.findings) > MAX_FINDINGS_PER_POST:
        raise HTTPException(413, f"Too many findings in one upload (max {MAX_FINDINGS_PER_POST})")
    c = db()
    try:
        cmd = c.execute("SELECT id, status FROM agent_commands WHERE id=? AND agent_id=?", (req.command_id, aid)).fetchone()
        if not cmd:                                       # not this agent's command (or no such command)
            audit("result_foreign_command", aid, client_ip(request), f"cmd={req.command_id}")
            raise HTTPException(404, "Unknown command")
        if req.result_id and c.execute("SELECT 1 FROM result_receipts WHERE result_id=?", (req.result_id,)).fetchone():
            return {"ok": True, "findings_saved": 0, "duplicate": True}         # idempotent retry
        if cmd["status"] not in ("running", "pending"):
            raise HTTPException(409, f"Command already {cmd['status']}")
        now = utc_iso()
        rows = []
        for f in req.findings:
            s = sanitize_finding(f)
            rows.append((aid, req.command_id, s["category"], s["check_name"], s["status"], s["risk"],
                         _enc(s["details"], f"agent_findings.details|{aid}"),
                         _enc(s["recommendation"], f"agent_findings.recommendation|{aid}"),
                         s["mitre"], now, s["check_id"], s["sha256"]))
        c.executemany("""INSERT INTO agent_findings (agent_id,command_id,category,check_name,status,risk,details,
            recommendation,mitre,timestamp,check_id,sha256) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", rows)
        if req.inventory:
            blob = json.dumps(req.inventory)
            if len(blob) > MAX_BODY:
                raise HTTPException(413, "inventory too large")
            c.execute("INSERT INTO agent_inventory (agent_id,data,timestamp) VALUES (?,?,?)",
                      (aid, _enc(blob, f"agent_inventory.data|{aid}"), now))
        c.execute("UPDATE agent_commands SET status=?,completed_at=?,summary=?,coverage=?,lease_until=NULL WHERE id=?",
                  (req.status, now, req.summary, json.dumps(req.coverage)[:2000], req.command_id))
        if req.result_id:
            c.execute("INSERT OR IGNORE INTO result_receipts (result_id,agent_id,command_id,ts) VALUES (?,?,?,?)",
                      (req.result_id, aid, req.command_id, now))
        c.commit()
        host = (c.execute("SELECT hostname FROM agents WHERE id=?", (aid,)).fetchone() or {"hostname": aid})["hostname"]
    finally:
        c.close()
    audit("results", aid, "", f"cmd={req.command_id} status={req.status} findings={len(req.findings)}")
    _notify_async(host, [sanitize_finding(f) for f in req.findings])
    return {"ok": True, "findings_saved": len(rows)}


def _notify_async(host, findings):
    try:
        import af_integrations
    except Exception:
        return
    bad = [f for f in findings if f["status"] in ("FAIL", "WARNING") and f["risk"] in ("Critical", "High")]
    if bad:
        threading.Thread(target=lambda: af_integrations.notify_findings(bad, source=f"agent:{host}", host=host),
                         daemon=True).start()


@app.post("/artifacts/{command_id}")
async def upload_artifact(command_id: int, request: Request, x_agent_token: Optional[str] = Header(None),
                          x_content_sha256: str = Header("")):
    """Evidence upload (e.g. triage package). The SHA-256 the agent claims is verified while streaming, then a
    chain-of-custody record is written."""
    aid = await run_in_threadpool(verify, x_agent_token, request)
    c = db()
    ok = c.execute("SELECT 1 FROM agent_commands WHERE id=? AND agent_id=?", (command_id, aid)).fetchone()
    c.close()
    if not ok:
        raise HTTPException(404, "Unknown command")
    d = af_home() / "artifacts" / aid
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / f".{command_id}.{secrets.token_hex(4)}.part"
    h, size = hashlib.sha256(), 0
    with open(tmp, "wb") as fh:
        async for chunk in request.stream():
            size += len(chunk)
            if size > MAX_ARTIFACT:
                fh.close(); tmp.unlink(missing_ok=True)
                raise HTTPException(413, "artifact too large")
            h.update(chunk); fh.write(chunk)
    digest = h.hexdigest()
    if x_content_sha256 and not hmac.compare_digest(x_content_sha256.lower(), digest):
        tmp.unlink(missing_ok=True)
        audit("artifact_hash_mismatch", aid, "", f"cmd={command_id}")
        raise HTTPException(422, "SHA-256 mismatch: upload corrupted in transit")
    final = d / f"{command_id}_{digest[:12]}.zip"
    os.replace(tmp, final)
    try:
        os.chmod(final, 0o600)
    except OSError:
        pass
    af_audit.append(DB_PATH, "custody_log", ts=utc_iso(), agent_id=aid, command_id=command_id, action="artifact_received",
                    actor=f"agent:{aid[:8]}", detail=f"{final.name} {size} bytes", sha256=digest)
    return {"ok": True, "sha256": digest, "bytes": size}


@app.get("/health")
def health():
    return {"status": "ok", "version": API_VERSION}


@app.get("/stats")
def stats(request: Request, x_agent_token: Optional[str] = Header(None)):
    """Agent-scoped only: an agent token must not reveal fleet-wide numbers."""
    aid = verify(x_agent_token, request)
    c = db()
    p = c.execute("SELECT COUNT(*) AS c FROM agent_commands WHERE agent_id=? AND status='pending'", (aid,)).fetchone()["c"]
    c.close()
    return {"agent_id": aid, "pending": p}


@app.post("/pki/renew")
def pki_renew(req: RenewRequest, request: Request, x_agent_token: Optional[str] = Header(None)):
    """Over the mTLS listener: an agent holding a valid cert + token swaps it for a fresh short-lived one."""
    aid = verify(x_agent_token, request)
    if not _peer_fp(request):
        raise HTTPException(400, "renewal requires a client certificate")
    import af_pki
    pkidir = Path(os.environ.get("AF_PKI_DIR") or (af_home() / "pki"))
    try:
        pem, fp, serial = af_pki.sign_csr(pkidir, req.csr_pem, f"agent-{aid[:8]}")
    except (ValueError, SystemExit) as e:
        raise HTTPException(400, f"CSR rejected: {e}")
    c = db(); c.execute("UPDATE agents SET cert_fp=? WHERE id=?", (fp, aid)); c.commit(); c.close()
    audit("cert_renewed", aid, client_ip(request), f"serial={serial}")
    return {"cert_pem": pem.decode(), "ca_pem": (pkidir / "ca.crt").read_text()}


# ---------------------------------------------------------------- bootstrap listener (TLS only, no client cert)
enroll_app = FastAPI(title="AuditForensics Enrollment", version=API_VERSION)
enroll_app.add_middleware(BodyLimitMiddleware, default_limit=64 * 1024)


@enroll_app.get("/health")
def enroll_health():
    return {"status": "ok"}


@enroll_app.post("/enroll")
def enroll(req: EnrollRequest, request: Request):
    """Token + CSR in, short-lived client certificate + agent credentials out. The agent's private key never
    leaves the endpoint."""
    ip = client_ip(request)
    _rate_limit(ip)
    import af_pki
    pkidir = Path(os.environ.get("AF_PKI_DIR") or (af_home() / "pki"))
    if not (pkidir / "ca.key").exists():
        raise HTTPException(503, "CA not initialised on the manager (python af_pki.py init-ca)")
    # sign first (cheap, side-effect free), enrol second, so a bad CSR does not burn a token use
    try:
        pem, fp, serial = af_pki.sign_csr(pkidir, req.csr_pem, f"agent-{hashlib.sha256((req.agent_uid or req.hostname).encode()).hexdigest()[:10]}")
    except (ValueError, SystemExit) as e:
        raise HTTPException(400, f"CSR rejected: {e}")
    aid, tok, _ = _enroll_core(req, ip, cert_fp=fp)
    audit("enroll_csr", aid, ip, f"serial={serial}")
    return {"agent_id": aid, "agent_token": tok, "cert_pem": pem.decode(), "ca_pem": (pkidir / "ca.crt").read_text(),
            "command_pubkey": af_signing.public_pem(af_signing.CMD_KEY), "manager_time": utc_iso()}


# ---------------------------------------------------------------- admin operations (used by the UI / worker, not HTTP)
def release_agent(agent_id, minutes=60, actor="system"):
    """Allow one re-enrollment of this agent within ``minutes`` (e.g. after a reinstall that lost its state)."""
    until = (utcnow() + datetime.timedelta(minutes=minutes)).isoformat(timespec="seconds")
    c = db(); c.execute("UPDATE agents SET reenroll_until=? WHERE id=?", (until, agent_id)); c.commit(); c.close()
    audit("agent_released", agent_id, "", f"by={actor} until={until}")


def set_agent_disabled(agent_id, disabled=True, actor="system"):
    c = db(); c.execute("UPDATE agents SET disabled=? WHERE id=?", (int(disabled), agent_id)); c.commit(); c.close()
    audit("agent_disabled" if disabled else "agent_enabled", agent_id, "", f"by={actor}")


def revoke_agent_cert(agent_id, reason="revoked by admin", actor="system"):
    c = db()
    row = c.execute("SELECT cert_fp FROM agents WHERE id=?", (agent_id,)).fetchone()
    if row and row["cert_fp"]:
        c.execute("INSERT OR REPLACE INTO revoked_certs (fingerprint,agent_id,reason,ts) VALUES (?,?,?,?)",
                  (row["cert_fp"], agent_id, reason, utc_iso()))
        c.commit()
    c.close()
    audit("cert_revoked", agent_id, "", f"by={actor} {reason}")


def set_agent_context(agent_id, criticality="medium", exposure="internal", tags=None):
    c = db()
    c.execute("UPDATE agents SET criticality=?, exposure=? WHERE id=?", (criticality, exposure, agent_id))
    if tags is not None:
        c.execute("UPDATE agents SET tags=? WHERE id=?", (tags, agent_id))
    c.commit(); c.close()


def validate_params(command, params):
    """Whitelist + shape-check every command the manager is willing to queue."""
    params = params or {}
    if command in SIMPLE_COMMANDS:
        if params:
            raise ValueError(f"{command} takes no parameters")
        return {}
    if command == "run_file_scan":
        p = params.get("paths", [])
        if not isinstance(p, list) or len(p) > 20 or any(not isinstance(x, str) or not x or len(x) > 512 for x in p):
            raise ValueError("paths: up to 20 non-empty strings")
        return {"paths": p}
    if command == "run_ioc_sweep":
        p, sh, y = params.get("paths", []), params.get("sha256", []), params.get("yara", "")
        if not isinstance(p, list) or len(p) > 20 or any(not isinstance(x, str) or len(x) > 512 for x in p):
            raise ValueError("paths: up to 20 strings")
        if not isinstance(sh, list) or len(sh) > 10000 or any(not (isinstance(x, str) and len(x) == 64 and all(ch in "0123456789abcdefABCDEF" for ch in x)) for x in sh):
            raise ValueError("sha256: up to 10000 hex digests")
        if not isinstance(y, str) or len(y) > 200000:
            raise ValueError("yara: rules text up to 200 KB")
        return {"paths": p, "sha256": [x.lower() for x in sh], "yara": y}
    if command == "collect_triage":
        return {"upload": bool(params.get("upload", True))}
    if command == "run_scap":
        prof, ds = str(params.get("profile", ""))[:200], str(params.get("datastream", ""))[:512]
        return {"profile": prof, "datastream": ds}
    if command == "kill_process":
        pid = params.get("pid")
        if not isinstance(pid, int) or pid <= 1:
            raise ValueError("pid must be an integer > 1")
        return {"pid": pid, "name": str(params.get("name", ""))[:128]}
    if command == "quarantine_file":
        p = params.get("path", "")
        if not isinstance(p, str) or not p or len(p) > 1024:
            raise ValueError("path required")
        return {"path": p}
    if command == "isolate_host":
        ttl = params.get("ttl_minutes", 60)
        if not isinstance(ttl, int) or not 1 <= ttl <= 1440:
            raise ValueError("ttl_minutes must be 1..1440")
        return {"ttl_minutes": ttl}
    raise ValueError(f"unknown command: {command}")


def queue_command(agent_id, command, params=None, actor="system"):
    """-> (command_id, status). Live-response commands wait for a *different* admin to approve them."""
    params = validate_params(command, params)
    status = "awaiting_approval" if command in LIVE_RESPONSE else "pending"
    c = db()
    if not c.execute("SELECT 1 FROM agents WHERE id=?", (agent_id,)).fetchone():
        c.close(); raise ValueError("unknown agent")
    cur = c.execute("INSERT INTO agent_commands (agent_id,command,params,status,created_at,requested_by) VALUES (?,?,?,?,?,?)",
                    (agent_id, command, json.dumps(params), status, utc_iso(), actor))
    c.commit(); cid = cur.lastrowid; c.close()
    audit("command_queued", agent_id, "", f"#{cid} {command} by={actor} status={status}")
    return cid, status


def approve_command(cmd_id, approver):
    c = db()
    r = c.execute("SELECT * FROM agent_commands WHERE id=?", (cmd_id,)).fetchone()
    try:
        if not r or r["status"] != "awaiting_approval":
            raise ValueError("command is not awaiting approval")
        if r["requested_by"] == approver:
            raise ValueError("two-person rule: a different administrator must approve this command")
        c.execute("UPDATE agent_commands SET status='pending', approved_by=? WHERE id=?", (approver, cmd_id))
        c.commit()
    finally:
        c.close()
    audit("command_approved", r["agent_id"] if r else "", "", f"#{cmd_id} {r['command'] if r else ''} approver={approver}")
    af_audit.append(DB_PATH, "custody_log", ts=utc_iso(), agent_id=r["agent_id"], command_id=cmd_id, action="live_response_approved",
                    actor=approver, detail=f"{r['command']} requested_by={r['requested_by']}", sha256="")


def deny_command(cmd_id, approver):
    c = db()
    c.execute("UPDATE agent_commands SET status='failed', summary=? WHERE id=? AND status='awaiting_approval'",
              (f"denied by {approver}", cmd_id))
    c.commit(); c.close()
    audit("command_denied", "", "", f"#{cmd_id} by={approver}")


def prune(c=None):
    """Retention: old findings, surplus inventory snapshots, old receipts and (checkpointed) audit rows."""
    own = c is None
    c = c or db()
    cutoff = (utcnow() - datetime.timedelta(days=RETENTION_DAYS)).isoformat(timespec="seconds")
    out = {}
    out["findings"] = c.execute("DELETE FROM agent_findings WHERE timestamp<?", (cutoff,)).rowcount
    out["inventory"] = c.execute("DELETE FROM agent_inventory WHERE timestamp<? OR id NOT IN ("
                                 "SELECT id FROM (SELECT id, ROW_NUMBER() OVER (PARTITION BY agent_id ORDER BY id DESC) rn "
                                 "FROM agent_inventory) WHERE rn<=?)", (cutoff, INVENTORY_KEEP)).rowcount
    out["receipts"] = c.execute("DELETE FROM result_receipts WHERE ts<?", (cutoff,)).rowcount
    c.commit()
    if own:
        c.close()
    out["audit"] = prune_audit()
    return out


def prune_audit(days=None):
    """Delete audit rows older than the retention period but leave a checkpoint so the chain still verifies."""
    days = AUDIT_RETENTION_DAYS if days is None else days
    cutoff = (utcnow() - datetime.timedelta(days=days)).isoformat(timespec="seconds")
    c = db()
    try:
        last = c.execute("SELECT id,row_hash FROM api_audit WHERE row_hash IS NOT NULL AND ts<? ORDER BY id DESC LIMIT 1", (cutoff,)).fetchone()
        if not last:
            return 0
        n = c.execute("DELETE FROM api_audit WHERE id<=?", (last["id"],)).rowcount
        c.execute("INSERT INTO audit_checkpoints (tbl,last_hash,ts,deleted) VALUES ('api_audit',?,?,?)", (last["row_hash"], utc_iso(), n))
        c.commit()
        return n
    finally:
        c.close()


def maintenance():
    c = db()
    out = {"requeued": requeue_stale(c)}
    out.update(prune(c))
    c.close()
    return out


def verify_audit_chain():
    r = af_audit.verify(DB_PATH, "api_audit")
    if not r["ok"] and "genesis" in r["message"]:      # legitimate after pruning: accept a matching checkpoint
        c = db()
        row = c.execute("SELECT prev_hash FROM api_audit WHERE row_hash IS NOT NULL ORDER BY id LIMIT 1").fetchone()
        cp = row and c.execute("SELECT 1 FROM audit_checkpoints WHERE tbl='api_audit' AND last_hash=?", (row["prev_hash"],)).fetchone()
        c.close()
        if cp:
            return {**r, "ok": True, "message": "chain intact (older rows pruned under a checkpoint)"}
    return r


# ---------------------------------------------------------------- TLS peer-certificate capture for uvicorn
try:
    from uvicorn.protocols.http.h11_impl import H11Protocol as _H11

    class PeerCertProtocol(_H11):
        """uvicorn HTTP protocol that exposes the verified client-certificate fingerprint as request.state.peer_cert_fp."""

        def connection_made(self, transport):
            super().connection_made(transport)
            fp = None
            try:
                so = transport.get_extra_info("ssl_object")
                der = so.getpeercert(binary_form=True) if so else None
                fp = hashlib.sha256(der).hexdigest() if der else None
            except Exception:
                pass
            self.app_state = {**(getattr(self, "app_state", None) or {}), "peer_cert_fp": fp}
except Exception:                                        # uvicorn missing / incompatible: binding unavailable
    PeerCertProtocol = None
