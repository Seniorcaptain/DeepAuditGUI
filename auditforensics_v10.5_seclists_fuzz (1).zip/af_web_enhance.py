#!/usr/bin/env python3
"""Web scanning enhancements for AuditForensics.

Adds (read-only, authorised-use only):
  1. Authenticated / session-aware probing (cookie + header injection)
  2. Technology fingerprint → targeted path wordlists
  3. Lightweight JS / HTML endpoint extraction
  4. Certificate & TLS posture checks
  5. Scan drift helpers (diff vs previous)
  6. Cloud metadata / SSRF-ish read-only probes
  7. Executive report builder (markdown + structured sections)
  8. Scan profiles (quick / standard / deep)
  9. Checkpoint / resume for long path fuzz runs
 10. Explicit false-positive / accepted workflow helpers (extends risk_exceptions)

All active probes remain GET/HEAD/OPTIONS (or one harmless GraphQL introspection)
and honour af_scope rate limits when a throttled session is supplied.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import socket
import ssl
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

# ---------------------------------------------------------------------------
# 8. Scan profiles
# ---------------------------------------------------------------------------
SCAN_PROFILES = {
    "quick": {
        "label": "Fast — about 1 minute",
        "path_seclist_size": "built-in only",
        "path_max": 80,
        "path_concurrency": 20,
        "include_subdomains": False,
        "sub_seclist_size": "built-in only (~200)",
        "sub_max": 0,
        "sub_brute": False,
        "sub_crtsh": False,
        "enable_tls": True,
        "enable_js_extract": False,
        "enable_cloud_meta": False,
        "enable_auth": False,
        "time_budget_sec": 90,
        "description": "Checks the site, security headers, and the most common risky paths. Stops automatically so you stay signed in.",
    },
    "standard": {
        "label": "Recommended — about 3 minutes",
        "path_seclist_size": "built-in only",
        "path_max": 250,
        "path_concurrency": 20,
        "include_subdomains": False,
        "sub_seclist_size": "built-in only (~200)",
        "sub_max": 15,
        "sub_brute": False,
        "sub_crtsh": True,
        "enable_tls": True,
        "enable_js_extract": True,
        "enable_cloud_meta": False,
        "enable_auth": False,
        "time_budget_sec": 180,
        "description": "Fast checks plus a short path list and certificate names. Good default for most sites.",
    },
    "deep": {
        "label": "Thorough — up to 10 minutes",
        "path_seclist_size": "tiny/small (~5k)",
        "path_max": 800,
        "path_concurrency": 24,
        "include_subdomains": True,
        "sub_seclist_size": "small (~5k)",
        "sub_max": 20,
        "sub_brute": True,
        "sub_crtsh": True,
        "enable_tls": True,
        "enable_js_extract": True,
        "enable_cloud_meta": True,
        "enable_auth": False,
        "time_budget_sec": 480,
        "description": "Larger path list and subdomain lookup. Still stops on a time limit so the session does not expire.",
    },
    "subdomains_only": {
        "label": "Names only — no path fuzzing",
        "path_seclist_size": "built-in only",
        "path_max": 0,
        "path_concurrency": 8,
        "include_subdomains": True,
        "sub_seclist_size": "small (~5k)",
        "sub_max": 30,
        "sub_brute": True,
        "sub_crtsh": True,
        "enable_tls": False,
        "enable_js_extract": False,
        "enable_cloud_meta": False,
        "enable_auth": False,
        "time_budget_sec": 180,
        "description": "Finds related hostnames. Does not probe thousands of paths.",
    },
    "internal_hardening": {
        "label": "Internal host",
        "path_seclist_size": "built-in only",
        "path_max": 200,
        "path_concurrency": 16,
        "include_subdomains": False,
        "sub_seclist_size": "built-in only (~200)",
        "sub_max": 0,
        "sub_brute": False,
        "sub_crtsh": False,
        "enable_tls": True,
        "enable_js_extract": False,
        "enable_cloud_meta": True,
        "enable_auth": False,
        "time_budget_sec": 180,
        "description": "For a host you already know. Short path list plus cloud-metadata path checks.",
    },
}


def apply_profile(profile_key: str, target_inputs: dict) -> dict:
    """Merge a profile into target_inputs (profile values win for known keys)."""
    p = SCAN_PROFILES.get(profile_key) or SCAN_PROFILES["standard"]
    out = dict(target_inputs)
    for k, v in p.items():
        if k in ("label", "description"):
            continue
        out[k] = v
    out["scan_profile"] = profile_key
    return out


# ---------------------------------------------------------------------------
# 2. Technology fingerprint
# ---------------------------------------------------------------------------
_TECH_RULES = [
    # (name, header_key_re, header_val_re, body_re, path_boost_list)
    ("wordpress", r"x-powered-by", r"wordpress", r"wp-content|wp-includes|wordpress", [
        "/wp-admin/", "/wp-login.php", "/wp-json/", "/xmlrpc.php",
        "/wp-content/debug.log", "/wp-config.php.bak", "/readme.html",
        "/wp-content/uploads/", "/?author=1",
    ]),
    ("spring", r"x-application-context|x-powered-by", r"spring|servlet", r"whitelabel error page|spring framework", [
        "/actuator", "/actuator/env", "/actuator/health", "/actuator/mappings",
        "/actuator/heapdump", "/actuator/beans", "/jolokia", "/env",
    ]),
    ("laravel", r"x-powered-by|set-cookie", r"laravel|php", r"laravel_session|csrf-token", [
        "/.env", "/storage/logs/laravel.log", "/telescope", "/_ignition/health-check",
        "/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php",
    ]),
    ("django", r"x-powered-by|set-cookie", r"django|python|wsgi", r"csrfmiddlewaretoken|django", [
        "/admin/", "/static/admin/", "/__debug__/", "/api/",
    ]),
    ("express", r"x-powered-by", r"express", r"", [
        "/api/", "/graphql", "/.env", "/package.json",
    ]),
    ("nginx", r"server", r"nginx", r"", []),
    ("apache", r"server", r"apache", r"", ["/server-status", "/server-info", "/.htaccess"]),
    ("iis", r"server", r"microsoft-iis|iis", r"", ["/web.config", "/aspnet_client/"]),
    ("tomcat", r"server", r"tomcat|coyote", r"", [
        "/manager/html", "/host-manager/html", "/examples/", "/docs/",
    ]),
    ("jenkins", r"x-jenkins|server", r"jenkins", r"jenkins", [
        "/jenkins", "/manage", "/script", "/asynchPeople/",
    ]),
    ("graphql", r"", r"", r"graphql|__schema", ["/graphql", "/graphiql", "/api/graphql"]),
    ("swagger", r"", r"", r"swagger|openapi", [
        "/swagger.json", "/swagger-ui.html", "/openapi.json", "/api-docs", "/v2/api-docs", "/v3/api-docs",
    ]),
]


def fingerprint_tech(headers: dict, body: bytes = b"") -> List[str]:
    """Return list of detected technology names (lowercase)."""
    headers = {str(k).lower(): str(v).lower() for k, v in (headers or {}).items()}
    body_l = (body or b"")[:50000].lower()
    found = []
    for name, hk, hv, br, _boost in _TECH_RULES:
        hit = False
        if hk:
            for k, v in headers.items():
                if re.search(hk, k) and (not hv or re.search(hv, v)):
                    hit = True
                    break
        if not hit and br and re.search(br.encode() if isinstance(br, str) else br, body_l):
            hit = True
        if hit:
            found.append(name)
    return list(dict.fromkeys(found))


def tech_boost_paths(techs: List[str]) -> List[str]:
    """Paths to prioritise based on detected technologies."""
    out = []
    for name, _hk, _hv, _br, boost in _TECH_RULES:
        if name in techs:
            out.extend(boost)
    return list(dict.fromkeys(out))


# ---------------------------------------------------------------------------
# 3. JS / HTML endpoint extraction
# ---------------------------------------------------------------------------
_JS_URL_RE = re.compile(
    r"""(?:fetch|axios\.(?:get|post|put|delete|patch)|\$\.(?:get|post|ajax)|XMLHttpRequest)
        \s*\(\s*['"`](/[^'"`\s]{1,200})['"`]""",
    re.I | re.X,
)
_HREF_RE = re.compile(r"""(?:href|src|action|data-url|data-api)\s*=\s*['"](/[^'"]{1,200})['"]""", re.I)
_ABS_API_RE = re.compile(
    r"""['"`](https?://[^'"`\s]{8,200}(?:/api|/v[0-9]|/graphql|/rest|/swagger)[^'"`\s]*)['"`]""",
    re.I,
)
_PATH_IN_STRING_RE = re.compile(r"""['"`](/(?:api|v[0-9]|graphql|rest|admin|internal|private)/[^'"`\s]{0,150})['"`]""")


def extract_endpoints(html_or_js: bytes, base_url: str = "") -> List[str]:
    """Extract relative API-ish paths from HTML or JS text."""
    if not html_or_js:
        return []
    try:
        text = html_or_js.decode("utf-8", errors="ignore")
    except Exception:
        return []
    found = []
    for rx in (_JS_URL_RE, _HREF_RE, _PATH_IN_STRING_RE):
        for m in rx.finditer(text):
            p = m.group(1).split("?")[0].split("#")[0]
            if 1 < len(p) < 180 and ".." not in p:
                found.append(p if p.startswith("/") else "/" + p)
    # absolute same-host APIs → path only
    host = urlparse(base_url).hostname if base_url else ""
    for m in _ABS_API_RE.finditer(text):
        u = m.group(1)
        pu = urlparse(u)
        if host and pu.hostname and pu.hostname != host:
            continue
        if pu.path and len(pu.path) < 180:
            found.append(pu.path)
    return list(dict.fromkeys(found))[:200]


def extract_script_srcs(html: bytes) -> List[str]:
    """Return relative or absolute script src URLs from HTML."""
    if not html:
        return []
    try:
        text = html.decode("utf-8", errors="ignore")
    except Exception:
        return []
    return list(dict.fromkeys(re.findall(r"""<script[^>]+src=['"]([^'"]+)['"]""", text, re.I)))[:30]


# ---------------------------------------------------------------------------
# 1. Auth / session helper
# ---------------------------------------------------------------------------
def apply_auth_to_session(session, cookies: str = "", headers: str = "") -> List[str]:
    """Inject Cookie header and extra headers into a requests session.

    cookies: 'name=value; name2=value2' or multi-line
    headers: 'Header-Name: value' per line
    Returns list of notes (what was applied).
    """
    notes = []
    if not session:
        return ["no session"]
    if cookies:
        # support multi-line or semicolon-separated
        parts = re.split(r"[\n;]+", cookies)
        jar = {}
        for p in parts:
            p = p.strip()
            if not p or "=" not in p:
                continue
            # strip optional "Cookie:" prefix
            if p.lower().startswith("cookie:"):
                p = p[7:].strip()
            k, _, v = p.partition("=")
            k, v = k.strip(), v.strip()
            if k:
                jar[k] = v
        if jar:
            session.headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in jar.items())
            notes.append(f"cookies:{len(jar)}")
    if headers:
        for line in headers.splitlines():
            line = line.strip()
            if not line or ":" not in line:
                continue
            k, _, v = line.partition(":")
            k, v = k.strip(), v.strip()
            if k and k.lower() not in ("host", "content-length"):
                session.headers[k] = v
                notes.append(f"hdr:{k}")
    return notes


# ---------------------------------------------------------------------------
# 4. Certificate & TLS posture
# ---------------------------------------------------------------------------
def check_tls(hostname: str, port: int = 443, timeout: float = 8.0) -> List[dict]:
    """Return list of finding dicts (category, check, status, details, risk, rec, host).

    Uses stdlib ssl only — no extra deps. Cipher enumeration is best-effort.
    """
    findings = []
    host_label = f"{hostname}:{port}"

    def add(check, status, details, risk="Info", rec=""):
        findings.append({
            "Category": "TLS", "Check": check, "Status": status,
            "Details": details, "Risk": risk, "Recommendation": rec, "Host": host_label,
        })

    try:
        ctx = ssl.create_default_context()
        # We still want to inspect bad certs, so do a second connect with unverified if needed
        try:
            with socket.create_connection((hostname, port), timeout=timeout) as sock:
                with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    version = ssock.version()
        except ssl.SSLCertVerificationError as e:
            add("TLS Certificate Verification", "FAIL",
                f"Certificate verification failed: {str(e)[:200]}",
                "High", "Install a valid certificate from a trusted CA; check chain and hostname.")
            # retry unverified to still collect cert dates / cipher
            ctx2 = ssl._create_unverified_context()
            with socket.create_connection((hostname, port), timeout=timeout) as sock:
                with ctx2.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    version = ssock.version()
        except Exception as e:
            add("TLS Connection", "FAIL", f"Could not complete TLS handshake: {type(e).__name__}: {str(e)[:150]}",
                "Medium", "Verify the service speaks TLS on this port and is reachable.")
            return findings

        # Protocol version
        if version in ("TLSv1", "TLSv1.1", "SSLv2", "SSLv3", None):
            add("TLS Protocol Version", "FAIL",
                f"Negotiated {version or 'unknown'} — obsolete and vulnerable",
                "High", "Disable TLS 1.0/1.1 (and SSL); require TLS 1.2+ (prefer 1.3).")
        elif version == "TLSv1.2":
            add("TLS Protocol Version", "PASS", "Negotiated TLSv1.2", "Info", "")
        else:
            add("TLS Protocol Version", "PASS", f"Negotiated {version}", "Info", "")

        # Cipher
        if cipher:
            name, proto, bits = cipher[0], cipher[1] if len(cipher) > 1 else "", cipher[2] if len(cipher) > 2 else 0
            weak = any(x in name.upper() for x in ("RC4", "DES", "MD5", "NULL", "EXPORT", "ANON"))
            if weak or (bits and bits < 128):
                add("TLS Cipher", "FAIL", f"Weak cipher negotiated: {name} ({bits} bits)",
                    "High", "Disable weak ciphers; prefer AEAD (AES-GCM, ChaCha20-Poly1305).")
            else:
                add("TLS Cipher", "PASS", f"{name} ({bits} bits, {proto})", "Info", "")

        # Certificate fields
        if cert:
            subject = dict(x[0] for x in cert.get("subject", ()))
            issuer = dict(x[0] for x in cert.get("issuer", ()))
            cn = subject.get("commonName", "")
            san = []
            for typ, val in cert.get("subjectAltName", ()) or ():
                if typ == "DNS":
                    san.append(val)
            add("TLS Certificate Subject", "PASS",
                f"CN={cn}; SAN={', '.join(san[:8]) or 'none'}; Issuer={issuer.get('commonName', issuer.get('organizationName', ''))}",
                "Info", "")

            # Expiry
            not_after = cert.get("notAfter")
            if not_after:
                try:
                    exp = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    days = (exp - datetime.now(timezone.utc)).days
                    if days < 0:
                        add("TLS Certificate Expiry", "FAIL",
                            f"Certificate expired {-days} day(s) ago ({not_after})",
                            "Critical", "Renew the certificate immediately.")
                    elif days < 14:
                        add("TLS Certificate Expiry", "WARNING",
                            f"Certificate expires in {days} day(s) ({not_after})",
                            "High", "Renew before expiry; automate with ACME where possible.")
                    elif days < 30:
                        add("TLS Certificate Expiry", "WARNING",
                            f"Certificate expires in {days} day(s) ({not_after})",
                            "Medium", "Plan renewal.")
                    else:
                        add("TLS Certificate Expiry", "PASS",
                            f"Valid for {days} more day(s) (until {not_after})", "Info", "")
                except ValueError:
                    add("TLS Certificate Expiry", "INFO", f"notAfter={not_after}", "Info", "")

            # Hostname match (basic)
            names = set(san) | ({cn} if cn else set())
            if names and not any(
                hostname == n or (n.startswith("*.") and hostname.endswith(n[1:]))
                for n in names
            ):
                add("TLS Hostname Match", "WARNING",
                    f"Hostname {hostname!r} not in cert names {sorted(names)[:10]}",
                    "Medium", "Use a certificate that includes this hostname in SAN.")
    except Exception as e:
        add("TLS Check Error", "ERROR", f"{type(e).__name__}: {str(e)[:150]}", "Info", "")

    return findings


def check_hsts(headers: dict) -> Optional[dict]:
    """Inspect Strict-Transport-Security header quality."""
    hsts = None
    for k, v in (headers or {}).items():
        if k.lower() == "strict-transport-security":
            hsts = v
            break
    if not hsts:
        return {
            "Category": "TLS", "Check": "HSTS", "Status": "WARNING",
            "Details": "Strict-Transport-Security header missing",
            "Risk": "Medium",
            "Recommendation": "Add HSTS with max-age >= 15552000 (180 days); consider includeSubDomains and preload.",
            "Host": "",
        }
    low = hsts.lower()
    try:
        ma = int(re.search(r"max-age\s*=\s*(\d+)", low).group(1))
    except Exception:
        ma = 0
    issues = []
    if ma < 15552000:
        issues.append(f"max-age={ma} < 180 days")
    if "includesubdomains" not in low:
        issues.append("missing includeSubDomains")
    if issues:
        return {
            "Category": "TLS", "Check": "HSTS", "Status": "WARNING",
            "Details": f"HSTS present but weak: {hsts[:120]} ({'; '.join(issues)})",
            "Risk": "Low",
            "Recommendation": "Raise max-age to >= 15552000 and add includeSubDomains when all subs support HTTPS.",
            "Host": "",
        }
    return {
        "Category": "TLS", "Check": "HSTS", "Status": "PASS",
        "Details": f"HSTS: {hsts[:120]}",
        "Risk": "Info", "Recommendation": "", "Host": "",
    }


# ---------------------------------------------------------------------------
# 6. Cloud metadata / SSRF-ish probes (read-only, only when enabled)
# ---------------------------------------------------------------------------
_CLOUD_PATHS = [
    # Generic / confusing paths sometimes exposed via reverse proxies
    ("/latest/meta-data/", "AWS IMDS path exposed on this host"),
    ("/latest/api/token", "AWS IMDSv2 token endpoint reachable"),
    ("/metadata/instance", "Azure Instance Metadata path reachable"),
    ("/computeMetadata/v1/", "GCP metadata path reachable"),
    ("/opc/v2/instance/", "Oracle Cloud metadata path reachable"),
    ("/openstack/latest/meta_data.json", "OpenStack metadata path reachable"),
]


def probe_cloud_metadata(session, base: str, timeout: float = 4.0) -> List[dict]:
    """Probe whether cloud metadata-style paths answer on the *target* (proxy/misconfig indicator).

    Does NOT target 169.254.169.254 — only paths on the authorised scan target.
    """
    findings = []
    for path, label in _CLOUD_PATHS:
        try:
            r = session.get(
                base.rstrip("/") + path,
                timeout=timeout,
                verify=False,
                allow_redirects=False,
                headers={"Metadata-Flavor": "Google", "Metadata": "true"},
            )
            # Real metadata usually returns 200 with plain text/json and specific headers
            if r.status_code == 200 and len(r.content) > 0:
                ctype = r.headers.get("Content-Type", "")
                # Avoid counting generic HTML soft-404s
                body = r.content[:500].lower()
                if b"<html" in body or b"<!doctype" in body:
                    continue
                findings.append({
                    "Category": "Cloud", "Check": "Metadata Path Exposed",
                    "Status": "FAIL",
                    "Details": f"{label}: {path} → HTTP {r.status_code} ({ctype[:40]}, {len(r.content)} bytes)",
                    "Risk": "High",
                    "Recommendation": "Block metadata paths at the reverse proxy/WAF; ensure the app is not proxying to IMDS.",
                    "Host": base,
                })
        except Exception:
            continue
    return findings


# ---------------------------------------------------------------------------
# 9. Checkpoint / resume
# ---------------------------------------------------------------------------
def checkpoint_path(work_dir: Optional[Path], target: str) -> Path:
    root = work_dir or (Path.home() / ".auditforensics" / "checkpoints")
    root.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^a-zA-Z0-9._-]+", "_", target)[:80]
    return root / f"pathfuzz_{safe}.json"


def load_checkpoint(path: Path) -> dict:
    try:
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def save_checkpoint(path: Path, data: dict) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=0), encoding="utf-8")
        tmp.replace(path)
    except Exception:
        pass


def clear_checkpoint(path: Path) -> None:
    try:
        if path.is_file():
            path.unlink()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 5. Drift helpers
# ---------------------------------------------------------------------------
def summarise_drift(diff: dict) -> str:
    """Human-readable summary of diff_results()-style dict."""
    if not diff:
        return "No previous scan to compare."
    new = diff.get("new") or []
    gone = diff.get("resolved") or diff.get("gone") or []
    worse = diff.get("worsened") or []
    better = diff.get("improved") or []
    parts = []
    if new:
        parts.append(f"{len(new)} new issue(s)")
    if gone:
        parts.append(f"{len(gone)} resolved")
    if worse:
        parts.append(f"{len(worse)} worsened")
    if better:
        parts.append(f"{len(better)} improved")
    return (", ".join(parts) if parts else "No material change in FAIL/WARNING findings.") + (
        f" (previous: {diff.get('prev_ts', '?')})" if diff.get("prev_ts") else ""
    )


# ---------------------------------------------------------------------------
# 10. FP / acceptance helpers (thin wrappers — core lives in auditforensics_web)
# ---------------------------------------------------------------------------
def fp_note(reason: str, by: str = "", until_days: int = 90) -> str:
    until = (datetime.now(timezone.utc) + timedelta(days=until_days)).strftime("%Y-%m-%d")
    who = f" by {by}" if by else ""
    return f"marked false-positive{who} until {until}: {reason[:300]}"


# ---------------------------------------------------------------------------
# 7. Executive report (markdown)
# ---------------------------------------------------------------------------
def build_executive_report(
    results: List[dict],
    target: str = "",
    scan_type: str = "Web Application",
    profile: str = "",
    drift_summary: str = "",
    ai_summary: str = "",
) -> str:
    """Return markdown suitable for paste into email / PDF pipeline."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    crit = [r for r in results if r.get("Risk") == "Critical" and r.get("Status") in ("FAIL", "WARNING")]
    high = [r for r in results if r.get("Risk") == "High" and r.get("Status") in ("FAIL", "WARNING")]
    med = [r for r in results if r.get("Risk") == "Medium" and r.get("Status") in ("FAIL", "WARNING")]
    accepted = [r for r in results if r.get("Status") == "ACCEPTED"]
    total = len(results)

    def bullet(rs, limit=8):
        lines = []
        for r in rs[:limit]:
            host = r.get("Host") or target
            lines.append(f"- **{r.get('Check', '')}** ({host}): {str(r.get('Details', ''))[:140]}")
        if len(rs) > limit:
            lines.append(f"- … and {len(rs) - limit} more")
        return "\n".join(lines) if lines else "_None_"

    md = f"""# AuditForensics — Executive Summary

| Field | Value |
|------|-------|
| Target | `{target}` |
| Scan type | {scan_type} |
| Profile | {profile or "custom"} |
| Generated | {now} |
| Findings (total rows) | {total} |
| Critical / High / Medium (open) | {len(crit)} / {len(high)} / {len(med)} |
| Accepted risk | {len(accepted)} |

## Headline

"""
    if crit or high:
        md += f"This scan identified **{len(crit)} critical** and **{len(high)} high** severity issues that warrant prompt attention.\n\n"
    else:
        md += "No critical or high severity open issues were identified in this run. Residual medium/low items should still be reviewed.\n\n"

    if drift_summary:
        md += f"**Change since previous scan:** {drift_summary}\n\n"

    if ai_summary:
        md += f"## Analyst notes\n\n{ai_summary.strip()}\n\n"

    md += "## Critical\n\n" + bullet(crit) + "\n\n"
    md += "## High\n\n" + bullet(high) + "\n\n"
    md += "## Medium (sample)\n\n" + bullet(med, 5) + "\n\n"

    md += """## What this scan did *not* cover

- No exploitation, password spraying, or denial-of-service testing
- Findings are based on read-only probes within the recorded authorisation scope
- Soft-404 and catch-all responses are filtered; residual false positives may remain — use the risk acceptance register to document them

## Recommended next steps

1. Remediate all Critical items within 7 days (or document formal risk acceptance).
2. Schedule High items into the current sprint / change window.
3. Re-run the same scan profile after remediation to confirm closure (drift view).
"""
    return md


def findings_to_csv_rows(results: List[dict]) -> List[dict]:
    """Normalise findings for CSV export."""
    keys = ["Host", "Category", "Check", "Status", "Risk", "Details", "Recommendation", "MITRE", "Timestamp", "Evidence"]
    rows = []
    for r in results:
        rows.append({k: r.get(k, "") for k in keys})
    return rows
