#!/usr/bin/env python3
"""AuditForensics portable host checks - one implementation shared by the agent and the main app.

Design rules
  * stdlib only (+ optional psutil) so the agent stays easy to deploy
  * no shell: commands are argument lists, never strings
  * parsing is separated from execution (pure ``parse_*`` / ``*_protective`` functions are unit-tested)
  * a check that cannot run says so: ``Skip`` -> SKIPPED finding, an exception -> ERROR finding. A failure is
    never reported as a clean PASS; ``Collector.stats`` becomes the scan's coverage summary.
"""
import fnmatch, glob as _glob, hashlib, ipaddress, json, os, platform, re, shutil, stat, subprocess, sys, tarfile
import time, zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

RISKY_PORTS = {21: "FTP", 23: "Telnet", 445: "SMB", 3389: "RDP", 5900: "VNC", 6379: "Redis", 27017: "MongoDB",
               1433: "MSSQL", 3306: "MySQL", 5432: "PostgreSQL", 11211: "Memcached", 2375: "Docker", 2376: "Docker-TLS"}
PROXY_INDICATORS = ["netnut", "ipidea", "luminati", "brightdata", "smartproxy", "oxylabs", "soax", "proxyrack", "911s5"]
MAX_HASH_BYTES = 100 * 1024 * 1024


class Skip(Exception):
    """The check could not run here (missing tool, needs root, ...). Reported as SKIPPED, with the reason."""


class NotApplicable(Exception):
    """The check does not apply to this OS. Counted in coverage, not reported as a finding."""


# ---------------------------------------------------------------- ids and findings
def make_check_id(category, check):
    """Deterministic, human-readable check ID. Digits, versions, ports and parentheticals are stripped so
    ``Risky Port 21 (FTP)`` and ``Risky Port 23 (Telnet)`` share one ID and exceptions survive wording changes."""
    cat = re.sub(r"[^A-Z0-9]+", "", str(category).upper())[:4] or "GEN"
    s = re.sub(r"\(.*?\)", "", str(check).lower())
    s = re.sub(r"\b\d+(\.\d+)*\b", "", s)
    s = re.sub(r"[^a-z]+", "-", s).strip("-")
    return f"AF-{cat}-{s[:40] or 'check'}"


def F(category, check, status, risk, details, rec="", mitre="", check_id=None, **extra):
    d = {"category": category, "check_name": check, "status": status, "risk": risk, "details": str(details),
         "recommendation": rec, "mitre": mitre, "check_id": check_id or make_check_id(category, check)}
    d.update({k: v for k, v in extra.items() if v})
    return d


class Collector:
    """Runs checks, converting failures into explicit ERROR / SKIPPED findings and counting coverage."""

    def __init__(self):
        self.findings = []
        self.stats = {"run": 0, "errors": 0, "skipped": 0, "not_applicable": 0}

    def run(self, name, fn, *args):
        self.stats["run"] += 1
        try:
            out = fn(*args) or []
        except NotApplicable:
            self.stats["not_applicable"] += 1
        except Skip as s:
            self.stats["skipped"] += 1
            self.findings.append(F("Scan Coverage", f"Check skipped: {name}", "SKIPPED", "Info", str(s) or "could not run",
                                   "Run the agent with sufficient privileges / install the missing tool.", check_id=f"AF-COVR-skipped-{name}"))
        except Exception as e:
            self.stats["errors"] += 1
            self.findings.append(F("Scan Coverage", f"Check error: {name}", "ERROR", "Info",
                                   f"{type(e).__name__}: {str(e)[:300]}", "Investigate; this result is NOT a pass.",
                                   check_id=f"AF-COVR-error-{name}"))
        else:
            self.findings.extend(out)
        return self

    def coverage(self):
        return dict(self.stats)

    def summary(self, label="findings"):
        real = [f for f in self.findings if f["status"] not in ("SKIPPED", "ERROR")]
        s = self.stats
        return (f"{len(real)} {label}; coverage: {s['run']} checks run, {s['errors']} errored, "
                f"{s['skipped']} skipped, {s['not_applicable']} n/a")


# ---------------------------------------------------------------- execution context
def _default_run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, errors="replace")   # argument list: never run through a shell
        out = r.stdout.strip()
        if r.returncode != 0 and not out:
            out = r.stderr.strip()
        return out, r.returncode
    except (OSError, subprocess.SubprocessError):
        return "", -1


class Ctx:
    """Everything a check needs from the host. Tests inject ``runner`` / ``files`` / ``tools``."""

    def __init__(self, system=None, runner=None, files=None, tools=None, is_root=None, psutil_mod="auto"):
        self.system = system or platform.system()
        self._runner = runner or _default_run
        self.files = files                    # None = real filesystem; dict = fake filesystem for tests
        self.tools = tools                    # None = shutil.which; set = fake installed tools
        self.is_root = (os.geteuid() == 0 if hasattr(os, "geteuid") else False) if is_root is None else is_root
        if psutil_mod == "auto":
            try:
                import psutil as psutil_mod
            except ImportError:
                psutil_mod = None
        self.psutil = psutil_mod

    linux = property(lambda s: s.system == "Linux")
    mac = property(lambda s: s.system == "Darwin")
    windows = property(lambda s: s.system == "Windows")

    def run(self, cmd, timeout=30):
        assert isinstance(cmd, (list, tuple)), "commands must be argument lists"
        return self._runner(list(cmd), timeout)

    def ps(self, script, timeout=60):
        if not self.windows:
            return ""
        return self.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout)[0]

    def which(self, name):
        return (name in self.tools) if self.tools is not None else bool(shutil.which(name))

    def read(self, path, default=None):
        if self.files is not None:
            return self.files.get(path, default)
        try:
            return Path(path).read_text(errors="replace")
        except OSError:
            return default

    def exists(self, path):
        return (path in self.files) if self.files is not None else os.path.exists(path)

    def glob(self, pattern):
        if self.files is not None:
            return sorted(p for p in self.files if fnmatch.fnmatch(p, pattern))
        return sorted(_glob.glob(pattern))

    def processes(self):
        """[{pid, name, exe, cmdline, deleted}] via psutil, else ``ps``."""
        out = []
        if self.psutil:
            for p in self.psutil.process_iter(["pid", "name", "exe", "cmdline"]):
                try:
                    i = p.info
                    exe = i.get("exe") or ""
                    out.append({"pid": i["pid"], "name": i.get("name") or "", "exe": exe,
                                "cmdline": " ".join(i.get("cmdline") or []), "deleted": exe.endswith(" (deleted)")})
                except Exception:
                    continue
            return out
        o, rc = self.run(["ps", "-eo", "pid=,comm=,args="], 15)
        for line in o.splitlines():
            parts = line.split(None, 2)
            if len(parts) >= 2 and parts[0].isdigit():
                out.append({"pid": int(parts[0]), "name": parts[1], "exe": "", "cmdline": parts[2] if len(parts) > 2 else "",
                            "deleted": False})
        return out


def _json_list(text):
    if not text:
        return []
    d = json.loads(text)
    return [d] if isinstance(d, dict) else (d or [])


# ---------------------------------------------------------------- hashing / IOC
def sha256_file(path, limit=MAX_HASH_BYTES):
    h, n = hashlib.sha256(), 0
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                n += len(chunk)
                if n > limit:
                    return None
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return None


def load_ioc_hashes(path):
    try:
        return {ln.split()[0].lower() for ln in Path(path).read_text().splitlines()
                if ln.strip() and not ln.startswith("#") and len(ln.split()[0]) == 64}
    except OSError:
        return set()


# ---------------------------------------------------------------- listening ports
def parse_listeners(text):
    """-> [(addr, port)] from ss / netstat / lsof output. Only lines mentioning LISTEN are considered."""
    out = []
    for line in text.splitlines():
        if "LISTEN" not in line:
            continue
        for tok in line.split():
            m = re.fullmatch(r"(.+):(\d+)", tok)
            if m:
                addr = m.group(1).strip("[]").split("%")[0]
                out.append((addr, int(m.group(2))))
                break
    return out


def is_loopback_addr(addr):
    if addr.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(addr).is_loopback
    except ValueError:
        return False


def get_listeners(ctx):
    if ctx.windows:
        out = ctx.ps("Get-NetTCPConnection -State Listen | Select-Object LocalAddress,LocalPort | ConvertTo-Json")
        if not out:
            raise Skip("Get-NetTCPConnection returned nothing (needs PowerShell with the NetTCPIP module)")
        return [(str(x.get("LocalAddress", "")), int(x.get("LocalPort", 0))) for x in _json_list(out)]
    for cmd in (["ss", "-H", "-ltn"], ["lsof", "-nP", "-iTCP", "-sTCP:LISTEN"], ["netstat", "-tln"]):
        if ctx.which(cmd[0]):
            out, rc = ctx.run(cmd, 15)
            if rc == 0 and out:
                return parse_listeners(out)
    raise Skip("none of ss / lsof / netstat produced output")


def check_ports(ctx):
    exposed = {}
    for addr, port in get_listeners(ctx):
        if port in RISKY_PORTS and not is_loopback_addr(addr):   # 127.0.0.1-only services are not network exposure
            exposed.setdefault(port, set()).add(addr)
    return [F("Network", f"Risky Port {p} ({RISKY_PORTS[p]})", "WARNING", "High",
              f"Port {p} ({RISKY_PORTS[p]}) listens on {', '.join(sorted(a))}", "Bind to localhost or restrict with a firewall", "T1046")
            for p, a in sorted(exposed.items())]


# ---------------------------------------------------------------- firewall
def parse_ufw(text):
    m = re.search(r"^\s*Status:\s*(\w+)", text or "", re.M | re.I)
    return m.group(1).lower() if m else None                     # 'active' | 'inactive' | None (error/unknown)


def iptables_protective(text):
    """True when INPUT's default policy is DROP/REJECT or a rule drops/rejects traffic in INPUT or a custom
    (non built-in) chain. An empty ACCEPT-everything ruleset -> False."""
    pol = re.search(r"^-P INPUT (\w+)", text or "", re.M)
    if pol and pol.group(1) in ("DROP", "REJECT"):
        return True
    for m in re.finditer(r"^-A (\S+) .*-j (DROP|REJECT)\b", text or "", re.M):
        if m.group(1) not in ("OUTPUT", "FORWARD", "PREROUTING", "POSTROUTING"):
            return True
    return False


def nft_protective(text):
    for block in re.findall(r"chain\s+\S+\s*\{(.*?)\n\s*\}", text or "", re.S):
        if re.search(r"hook\s+input", block) and (re.search(r"policy\s+(drop|reject)", block) or re.search(r"\b(drop|reject)\b", block)):
            return True
    return False


def check_firewall(ctx):
    if ctx.linux:
        tried, protective, seen = False, False, []
        if ctx.which("ufw"):
            out, _ = ctx.run(["ufw", "status"], 8)
            st = parse_ufw(out)
            if st:
                tried, protective, seen = True, protective or st == "active", seen + [f"ufw {st}"]
        if ctx.which("firewall-cmd"):
            out, _ = ctx.run(["firewall-cmd", "--state"], 8)
            if out.strip() in ("running", "not running"):
                tried, protective, seen = True, protective or out.strip() == "running", seen + [f"firewalld {out.strip()}"]
        if ctx.which("nft"):
            out, rc = ctx.run(["nft", "list", "ruleset"], 10)
            if rc == 0:
                p = nft_protective(out)
                tried, protective, seen = True, protective or p, seen + [f"nftables {'filtering' if p else 'no input filtering'}"]
        if ctx.which("iptables"):
            out, rc = ctx.run(["iptables", "-S"], 10)
            if rc == 0 and out:
                p = iptables_protective(out)
                tried, protective, seen = True, protective or p, seen + [f"iptables {'filtering' if p else 'no input filtering'}"]
        if protective:
            return [F("Linux", "Host Firewall Active", "PASS", "Info", "; ".join(seen))]
        if tried:
            return [F("Linux", "Firewall Disabled", "FAIL", "High", "No host firewall with a restrictive inbound policy: " + "; ".join(seen),
                      "Enable ufw/firewalld or set a default-deny INPUT policy", "T1562.004")]
        raise Skip("could not query ufw / firewalld / nft / iptables (run the agent as root?)")
    if ctx.windows:
        o = ctx.ps("(Get-NetFirewallProfile | Where-Object {$_.Enabled -eq $false}).Count")
        if not o.strip().isdigit():
            raise Skip("Get-NetFirewallProfile returned no usable output")
        return ([F("Windows", "Firewall Disabled", "FAIL", "Critical", f"{o.strip()} firewall profile(s) off", "Enable the firewall", "T1562.004")]
                if int(o) > 0 else [])
    if ctx.mac:
        out, rc = ctx.run(["/usr/libexec/ApplicationFirewall/socketfilterfw", "--getglobalstate"], 8)
        if rc != 0:
            raise Skip("socketfilterfw unavailable")
        return ([] if re.search(r"enabled|State = [12]", out, re.I) and "disabled" not in out.lower() else
                [F("macOS", "Firewall Disabled", "FAIL", "Medium", out[:120], "Enable the application firewall", "T1562.004")])
    raise NotApplicable()


# ---------------------------------------------------------------- hardening
def sip_enabled(text):
    return "enabled" in (text or "").lower()


def filevault_on(text):
    return bool(re.search(r"FileVault is On", text or "", re.I))


def check_macos_hardening(ctx):
    if not ctx.mac:
        raise NotApplicable()
    out = []
    o, rc = ctx.run(["csrutil", "status"], 5)
    if rc != 0:
        raise Skip("csrutil unavailable")
    if not sip_enabled(o):
        out.append(F("macOS", "SIP Disabled", "FAIL", "Critical", f"SIP: {o}", "Enable SIP", "T1562.001"))
    o, rc = ctx.run(["fdesetup", "status"], 5)
    if rc == 0 and not filevault_on(o):
        out.append(F("macOS", "FileVault Disabled", "FAIL", "High", o[:100] or "FileVault off", "Enable FileVault", "T1486"))
    return out


def check_windows_hardening(ctx):
    if not ctx.windows:
        raise NotApplicable()
    out, answered = [], 0
    o = ctx.ps("(Get-MpComputerStatus).RealTimeProtectionEnabled")
    if o.strip():
        answered += 1
        if "false" in o.lower():
            out.append(F("Windows", "Defender RTP Disabled", "FAIL", "Critical", "Real-time protection is off", "Enable Defender RTP", "T1562.001"))
    o = ctx.ps("(Get-SmbServerConfiguration).EnableSMB1Protocol")
    if o.strip():
        answered += 1
        if "true" in o.lower():
            out.append(F("Windows", "SMBv1 Enabled", "FAIL", "High", "SMB1 server protocol is enabled", "Disable SMBv1", "T1210"))
    o = ctx.ps(r"(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System').EnableLUA")
    if o.strip():
        answered += 1
        if o.strip() == "0":
            out.append(F("Windows", "UAC Disabled", "FAIL", "High", "EnableLUA=0", "Enable UAC", "T1548.002"))
    o = ctx.ps("(Get-BitLockerVolume -MountPoint $env:SystemDrive).ProtectionStatus")
    if o.strip():
        answered += 1
        if o.strip().lower() in ("off", "0"):
            out.append(F("Windows", "BitLocker Disabled", "FAIL", "High", "System drive is not protected", "Enable BitLocker", "T1486"))
    if not answered:
        raise Skip("PowerShell queries returned nothing (needs Administrator)")
    return out


def check_linux_kernel(ctx):
    if not ctx.linux:
        raise NotApplicable()
    v = ctx.read("/proc/sys/kernel/randomize_va_space")
    if v is None:
        raise Skip("/proc/sys/kernel/randomize_va_space unreadable")
    return ([F("Linux", "ASLR Not Fully Enabled", "FAIL", "Medium", f"kernel.randomize_va_space={v.strip()}", "sysctl kernel.randomize_va_space=2", "T1068")]
            if v.strip() != "2" else [])


# ---------------------------------------------------------------- users
def passwd_uid0(text):
    return [p[0] for p in (ln.split(":") for ln in (text or "").splitlines()) if len(p) >= 3 and p[2] == "0" and p[0] != "root"]


def shadow_empty(text):
    return [p[0] for p in (ln.split(":") for ln in (text or "").splitlines()) if len(p) >= 2 and p[1] == ""]


def sudo_nopasswd(text):
    return [ln.strip() for ln in (text or "").splitlines() if "NOPASSWD" in ln and not ln.strip().startswith("#")]


def check_users(ctx):
    if not (ctx.linux or ctx.mac):
        raise NotApplicable()
    out = []
    pw = ctx.read("/etc/passwd")
    if pw is None:
        raise Skip("/etc/passwd unreadable")
    z = passwd_uid0(pw)
    if z:
        out.append(F("Users", "UID 0 Accounts", "FAIL", "Critical", f"Non-root UID 0: {', '.join(z)}", "Remove UID 0 from these accounts", "T1078.003"))
    sh = ctx.read("/etc/shadow")
    if sh is not None:
        e = shadow_empty(sh)
        if e:
            out.append(F("Users", "Empty Password Accounts", "FAIL", "Critical", f"No password set: {', '.join(e)}", "Lock or set a password", "T1078"))
    sudo = [ctx.read(p, "") for p in ["/etc/sudoers"] + ctx.glob("/etc/sudoers.d/*")]
    n = sudo_nopasswd("\n".join(sudo))
    if n:
        out.append(F("Users", "Sudo NOPASSWD", "WARNING", "Medium", f"{len(n)} NOPASSWD rule(s): {n[0][:100]}", "Require a password for sudo", "T1548.003"))
    return out


# ---------------------------------------------------------------- ssh
SSH_DEFAULTS = {"permitrootlogin": "prohibit-password", "passwordauthentication": "yes", "permitemptypasswords": "no"}


def parse_sshd_T(text):
    d = {}
    for ln in (text or "").splitlines():
        k, _, v = ln.strip().partition(" ")
        if k:
            d.setdefault(k.lower(), v.strip().lower())
    return d


def effective_sshd(lines):
    """Fallback when ``sshd -T`` is unavailable: OpenSSH semantics - first value wins, evaluation of the
    global section stops at the first ``Match`` block, defaults apply for unset keywords."""
    d = {}
    for raw in lines:
        ln = raw.split("#", 1)[0].strip()
        if not ln:
            continue
        k, _, v = ln.partition(" ") if " " in ln else (ln, "", "")
        k = k.lower()
        if k == "match":
            break
        if k and v and k not in d:
            d[k] = v.strip().strip('"').lower()
    return {**SSH_DEFAULTS, **d}


def _read_sshd_lines(ctx, path="/etc/ssh/sshd_config", depth=0):
    text = ctx.read(path)
    if text is None or depth > 4:
        return []
    out = []
    for ln in text.splitlines():
        m = re.match(r"\s*Include\s+(.+)", ln, re.I)
        if m:
            for pat in m.group(1).split():
                pat = pat if pat.startswith("/") else "/etc/ssh/" + pat
                for p in ctx.glob(pat):
                    out.extend(_read_sshd_lines(ctx, p, depth + 1))
        else:
            out.append(ln)
    return out


def check_ssh(ctx):
    if not (ctx.linux or ctx.mac):
        raise NotApplicable()
    cfg, src = None, ""
    if ctx.which("sshd"):
        o, rc = ctx.run(["sshd", "-T"], 10)
        if rc == 0 and o:
            cfg, src = {**SSH_DEFAULTS, **parse_sshd_T(o)}, "sshd -T"
    if cfg is None:
        lines = _read_sshd_lines(ctx)
        if not lines:
            if ctx.exists("/etc/ssh/sshd_config"):
                raise Skip("sshd_config unreadable and sshd -T unavailable")
            raise NotApplicable()
        cfg, src = effective_sshd(lines), "config files (sshd -T unavailable)"
    out = []
    if cfg.get("permitrootlogin") == "yes":
        out.append(F("SSH", "SSH Root Login", "FAIL", "High", f"PermitRootLogin yes ({src})", "Set PermitRootLogin no", "T1110"))
    if cfg.get("passwordauthentication") == "yes":
        out.append(F("SSH", "SSH Password Auth", "WARNING", "Medium", f"PasswordAuthentication yes ({src})", "Use keys only", "T1110"))
    if cfg.get("permitemptypasswords") == "yes":
        out.append(F("SSH", "SSH Empty Passwords", "FAIL", "High", f"PermitEmptyPasswords yes ({src})", "Set PermitEmptyPasswords no", "T1110"))
    return out


# ---------------------------------------------------------------- proxy SDKs
def check_proxy(ctx):
    out, seen = [], set()
    if ctx.windows:
        o = ctx.ps(r"Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, "
                   r"HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName | ConvertTo-Json")
        names = [(x.get("DisplayName") or "") for x in _json_list(o)]
        hay = [(n, n.lower()) for n in names]
    else:
        me = os.getpid()
        hay = [(f"{p['name']} {p['cmdline']}"[:150], f"{p['name']} {p['cmdline']}".lower()) for p in ctx.processes() if p["pid"] != me]
    for shown, low in hay:
        for ind in PROXY_INDICATORS:
            if ind in low and ind not in seen:
                seen.add(ind)
                out.append(F("Proxy Detection", "Residential Proxy SDK", "FAIL", "Critical", f"Detected: {shown}", "Investigate / uninstall", "T1090"))
    return out


# ---------------------------------------------------------------- updates
def parse_apt_upgradable(text):
    total = sec = 0
    for ln in (text or "").splitlines():
        m = re.match(r"^(\S+)/(\S+)\s", ln)
        if m:
            total += 1
            sec += "-security" in m.group(2)
    return total, sec


def check_updates(ctx):
    if ctx.linux and ctx.which("apt"):
        o, rc = ctx.run(["apt", "list", "--upgradable"], 60)
        total, sec = parse_apt_upgradable(o)
        if sec:
            return [F("Vulnerability", "Pending Security Updates", "WARNING", "High", f"{sec} security update(s) of {total} upgradable", "sudo apt upgrade", "T1195")]
        if total:
            return [F("Vulnerability", "Pending Updates", "WARNING", "Low", f"{total} non-security update(s) pending", "sudo apt upgrade", "T1195")]
        return []
    if ctx.linux and (ctx.which("dnf") or ctx.which("yum")):
        tool = "dnf" if ctx.which("dnf") else "yum"
        o, rc = ctx.run([tool, "-q", "check-update", "--security"], 120)
        if rc == 100:
            n = len([ln for ln in o.splitlines() if ln.strip() and not ln.startswith(("Last metadata", "Obsoleting"))])
            return [F("Vulnerability", "Pending Security Updates", "WARNING", "High", f"{n} security update(s) available", f"sudo {tool} update --security", "T1195")]
        if rc == 0:
            return []
        raise Skip(f"{tool} check-update failed (rc={rc})")
    if ctx.mac:
        out = []
        if ctx.which("softwareupdate"):
            o, rc = ctx.run(["softwareupdate", "-l"], 180)
            n = len(re.findall(r"^\s*\*\s+(Label:)?", o, re.M))
            if n:
                out.append(F("Vulnerability", "Pending Updates", "WARNING", "Medium", f"{n} macOS update(s) available", "softwareupdate -i -a", "T1195"))
        if ctx.which("brew"):
            o, _ = ctx.run(["brew", "outdated"], 90)
            if o.strip():
                out.append(F("Vulnerability", "Outdated Homebrew Packages", "WARNING", "Low", f"{len(o.splitlines())} outdated", "brew upgrade", "T1195"))
        return out
    raise NotApplicable()


# ---------------------------------------------------------------- outbound connections
def is_public_ip(ip):
    try:
        return ipaddress.ip_address(str(ip).strip("[]").split("%")[0]).is_global
    except ValueError:
        return False


def check_external_connections(ctx, cap=200):
    pairs = {}
    if ctx.windows:
        for c in _json_list(ctx.ps("Get-NetTCPConnection -State Established | Select-Object RemoteAddress,RemotePort,OwningProcess | ConvertTo-Json")):
            if is_public_ip(c.get("RemoteAddress", "")):
                pairs.setdefault((c["RemoteAddress"], c.get("RemotePort")), set()).add(str(c.get("OwningProcess")))
    elif ctx.psutil:
        try:
            conns = ctx.psutil.net_connections(kind="inet")
        except Exception as e:
            raise Skip(f"psutil.net_connections failed ({type(e).__name__}); run as root")
        names = {}
        for c in conns:
            if c.status == "ESTABLISHED" and c.raddr and is_public_ip(c.raddr.ip):
                if c.pid and c.pid not in names:
                    try:
                        names[c.pid] = ctx.psutil.Process(c.pid).name()
                    except Exception:
                        names[c.pid] = str(c.pid)
                pairs.setdefault((c.raddr.ip, c.raddr.port), set()).add(names.get(c.pid, "?"))
    else:
        o, rc = ctx.run(["ss", "-H", "-tn", "state", "established"] if ctx.which("ss") else ["netstat", "-tn"], 20)
        if rc != 0:
            raise Skip("neither psutil, ss nor netstat available")
        for ln in o.splitlines():
            toks = [t for t in ln.split() if re.fullmatch(r"\S+:\d+", t)]
            if len(toks) >= 2:
                ip, _, port = toks[1].rpartition(":")
                if is_public_ip(ip):
                    pairs.setdefault((ip.strip("[]"), int(port)), set())
    out = [F("Network", "External Connection", "INFO", "Low", f"{ip}:{port}" + (f" ({', '.join(sorted(p))})" if p else ""),
             "Verify the destination is expected", "T1071") for (ip, port), p in sorted(pairs.items(), key=lambda kv: str(kv[0]))[:cap]]
    if len(pairs) > cap:
        out.append(F("Network", "External Connection Summary", "INFO", "Low", f"{len(pairs) - cap} more destinations not listed"))
    return out


# ---------------------------------------------------------------- processes
TEMP_FRAGMENTS_UNIX = ("/tmp/", "/var/tmp/", "/dev/shm/")   # nosec B108 - locations to inspect, not files we create
TEMP_FRAGMENTS_WIN = ("\\temp\\", "\\downloads\\", "\\users\\public\\")


def suspicious_exe(path, system):
    """True for binaries running from world-writable / staging locations (not merely any \\AppData\\ install)."""
    p = (path or "")
    low = p.lower()
    if low.endswith(" (deleted)"):
        return "binary deleted from disk while running"
    if system == "Windows":
        return "runs from a temp/download directory" if any(f in low for f in TEMP_FRAGMENTS_WIN) else ""
    return "runs from a temp directory" if any(low.startswith(f) or f in low for f in TEMP_FRAGMENTS_UNIX) else ""


def check_processes(ctx, ioc=None):
    if not ctx.psutil:
        raise Skip("psutil not installed")
    ioc = ioc or set()
    out = []
    for p in ctx.processes():
        why = suspicious_exe(p["exe"], ctx.system)
        if not why:
            continue
        exe = p["exe"].replace(" (deleted)", "")
        sha = sha256_file(exe) if exe and not p["deleted"] else None
        hit = bool(sha and sha in ioc)
        out.append(F("Process", "Known-Bad Process (IOC)" if hit else "Suspicious Process", "FAIL" if hit else "WARNING",
                     "Critical" if hit else "High", f"{p['name']} (PID {p['pid']}): {why}: {p['exe']}",
                     "Investigate; consider isolating the host", "T1204", sha256=sha))
    return out


# ---------------------------------------------------------------- files
WIN_EXTS = (".exe", ".dll", ".ps1", ".bat", ".vbs", ".js", ".hta", ".scr", ".cmd", ".jar")
MAGICS = (b"\x7fELF", b"MZ", b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe", b"\xca\xfe\xba\xbe")


def classify_file(path, st, system):
    """Return a short reason string when the file is an executable/script, else ''."""
    low = path.lower()
    try:
        with open(path, "rb") as f:
            head = f.read(4)
    except OSError:
        head = b""
    if head.startswith(MAGICS):
        return "native executable"
    if system == "Windows":
        return "script/executable extension" if low.endswith(WIN_EXTS) else ""
    if head[:2] == b"#!" and st.st_mode & 0o111:
        return "executable script"
    return ""


def default_scan_paths(ctx):
    if ctx.windows:
        return [p for p in (r"C:\Windows\Temp", os.environ.get("TEMP", "")) if p]
    return ["/tmp", "/var/tmp", "/dev/shm"]   # nosec B108 - default scan locations


def iter_files(paths, max_files=500000, deadline=None):
    seen = 0
    for base in paths:
        if not os.path.isabs(base) and not re.match(r"^[A-Za-z]:\\", base):
            continue
        for root, dirs, files in os.walk(base, followlinks=False):
            for f in files:
                seen += 1
                if seen > max_files or (deadline and time.time() > deadline):
                    return
                yield os.path.join(root, f)


def check_files(ctx, paths=None, ioc=None, max_findings=10000, time_budget=600):
    paths = paths or default_scan_paths(ctx)
    ioc = ioc or set()
    out = []
    for fp in iter_files(paths, deadline=time.time() + time_budget):
        try:
            st = os.lstat(fp)
        except OSError:
            continue
        if not stat.S_ISREG(st.st_mode):
            continue                                              # skip symlinks, devices, sockets
        why = classify_file(fp, st, ctx.system)
        if not why:
            continue
        sha = sha256_file(fp)
        hit = bool(sha and sha in ioc)
        mt = datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(timespec="seconds")
        out.append(F("File", "Known-Bad File (IOC)" if hit else "Suspicious File", "FAIL" if hit else "WARNING",
                     "Critical" if hit else "Medium", f"{fp} ({st.st_size} bytes, {why}, modified {mt}, uid {st.st_uid})",
                     "Investigate; compare the hash with threat intel", "T1204", sha256=sha))
        if len(out) >= max_findings:
            out.append(F("File", "Result Truncated", "INFO", "Info", f"stopped after {max_findings} findings"))
            break
    return out


def ioc_sweep(ctx, paths, sha256s, yara_text="", max_files=200000, time_budget=900):
    """Hunt: hash every file under ``paths`` against supplied SHA-256 IOCs and (optionally) YARA rules."""
    wanted = {h.lower() for h in sha256s or []} | load_ioc_hashes(str(Path.home() / ".af_agent" / "ioc_sha256.txt"))
    rules, yara_note = None, ""
    if yara_text:
        try:
            import yara
            rules = yara.compile(source=yara_text)
        except ImportError:
            yara_note = "yara-python not installed on the agent: YARA rules skipped"
        except Exception as e:
            raise Skip(f"YARA rules did not compile: {str(e)[:150]}")
    if not paths:
        paths = default_scan_paths(ctx)
    out, n = [], 0
    for fp in iter_files(paths, max_files=max_files, deadline=time.time() + time_budget):
        try:
            if not stat.S_ISREG(os.lstat(fp).st_mode):
                continue
        except OSError:
            continue
        n += 1
        sha = sha256_file(fp) if wanted else None
        if sha and sha in wanted:
            out.append(F("IOC Sweep", "IOC Hash Match", "FAIL", "Critical", f"{fp} matches a supplied SHA-256 indicator", "Contain and investigate", "T1204", sha256=sha))
        if rules:
            try:
                if os.path.getsize(fp) <= 50 * 1024 * 1024:
                    for m in rules.match(fp, timeout=10):
                        out.append(F("IOC Sweep", "YARA Match", "FAIL", "Critical", f"{fp} matches rule {m.rule}", "Contain and investigate", "T1204",
                                     sha256=sha or sha256_file(fp)))
            except Exception:
                continue
    out.append(F("IOC Sweep", "Sweep Coverage", "INFO", "Info", f"{n} files examined under {', '.join(paths)}" + (f"; {yara_note}" if yara_note else "")))
    return out


# ---------------------------------------------------------------- services / inventory
def check_services(ctx, cap=500):
    out = []
    if ctx.windows:
        for s in _json_list(ctx.ps("Get-Service | Where-Object {$_.Status -eq 'Running'} | Select-Object Name,DisplayName | ConvertTo-Json"))[:cap]:
            out.append(F("Service", f"Service: {s.get('Name')}", "PASS", "Info", s.get("DisplayName", ""), check_id="AF-SERV-running"))
    elif ctx.which("systemctl"):
        o, rc = ctx.run(["systemctl", "list-units", "--type=service", "--state=running", "--no-pager", "--plain"], 15)
        if rc != 0:
            raise Skip("systemctl failed")
        for ln in o.splitlines():
            if ".service" in ln.split(" ")[0]:
                out.append(F("Service", f"Service: {ln.split()[0]}", "PASS", "Info", ln.strip()[:200], check_id="AF-SERV-running"))
                if len(out) >= cap:
                    break
    else:
        raise Skip("no service manager query available")
    return out


def parse_os_release(text):
    d = {}
    for ln in (text or "").splitlines():
        k, _, v = ln.partition("=")
        if k and v:
            d[k.strip()] = v.strip().strip('"')
    return d


def collect_inventory(ctx, agent_ip="", boot=None):
    inv = {"hostname": platform.node(), "os": f"{platform.system()} {platform.release()}", "os_full": platform.platform(),
           "arch": platform.machine(), "ip": agent_ip, "python": platform.python_version(), "boot_time": None,
           "cpu_count": None, "memory_gb": None, "disk_gb": None, "packages": [], "processes_count": 0, "os_release": {}}
    if ctx.linux:
        inv["os_release"] = parse_os_release(ctx.read("/etc/os-release", ""))
    if ctx.psutil:
        try:
            inv["boot_time"] = datetime.fromtimestamp(ctx.psutil.boot_time(), timezone.utc).isoformat(timespec="seconds")
            inv["cpu_count"] = ctx.psutil.cpu_count()
            inv["memory_gb"] = round(ctx.psutil.virtual_memory().total / 1024 ** 3, 2)
            inv["disk_gb"] = round(ctx.psutil.disk_usage("/").total / 1024 ** 3, 2)
            inv["processes_count"] = len(ctx.psutil.pids())
        except Exception:
            pass
    pk = inv["packages"]
    if ctx.mac and ctx.which("brew"):
        for ln in ctx.run(["brew", "list", "--versions"], 60)[0].splitlines():
            p = ln.split()
            if len(p) >= 2:
                pk.append({"name": p[0], "version": p[-1]})
    elif ctx.linux and ctx.which("dpkg-query"):
        for ln in ctx.run(["dpkg-query", "-W", "-f=${Package}\t${Version}\t${Source}\n"], 60)[0].splitlines():
            p = ln.split("\t")
            if len(p) >= 2:
                src = re.sub(r"\s*\(.*\)", "", p[2]).strip() if len(p) > 2 else ""
                pk.append({"name": p[0], "version": p[1], **({"source": src} if src and src != p[0] else {})})
    elif ctx.linux and ctx.which("rpm"):
        for ln in ctx.run(["rpm", "-qa", "--qf", "%{NAME}\t%{VERSION}-%{RELEASE}\n"], 60)[0].splitlines():
            p = ln.split("\t")
            if len(p) >= 2:
                pk.append({"name": p[0], "version": p[1]})
    return inv


# ---------------------------------------------------------------- SCAP (OpenSCAP) results
_SEV = {"high": "High", "medium": "Medium", "low": "Low", "info": "Info", "unknown": "Low"}


def parse_xccdf_results(xml_text, max_pass=0):
    """OpenSCAP/XCCDF results -> findings. pass is summarised (not listed) unless ``max_pass`` > 0."""
    if re.search(r"<!(DOCTYPE|ENTITY)", xml_text, re.I):          # no DTDs/entities in XCCDF: blocks entity-expansion attacks
        raise ValueError("refusing XCCDF with a DOCTYPE/ENTITY declaration")
    root = ET.fromstring(xml_text)  # nosec B314 - DTDs rejected above
    ns = {"x": root.tag.split("}")[0].strip("{")} if root.tag.startswith("{") else {}
    q = (lambda t: f".//x:{t}") if ns else (lambda t: f".//{t}")
    findings, counts = [], {}
    for rr in root.iterfind(q("rule-result"), ns):
        res = (rr.findtext("x:result" if ns else "result", "", ns) or "").strip()
        counts[res] = counts.get(res, 0) + 1
        rid = rr.get("idref", "")
        sev = _SEV.get((rr.get("severity") or "unknown").lower(), "Low")
        short = rid.replace("xccdf_org.ssgproject.content_rule_", "")
        idents = [i.text for i in rr.iterfind("x:ident" if ns else "ident", ns) if i.text][:4]
        if res == "fail":
            findings.append(F("SCAP", f"SCAP: {short}", "FAIL", sev, f"Rule {rid} failed" + (f" ({', '.join(idents)})" if idents else ""),
                              "See the benchmark rule remediation", "", check_id=f"SCAP:{short}"))
        elif res in ("error", "unknown"):
            findings.append(F("SCAP", f"SCAP: {short}", "ERROR", "Info", f"Rule {rid} could not be evaluated ({res})", check_id=f"SCAP:{short}"))
        elif res == "pass" and max_pass > 0 and counts[res] <= max_pass:
            findings.append(F("SCAP", f"SCAP: {short}", "PASS", "Info", f"Rule {rid} passed", check_id=f"SCAP:{short}"))
    findings.append(F("SCAP", "SCAP Summary", "INFO", "Info", ", ".join(f"{k}={v}" for k, v in sorted(counts.items())) or "no rule results"))
    return findings


def find_datastream(ctx):
    rel = parse_os_release(ctx.read("/etc/os-release", ""))
    ident = (rel.get("ID", "") + re.sub(r"\D", "", rel.get("VERSION_ID", ""))).lower()
    cands = ctx.glob("/usr/share/xml/scap/ssg/content/ssg-*-ds.xml")
    for c in cands:
        if ident and ident in os.path.basename(c).lower().replace("-", "").replace("ssg", ""):
            return c
    return cands[0] if len(cands) == 1 else ""


def check_scap(ctx, profile="", datastream=""):
    if not ctx.linux:
        raise NotApplicable()
    if not ctx.which("oscap"):
        raise Skip("OpenSCAP (oscap) is not installed; install openscap-scanner and scap-security-guide")
    ds = datastream or find_datastream(ctx)
    if not ds:
        raise Skip("no SCAP datastream found (install scap-security-guide or pass 'datastream')")
    if not profile:
        raise Skip("no 'profile' given (e.g. xccdf_org.ssgproject.content_profile_cis)")
    out_xml = Path.home() / ".af_agent" / "scap-results.xml"
    out_xml.parent.mkdir(parents=True, exist_ok=True)
    o, rc = ctx.run(["oscap", "xccdf", "eval", "--profile", profile, "--results", str(out_xml), ds], 1500)
    if rc not in (0, 2) or not out_xml.exists():                 # oscap: 0 = all pass, 2 = some fail
        raise RuntimeError(f"oscap exited {rc}: {o[:200]}")
    return parse_xccdf_results(out_xml.read_text())


# ---------------------------------------------------------------- triage collection (chain of custody)
LINUX_FILES = ["/etc/passwd", "/etc/group", "/etc/hosts", "/etc/resolv.conf", "/etc/crontab", "/etc/cron.d/*", "/var/spool/cron/*",
               "/var/spool/cron/crontabs/*", "/etc/ssh/sshd_config", "/etc/ssh/sshd_config.d/*", "/etc/systemd/system/*.service",
               "/root/.bash_history", "/home/*/.bash_history", "/root/.ssh/authorized_keys", "/home/*/.ssh/authorized_keys"]
LINUX_TAILS = ["/var/log/auth.log", "/var/log/secure", "/var/log/syslog", "/var/log/messages"]
LINUX_CMDS = {"ps.txt": ["ps", "-eo", "pid,ppid,user,lstart,args"], "connections.txt": ["ss", "-tunap"], "listeners.txt": ["ss", "-ltnup"],
              "lsmod.txt": ["lsmod"], "last.txt": ["last", "-n", "100"], "who.txt": ["who", "-a"], "mount.txt": ["mount"],
              "ip_addr.txt": ["ip", "addr"], "iptables_save.txt": ["iptables-save"], "systemctl_units.txt": ["systemctl", "list-unit-files", "--no-pager"]}
MAC_FILES = ["/etc/hosts", "/Library/LaunchDaemons/*.plist", "/Library/LaunchAgents/*.plist", "/Users/*/Library/LaunchAgents/*.plist",
             "/Users/*/.zsh_history", "/Users/*/.bash_history"]
MAC_CMDS = {"ps.txt": ["ps", "-axo", "pid,ppid,user,lstart,command"], "connections.txt": ["lsof", "-nP", "-i"], "last.txt": ["last", "-n", "100"],
            "mount.txt": ["mount"], "ifconfig.txt": ["ifconfig"]}
WIN_PS = {"scheduled_tasks.txt": "Get-ScheduledTask | Select TaskName,TaskPath,State | Format-Table -Auto | Out-String -Width 300",
          "services.txt": "Get-CimInstance Win32_Service | Select Name,State,StartMode,PathName | Format-List | Out-String -Width 300",
          "run_keys.txt": r"Get-ItemProperty 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' | Out-String",
          "local_users.txt": "Get-LocalUser | Select Name,Enabled,LastLogon | Format-Table -Auto | Out-String",
          "processes.txt": "Get-CimInstance Win32_Process | Select ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | Format-List | Out-String -Width 300",
          "netstat.txt": "Get-NetTCPConnection | Select LocalAddress,LocalPort,RemoteAddress,RemotePort,State,OwningProcess | Format-Table -Auto | Out-String -Width 300"}
TAIL_BYTES = 2 * 1024 * 1024
FILE_CAP = 5 * 1024 * 1024


def build_triage(ctx, dest_dir, host, agent_version, collector="af_agent"):
    """Collect volatile and persistence artifacts into a zip with a SHA-256 manifest and chain-of-custody header.
    -> (zip_path, manifest_dict). Read-only on the host (never modifies collected files)."""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(dest_dir, 0o700)
    except OSError:
        pass
    started = datetime.now(timezone.utc)
    zp = dest_dir / f"triage_{re.sub(r'[^A-Za-z0-9_.-]', '_', host)}_{started.strftime('%Y%m%dT%H%M%SZ')}.zip"
    entries, errors = [], []

    def add(zf, arcname, data, source, mtime=None):
        zf.writestr(arcname, data)
        b = data if isinstance(data, bytes) else data.encode()
        entries.append({"name": arcname, "source": source, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest(),
                        "source_mtime": mtime})

    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        pats, cmds = (LINUX_FILES, LINUX_CMDS) if ctx.linux else (MAC_FILES, MAC_CMDS) if ctx.mac else ([], {})
        for pat in pats:
            for p in ctx.glob(pat):
                try:
                    if os.path.islink(p) or not os.path.isfile(p):
                        continue
                    with open(p, "rb") as f:
                        data = f.read(FILE_CAP)
                    add(zf, "files" + p, data, p, datetime.fromtimestamp(os.path.getmtime(p), timezone.utc).isoformat(timespec="seconds"))
                except OSError as e:
                    errors.append(f"{p}: {e.strerror}")
        if ctx.linux:
            for p in LINUX_TAILS:
                try:
                    if os.path.isfile(p):
                        size = os.path.getsize(p)
                        with open(p, "rb") as f:
                            f.seek(max(0, size - TAIL_BYTES))
                            add(zf, "logs" + p + ".tail", f.read(), p)
                except OSError as e:
                    errors.append(f"{p}: {e.strerror}")
        for name, cmd in cmds.items():
            if ctx.which(cmd[0]):
                o, rc = ctx.run(cmd, 30)
                add(zf, "commands/" + name, o, " ".join(cmd))
                if rc not in (0,):
                    errors.append(f"{' '.join(cmd)}: rc={rc}")
        if ctx.windows:
            for name, script in WIN_PS.items():
                add(zf, "commands/" + name, ctx.ps(script, 120), "powershell: " + script[:60])
            tmp = Path(os.environ.get("TEMP", ".")) / "af_evtx"
            tmp.mkdir(parents=True, exist_ok=True)
            for ch in ("Security", "System", "Microsoft-Windows-PowerShell/Operational"):
                f = tmp / (ch.replace("/", "_") + ".evtx")
                f.unlink(missing_ok=True)
                _, rc = ctx.run(["wevtutil", "epl", ch, str(f)], 180)
                if rc == 0 and f.exists():
                    add(zf, f"eventlogs/{f.name}", f.read_bytes()[:200 * 1024 * 1024], "wevtutil epl " + ch)
                    f.unlink(missing_ok=True)
                else:
                    errors.append(f"wevtutil {ch}: rc={rc} (needs Administrator)")
        manifest = {"format": "af-triage-1", "host": host, "collector": collector, "collector_version": agent_version,
                    "collected_utc": started.isoformat(timespec="seconds"),
                    "finished_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "collector_privileged": bool(ctx.is_root), "entries": entries, "errors": errors,
                    "note": "Collection was read-only. Verify each entry's sha256, then the sha256 of this archive recorded by the manager."}
        zf.writestr("MANIFEST.json", json.dumps(manifest, indent=1))
    try:
        os.chmod(zp, 0o600)
    except OSError:
        pass
    manifest["archive"] = str(zp)
    manifest["archive_sha256"] = sha256_file(str(zp), limit=10 ** 12)
    manifest["archive_bytes"] = zp.stat().st_size
    return zp, manifest


# ---------------------------------------------------------------- live response (agent must opt in)
def quarantine_file(path, qdir):
    """Move a regular file into a locked-down quarantine directory, keeping its hash and origin. Returns details."""
    p = Path(path)
    if not p.is_absolute():
        raise ValueError("absolute path required")
    st = os.lstat(p)                                           # lstat: never follow a symlink
    if not stat.S_ISREG(st.st_mode):
        raise ValueError("not a regular file (symlinks and devices are refused)")
    sha = sha256_file(str(p), limit=10 ** 12)
    qdir = Path(qdir)
    qdir.mkdir(parents=True, exist_ok=True)
    os.chmod(qdir, 0o700)
    dest = qdir / f"{sha}.quar"
    shutil.move(str(p), str(dest))
    os.chmod(dest, 0o000)
    meta = {"original_path": str(p), "sha256": sha, "bytes": st.st_size, "mode": oct(st.st_mode),
            "uid": st.st_uid, "quarantined_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    (qdir / f"{sha}.json").write_text(json.dumps(meta, indent=1))
    return meta


def kill_process(psutil_mod, pid, expect_name="", protected_pids=()):
    if pid <= 1 or pid in protected_pids:
        raise ValueError("refusing to signal this PID")
    p = psutil_mod.Process(pid)
    name = p.name()
    if expect_name and name != expect_name:
        raise ValueError(f"PID {pid} is '{name}', expected '{expect_name}' (PID reuse?) - not killed")
    exe = ""
    try:
        exe = p.exe()
    except Exception:
        pass
    p.terminate()
    try:
        p.wait(5)
    except Exception:
        p.kill()
    return {"pid": pid, "name": name, "exe": exe}


def isolation_plan(system, manager_ips):
    """Command lists that cut the host off from everything except the manager. Pure function (unit-tested)."""
    ips = [i for i in manager_ips if i]
    if not ips:
        raise ValueError("manager address unknown: refusing to isolate (the host would become unreachable)")
    if system == "Linux":
        cmds = [["iptables", "-N", "AF_ISOLATE"], ["iptables", "-F", "AF_ISOLATE"],
                ["iptables", "-A", "AF_ISOLATE", "-o", "lo", "-j", "ACCEPT"], ["iptables", "-A", "AF_ISOLATE", "-i", "lo", "-j", "ACCEPT"]]
        for ip in ips:
            cmds += [["iptables", "-A", "AF_ISOLATE", "-d", ip, "-j", "ACCEPT"], ["iptables", "-A", "AF_ISOLATE", "-s", ip, "-j", "ACCEPT"]]
        cmds += [["iptables", "-A", "AF_ISOLATE", "-j", "DROP"], ["iptables", "-I", "INPUT", "1", "-j", "AF_ISOLATE"],
                 ["iptables", "-I", "OUTPUT", "1", "-j", "AF_ISOLATE"]]
        return cmds
    if system == "Windows":
        cmds = []
        for ip in ips:
            cmds.append(["netsh", "advfirewall", "firewall", "add", "rule", "name=AF_ISOLATE_ALLOW_MANAGER_OUT", "dir=out", "action=allow", f"remoteip={ip}"])
            cmds.append(["netsh", "advfirewall", "firewall", "add", "rule", "name=AF_ISOLATE_ALLOW_MANAGER_IN", "dir=in", "action=allow", f"remoteip={ip}"])
        cmds.append(["netsh", "advfirewall", "set", "allprofiles", "firewallpolicy", "blockinbound,blockoutbound"])
        return cmds
    raise ValueError(f"host isolation is not supported on {system}")


def release_plan(system):
    if system == "Linux":
        return [["iptables", "-D", "INPUT", "-j", "AF_ISOLATE"], ["iptables", "-D", "OUTPUT", "-j", "AF_ISOLATE"],
                ["iptables", "-F", "AF_ISOLATE"], ["iptables", "-X", "AF_ISOLATE"]]
    if system == "Windows":
        return [["netsh", "advfirewall", "set", "allprofiles", "firewallpolicy", "blockinbound,allowoutbound"],
                ["netsh", "advfirewall", "firewall", "delete", "rule", "name=AF_ISOLATE_ALLOW_MANAGER_OUT"],
                ["netsh", "advfirewall", "firewall", "delete", "rule", "name=AF_ISOLATE_ALLOW_MANAGER_IN"]]
    raise ValueError(f"host isolation is not supported on {system}")


# ---------------------------------------------------------------- composite audits
def run_local_audit(ctx, ioc=None):
    c = Collector()
    for name, fn in (("ports", check_ports), ("firewall", check_firewall), ("macos_hardening", check_macos_hardening),
                     ("windows_hardening", check_windows_hardening), ("linux_kernel", check_linux_kernel), ("users", check_users),
                     ("ssh", check_ssh), ("proxy", check_proxy), ("updates", check_updates)):
        c.run(name, fn, ctx)
    return c


def run_network_scan(ctx):
    return Collector().run("external_connections", check_external_connections, ctx)


def run_process_scan(ctx, ioc=None):
    return Collector().run("processes", check_processes, ctx, ioc)


def run_service_scan(ctx):
    return Collector().run("services", check_services, ctx)


def run_file_scan(ctx, paths=None, ioc=None):
    return Collector().run("files", check_files, ctx, paths or None, ioc)
