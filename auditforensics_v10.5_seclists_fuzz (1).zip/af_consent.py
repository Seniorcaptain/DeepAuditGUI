#!/usr/bin/env python3
"""Builds a signed, tamper-evident PDF of a scan authorization (the record af_scope.record_authorization writes
to scan_authorizations). The record's canonical text is Ed25519-signed with af_signing under a dedicated key
(separate from command-signing and manifest-signing, so compromising one does not implicate the others); the
signature and public key are printed on the PDF so the record can be verified independently of the database.

Needs reportlab (requirements-optional.txt). Degrades by raising RuntimeError with a clear message when it is
not installed - callers should catch that and show it rather than fail silently.
"""
import hashlib
import io
from datetime import datetime, timezone

import af_signing

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    HAS_REPORTLAB = True
except ImportError:                                      # pragma: no cover
    HAS_REPORTLAB = False

CONSENT_KEY = "consent_signing"
FIELDS = ("id", "ts", "username", "scan_type", "targets", "reason", "ticket")


def _targets_text(t):
    return ", ".join(t) if isinstance(t, (list, tuple)) else str(t or "")


def canonical_text(record):
    """Deterministic text representation of the fields that matter: edit any one and the hash changes."""
    r = dict(record)
    r["targets"] = _targets_text(r.get("targets"))
    return "\n".join(f"{k}: {r.get(k, '') or ''}" for k in FIELDS)


def sign_record(record):
    """-> (signature_b64, public_key_pem, sha256_hex) over the canonical text."""
    msg = canonical_text(record).encode()
    sig = af_signing.sign(CONSENT_KEY, msg)
    pub = af_signing.public_pem(CONSENT_KEY)
    return sig, pub, hashlib.sha256(msg).hexdigest()


def verify_record(record, sig, pub):
    return af_signing.verify(pub, sig, canonical_text(record).encode())


def pdf_available():
    return HAS_REPORTLAB


def build_pdf(record, org_name="AuditForensics", generated_by=""):
    """-> PDF bytes. ``record`` needs id, ts, username, scan_type, targets (list or str), reason, ticket.
    Raises RuntimeError if reportlab is not installed."""
    if not HAS_REPORTLAB:
        raise RuntimeError("reportlab is not installed (pip install reportlab, or: pip install -r requirements-optional.txt)")
    sig, pub, digest = sign_record(record)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=22 * mm, bottomMargin=18 * mm, leftMargin=20 * mm, rightMargin=20 * mm,
                            title=f"Scan Authorization #{record.get('id', '')}", author=org_name)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("Small", parent=styles["Normal"], fontSize=8, textColor=colors.grey, leading=11))
    styles.add(ParagraphStyle("Mono", parent=styles["Small"], fontName="Courier", fontSize=7.5, leading=10))

    def esc(s):
        return str(s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    story = [Paragraph("Scan Authorization Record", styles["Title"]),
             Paragraph(esc(f"{org_name} - AuditForensics"), styles["Normal"]), Spacer(1, 12)]
    rows = [["Record ID", f"#{record.get('id', '-')}"],
            ["Authorized by", esc(record.get("username", ""))],
            ["Date / time (UTC)", esc(str(record.get("ts", ""))[:19])],
            ["Scan type", esc(record.get("scan_type", ""))],
            ["Target(s)", esc(_targets_text(record.get("targets")))],
            ["Reason / justification", esc(record.get("reason", ""))],
            ["Ticket / change reference", esc(record.get("ticket", "")) or "-"]]
    t = Table([[Paragraph(a, styles["Normal"]), Paragraph(b, styles["Normal"])] for a, b in rows],
              colWidths=[48 * mm, 117 * mm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
                          ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    story += [t, Spacer(1, 14),
              Paragraph("The person named above confirmed, at the time and date shown, that they hold written "
                       "permission from the owner of the target(s) listed to run the scan described, and recorded "
                       "that confirmation in AuditForensics before the scan began. This record was generated "
                       "automatically from that confirmation and has not been edited since.", styles["Normal"]),
              Spacer(1, 16), HRFlowable(width="100%", thickness=0.5, color=colors.lightgrey), Spacer(1, 8),
              Paragraph("Integrity", styles["Heading3"]),
              Paragraph("This record is signed so any later change to the fields above can be detected.", styles["Small"]),
              Spacer(1, 4),
              Paragraph(f"SHA-256: {digest}", styles["Mono"]),
              Paragraph(f"Ed25519 signature (base64): {sig}", styles["Mono"]),
              Paragraph("Public key (PEM):", styles["Small"]),
              Paragraph(pub.replace("\n", "<br/>"), styles["Mono"]),
              Spacer(1, 6),
              Paragraph("Verify: af_signing.verify(pub_pem, signature, canonical_text(record).encode()) using "
                       "af_consent.canonical_text() with the same field values.", styles["Small"])]
    if generated_by:
        story += [Spacer(1, 10), Paragraph(esc(f"PDF generated by {generated_by} on "
                                               f"{datetime.now(timezone.utc).isoformat(timespec='seconds')} UTC"), styles["Small"])]
    doc.build(story)
    return buf.getvalue()
