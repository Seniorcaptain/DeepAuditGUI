#!/usr/bin/env python3
"""AuditForensics background worker (runs independently of the Streamlit UI).

  * lease requeue + retention pruning for the agent API tables
  * fleet schedules (kind='fleet'): queues run_local_audit on online agents
Run it as its own service and set AF_EXTERNAL_WORKER=1 for the UI so it does not duplicate this work.
Local-machine scheduled scans (kind='local') still run inside the UI process because the scan engines live there.
"""
import datetime, os, sqlite3, sys, time

import af_manager_api as api
from af_util import utc_iso, utcnow

TICK = int(os.environ.get("AF_WORKER_TICK", "30"))
MAINT_EVERY = int(os.environ.get("AF_MAINT_EVERY", "600"))
_last_maint = [0.0]


def _ensure_schedules(c):
    c.execute("""CREATE TABLE IF NOT EXISTS schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, kind TEXT, interval_hours REAL,
        enabled INTEGER DEFAULT 1, next_run TEXT, last_run TEXT, last_status TEXT, created_by TEXT)""")


def run_fleet_schedule():
    c = api.db()
    cutoff = (utcnow() - datetime.timedelta(minutes=10)).isoformat(timespec="seconds")
    ids = [r["id"] for r in c.execute("SELECT id FROM agents WHERE status='online' AND disabled=0 AND last_seen>=?", (cutoff,))]
    n = 0
    for aid in ids:
        busy = c.execute("SELECT 1 FROM agent_commands WHERE agent_id=? AND command='run_local_audit' "
                         "AND status IN ('pending','running')", (aid,)).fetchone()
        if not busy:
            api.queue_command(aid, "run_local_audit", {}, actor="scheduler")
            n += 1
    c.close()
    return f"queued run_local_audit on {n}/{len(ids)} online agents"


def tick():
    c = api.db()
    _ensure_schedules(c)
    now = utc_iso()
    for r in c.execute("SELECT * FROM schedules WHERE enabled=1 AND kind='fleet' AND next_run<=?", (now,)).fetchall():
        nxt = (utcnow() + datetime.timedelta(hours=r["interval_hours"])).isoformat(timespec="seconds")
        if c.execute("UPDATE schedules SET next_run=? WHERE id=? AND next_run=?", (nxt, r["id"], r["next_run"])).rowcount != 1:
            continue                                        # another worker claimed it
        c.commit()
        try:
            msg = "ok: " + run_fleet_schedule()
        except Exception as e:
            msg = f"error: {type(e).__name__}: {str(e)[:120]}"
        c.execute("UPDATE schedules SET last_run=?, last_status=? WHERE id=?", (now, msg, r["id"]))
        c.commit()
        api.audit("scheduled_run", "", "", f"{r['name']}: {msg}")
    c.close()
    if time.time() - _last_maint[0] > MAINT_EVERY:
        _last_maint[0] = time.time()
        api.maintenance()


def main():
    print("[+] worker started (fleet schedules + maintenance)")
    while True:
        try:
            tick()
        except Exception as e:
            print(f"[!] worker error: {e}", file=sys.stderr)
        time.sleep(TICK)


if __name__ == "__main__":
    main()
