"""Single source of truth for the AuditForensics release version (UI, manager API, agent, exports)."""
__version__ = "10.5.0"
APP_VERSION = "10.5"            # short form shown in the UI
API_VERSION = __version__
AGENT_VERSION = __version__
