#!/usr/bin/env python3
"""Threat modeling + hunt / detect / triage guidance for AuditForensics findings.

Produces a **separate** result stream from the audit PASS/FAIL rows:
  - Threat model cards (actor, asset, attack path, impact, likelihood, MITRE)
  - Hunt & detect guidance (telemetry, queries, what “good” vs “bad” looks like)
  - Triage playbooks (priority, first questions, contain / eradicate / recover hints)

Read-only analysis of existing scan findings — no new network probes.
"""
from __future__ import annotations

import hashlib
import re
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Knowledge base: pattern → threat model + hunt + triage
# Keys matched against Category|Check|Details (case-insensitive).
# ---------------------------------------------------------------------------
_PLAYBOOKS: List[dict] = [
    {
        "id": "exposed_admin",
        "match": r"path .*/(admin|administrator|wp-admin|phpmyadmin|manager|console|cpanel|jenkins)",
        "title": "Exposed management / admin interface",
        "actors": ["External opportunistic attacker", "Targeted intruder"],
        "assets": ["Web application", "Admin credentials", "Underlying host"],
        "attack_path": "Discover admin URL → credential stuffing / default creds → privileged actions or webshell",
        "impact": "Full application or host compromise; data theft; ransomware staging",
        "likelihood": "High when internet-facing and weakly authenticated",
        "mitre": ["T1190", "T1110", "T1133"],
        "detect": [
            "Alert on successful auth to admin paths from new geos / ASNs",
            "Spike in 401/403 then 200 on /admin*, /wp-login.php, /manager/*",
            "New admin user creation or role elevation events in app logs",
        ],
        "hunt": [
            "Search web logs for admin path hits excluding known jump-host IPs",
            "Correlate admin logins with impossible travel or residential proxy ASNs",
            "Review WAF blocks for forced browsing toward management URLs",
        ],
        "triage": [
            "Confirm whether the path is intentionally public; if not, block at edge immediately",
            "Check for successful logins in the last 7–30 days from unexpected sources",
            "Rotate admin credentials and enable MFA before re-exposing (prefer VPN/SSO)",
        ],
        "priority": "P1",
    },
    {
        "id": "secrets_exposure",
        "match": r"path .*/(\.env|wp-config|config\.(php|json|ya?ml)|\.git/|\.aws/|\.ssh/|backup\.(sql|zip)|dump\.sql)",
        "title": "Secrets or source exposure on web root",
        "actors": ["Internet scanner", "Competitor / researcher", "Insider via shared link"],
        "assets": ["API keys", "DB credentials", "Source code", "Cloud tokens"],
        "attack_path": "Fetch exposed file → extract secrets → access DB/cloud/SCM as the application",
        "impact": "Credential compromise, data breach, lateral movement into cloud",
        "likelihood": "Critical when file returns 200 with real content",
        "mitre": ["T1552.001", "T1528", "T1213"],
        "detect": [
            "WAF/app log: GET to /.env, /.git/, *config*.bak, *.sql with 200",
            "Cloud trail: API calls using keys that only the app should hold, from unexpected IPs",
            "DB logins from web tier using credentials that appear in public pastes",
        ],
        "hunt": [
            "Historical web logs for sensitive path probes (even 403s show scanning interest)",
            "Secret scanning in git history and public buckets related to this domain",
            "Compare app config secrets against breach corpuses / internal canaries",
        ],
        "triage": [
            "Treat as confirmed credential exposure until proven otherwise — rotate all secrets in the file",
            "Remove files from web root; block path patterns at reverse proxy",
            "Review access logs for prior successful downloads of the same object",
        ],
        "priority": "P0",
    },
    {
        "id": "subdomain_takeover",
        "match": r"possible subdomain takeover|dangling cname",
        "title": "Dangling DNS / subdomain takeover risk",
        "actors": ["Opportunistic takeover bots", "Phishers / brand abusers"],
        "assets": ["Domain reputation", "Cookie scope / SSO trust", "Users who trust the hostname"],
        "attack_path": "Claim abandoned SaaS resource pointed to by CNAME → host attacker content under your domain",
        "impact": "Phishing, session fixation via shared parent domain cookies, brand damage",
        "likelihood": "High for takeover-prone providers when DNS is left dangling",
        "mitre": ["T1584.002", "T1204"],
        "detect": [
            "DNS monitoring: CNAME targets that stop resolving or change ownership",
            "Certificate transparency: unexpected certs issued for the subdomain",
            "Brand monitoring / sinkhole hits for the hostname",
        ],
        "hunt": [
            "Enumerate all CNAMEs to known takeover-prone suffixes (GitHub Pages, Azure, Heroku, etc.)",
            "Confirm each still maps to an active resource you control",
            "Check CT logs for certificates you did not request",
        ],
        "triage": [
            "Remove or update the DNS record immediately if the resource is unused",
            "If claimed by a third party, escalate to provider abuse + legal as needed",
            "Review whether cookies are scoped to parent domain (risk amplification)",
        ],
        "priority": "P1",
    },
    {
        "id": "tls_weak",
        "match": r"tls (protocol|cipher|certificate)|hsts|https enforcement",
        "title": "Weak or missing transport security",
        "actors": ["On-path attacker (wifi, ISP, compromised middlebox)", "Downgrade tooling"],
        "assets": ["Session tokens", "Credentials in transit", "PII"],
        "attack_path": "Force or exploit weak TLS / cleartext → intercept or modify traffic",
        "impact": "Credential theft, session hijack, content injection",
        "likelihood": "Medium on modern internet; higher on legacy clients or misconfigured edges",
        "mitre": ["T1557", "T1040"],
        "detect": [
            "TLS inventory: clients still negotiating TLS 1.0/1.1 or weak ciphers",
            "Certificate expiry monitoring (alerting < 14 days)",
            "Mixed content / HTTP deep links in application telemetry",
        ],
        "hunt": [
            "Edge logs for SSL protocol/cipher distribution by virtual host",
            "Find HTTP→HTTPS redirect failures and HSTS gaps on related hosts",
            "CT log anomalies (unexpected issuers for your domains)",
        ],
        "triage": [
            "Expired cert: emergency reissue and deploy; investigate why automation failed",
            "Weak protocol: disable at load balancer; test critical clients",
            "Missing HSTS: enable with staged max-age after HTTPS is solid everywhere",
        ],
        "priority": "P1",
    },
    {
        "id": "cors_misconfig",
        "match": r"cors misconfiguration",
        "title": "CORS misconfiguration",
        "actors": ["Malicious website operator", "XSS-chaining attacker"],
        "assets": ["Authenticated API responses", "User data readable cross-origin"],
        "attack_path": "Victim visits attacker page → browser sends cookies → attacker reads API response via ACAO reflection",
        "impact": "Account data theft, CSRF-like data exfil while user is logged in",
        "likelihood": "High when ACAO reflects arbitrary Origin with credentials",
        "mitre": ["T1204.001", "T1539"],
        "detect": [
            "WAF/app: responses with Access-Control-Allow-Origin reflecting untrusted origins",
            "Browser-side RUM: cross-origin API calls to your API from unexpected sites",
        ],
        "hunt": [
            "Log Origin header on API routes that return ACAO; flag non-allowlisted values",
            "Review CORS middleware config for * + Allow-Credentials combinations",
        ],
        "triage": [
            "Hotfix: restrict ACAO to explicit allowlist; never reflect raw Origin with credentials",
            "Identify sensitive endpoints that were callable cross-origin during the window",
            "Consider cookie SameSite=Strict/Lax as compensating control",
        ],
        "priority": "P1",
    },
    {
        "id": "graphql_introspection",
        "match": r"graphql introspection",
        "title": "GraphQL introspection enabled in production",
        "actors": ["API recon scanners", "Targeted API abusers"],
        "assets": ["Full schema (types, fields, mutations)", "Hidden business logic"],
        "attack_path": "Introspection → map mutations/fields → craft abuse queries (authz bypass, data scraping)",
        "impact": "Accelerated API abuse; exposure of undocumented operations",
        "likelihood": "High once discovered; common default in many frameworks",
        "mitre": ["T1590", "T1190"],
        "detect": [
            "GraphQL queries containing __schema / __type from non-allowlisted clients",
            "Unusual query complexity / depth scores",
        ],
        "hunt": [
            "Search access logs for introspection query shapes",
            "Inventory all GraphQL endpoints (including versioned paths)",
        ],
        "triage": [
            "Disable introspection in production or bind to admin auth",
            "Enable query allowlisting / cost limiting where supported",
            "Review schema for mutations that lack authorization checks",
        ],
        "priority": "P2",
    },
    {
        "id": "dir_listing",
        "match": r"directory listing",
        "title": "Directory listing enabled",
        "actors": ["Recon scanners", "Curious authenticated users"],
        "assets": ["Backup files", "Internal docs", "Upload directories"],
        "attack_path": "Browse indexes → download sensitive artifacts → use contents for further attacks",
        "impact": "Information disclosure leading to targeted follow-on attacks",
        "likelihood": "Medium; often left on by default on misconfigured static hosts",
        "mitre": ["T1083", "T1552"],
        "detect": [
            "Responses with body signatures 'Index of /' on non-documentation hosts",
            "Bulk sequential GETs under /uploads/, /backup/, /files/",
        ],
        "hunt": [
            "Crawl known static roots for index pages",
            "Compare listed filenames against secret/backup naming patterns",
        ],
        "triage": [
            "Disable autoindex at web server; return 403 for directory URLs",
            "Remove any backup or sensitive files discovered in listings",
            "Check whether listed objects were downloaded recently",
        ],
        "priority": "P2",
    },
    {
        "id": "stack_disclosure",
        "match": r"verbose error|stack trace|traceback|whitelabel error",
        "title": "Verbose error / stack trace disclosure",
        "actors": ["Scanners probing for injection points", "Targeted attackers mapping the stack"],
        "assets": ["Framework/version intel", "File paths", "Internal hostnames"],
        "attack_path": "Trigger errors → read stack/framework versions → select known exploits",
        "impact": "Faster weaponization of application flaws",
        "likelihood": "Medium when debug mode left on in production",
        "mitre": ["T1592", "T1190"],
        "detect": [
            "HTTP 500 responses containing Traceback / at java. / Whitelabel Error Page",
            "Sudden increase in 5xx correlated with fuzzing user-agents",
        ],
        "hunt": [
            "Sample 5xx response bodies in a staging-safe way; classify disclosure",
            "Find debug flags (APP_DEBUG, spring.profiles=dev) in deployment config",
        ],
        "triage": [
            "Turn off debug/detailed errors in production; log server-side only",
            "Patch frameworks versions revealed by stacks if they are EOL/vulnerable",
            "No need for user notification unless paths reveal sensitive data to third parties",
        ],
        "priority": "P2",
    },
    {
        "id": "missing_headers",
        "match": r"http security headers|missing core:",
        "title": "Missing core browser security headers",
        "actors": ["XSS / clickjacking abusers", "Session theft via mixed content"],
        "assets": ["User sessions", "UI integrity"],
        "attack_path": "Missing CSP/XFO/HSTS lowers cost of XSS, clickjacking, or SSL stripping follow-on",
        "impact": "Enables or amplifies client-side attacks",
        "likelihood": "Common; severity depends on app sensitivity",
        "mitre": ["T1189", "T1059.007"],
        "detect": [
            "Synthetic monitors asserting CSP, HSTS, X-Content-Type-Options, X-Frame-Options",
            "CSP report-uri / report-to endpoints for violation spikes",
        ],
        "hunt": [
            "Inventory response headers across main templates and API error pages",
            "Identify pages that frame your site (clickjacking candidates)",
        ],
        "triage": [
            "Add baseline headers at the edge (CDN/reverse proxy) for consistent coverage",
            "Roll out CSP in report-only first, then enforce",
            "Treat as hardening unless chained with active XSS evidence",
        ],
        "priority": "P3",
    },
    {
        "id": "cookie_flags",
        "match": r"cookie security",
        "title": "Insecure session cookie flags",
        "actors": ["Network observer", "XSS stealer"],
        "assets": ["Session tokens"],
        "attack_path": "Missing Secure/HttpOnly → token theft via XSS or cleartext network",
        "impact": "Account takeover",
        "likelihood": "High for session cookies without both flags on HTTPS sites",
        "mitre": ["T1539", "T1557"],
        "detect": [
            "Set-Cookie without Secure or HttpOnly on auth cookies",
            "Session reuse from multiple user-agents in short windows",
        ],
        "hunt": [
            "Catalog all Set-Cookie names used for auth; verify flags",
            "Check SameSite attribute presence (Lax/Strict)",
        ],
        "triage": [
            "Set Secure; HttpOnly; SameSite=Lax or Strict on session cookies",
            "Invalidate existing sessions after flag changes if tokens may have leaked",
            "Confirm cookies are not also readable by JavaScript intentionally",
        ],
        "priority": "P1",
    },
    {
        "id": "cloud_metadata",
        "match": r"metadata path exposed|imds",
        "title": "Cloud metadata-style path reachable on target",
        "actors": ["SSRF-capable attacker", "Compromised app component"],
        "assets": ["Instance credentials", "Cloud IAM role tokens"],
        "attack_path": "SSRF or open proxy → metadata path → steal cloud credentials → cloud account takeover",
        "impact": "Full cloud project/account compromise",
        "likelihood": "Critical if true metadata content is returned",
        "mitre": ["T1552.005", "T1078.004"],
        "detect": [
            "Egress/proxy logs to 169.254.169.254 or metadata hostnames",
            "Unusual use of instance role credentials outside the instance",
        ],
        "hunt": [
            "Confirm response body is real metadata vs soft-404",
            "Trace which code paths or proxies could reach IMDS",
            "CloudTrail/activity for role sessions originating from this instance",
        ],
        "triage": [
            "Block metadata paths at reverse proxy; enforce IMDSv2 / hop limit",
            "Rotate instance role credentials if exposure window is non-zero",
            "Escalate to cloud security immediately for confirmed token exposure",
        ],
        "priority": "P0",
    },
    {
        "id": "open_risky_port",
        "match": r"port (22|23|445|3389|5900|6379|9200|27017|2375|5432|3306).*open|risky",
        "title": "Internet-reachable high-risk service port",
        "actors": ["Botnet scanners", "Ransomware affiliates", "Cryptominers"],
        "assets": ["Host OS", "Databases", "Containers"],
        "attack_path": "Scan → exploit weak auth / known CVE on service → host compromise",
        "impact": "Host takeover, data theft, ransomware",
        "likelihood": "High for RDP/SMB/DB/Docker API on public IPs",
        "mitre": ["T1046", "T1210", "T1133"],
        "detect": [
            "IDS/IPS signatures for service-specific exploits",
            "Auth failures then success from rare sources on that port",
            "New processes / persistence shortly after inbound sessions",
        ],
        "hunt": [
            "Confirm exposure with external port scan from a trusted vantage point",
            "Review auth logs for the service over 30 days",
            "Map which security group / firewall rule allows 0.0.0.0/0",
        ],
        "triage": [
            "Close public access; require VPN or IP allowlist",
            "If must remain open: MFA, rate limits, up-to-date patches",
            "Assume credential testing occurred; rotate passwords/keys",
        ],
        "priority": "P0",
    },
    {
        "id": "kerberoast",
        "match": r"kerberoastable|as-rep roastable|unconstrained delegation",
        "title": "Active Directory credential attack surface",
        "actors": ["Domain-joined attacker", "Ransomware operator with foothold"],
        "assets": ["Service accounts", "Domain credentials", "Tier-0 assets"],
        "attack_path": "Request TGS/AS-REP for weak accounts → offline crack → lateral movement / DA",
        "impact": "Domain dominance",
        "likelihood": "High in many AD estates with legacy SPNs and unconstrained delegation",
        "mitre": ["T1558.003", "T1558.004", "T1134.001"],
        "detect": [
            "Windows Security 4769 anomalous RC4/weak encryption requests",
            "Unusual TGS requests for high-privilege service accounts",
            "BloodHound edges involving unconstrained delegation",
        ],
        "hunt": [
            "Enumerate SPNs with weak encryption; prioritize admin-equivalent accounts",
            "Find computers with unconstrained delegation still enabled",
            "Correlate with recent privilege group membership changes",
        ],
        "triage": [
            "Move service accounts to Group Managed Service Accounts where possible",
            "Enforce AES; disable RC4; long random passwords on remaining SPN accounts",
            "Remove unconstrained delegation; use resource-based constrained delegation",
        ],
        "priority": "P0",
    },
    {
        "id": "generic_fail",
        "match": r".*",  # fallback — last resort
        "title": "Security finding requiring review",
        "actors": ["Varies by finding"],
        "assets": ["In-scope system under assessment"],
        "attack_path": "Finding indicates a weakness that may be chained with others",
        "impact": "Depends on asset criticality and exposure",
        "likelihood": "Assess in context of exposure and compensating controls",
        "mitre": [],
        "detect": [
            "Ensure relevant logs for this control area are collected and retained",
            "Add a detection hypothesis tied to the specific check name",
        ],
        "hunt": [
            "Validate the finding is not a false positive",
            "Search historical telemetry for related suspicious activity",
        ],
        "triage": [
            "Confirm ownership of the affected asset",
            "Rate true severity using business impact, not only tool risk label",
            "Track remediation or formal risk acceptance with expiry",
        ],
        "priority": "P3",
    },
]


def _text_blob(r: dict) -> str:
    return " ".join(
        str(r.get(k, "")) for k in ("Category", "Check", "Details", "Recommendation", "Status", "Risk")
    ).lower()


def _match_playbook(r: dict) -> dict:
    blob = _text_blob(r)
    # Prefer specific playbooks; generic is last in list
    for pb in _PLAYBOOKS:
        if pb["id"] == "generic_fail":
            continue
        if re.search(pb["match"], blob, re.I):
            return pb
    return _PLAYBOOKS[-1]


def _open_findings(results: List[dict]) -> List[dict]:
    """Only model actionable audit issues (not INFO/PASS noise)."""
    out = []
    for r in results or []:
        st = (r.get("Status") or "").upper()
        risk = (r.get("Risk") or "Info")
        if st in ("FAIL", "WARNING", "ERROR") and risk in ("Critical", "High", "Medium", "Low"):
            out.append(r)
        elif st == "FAIL":
            out.append(r)
    return out


def _fingerprint(r: dict, pb_id: str) -> str:
    raw = f"{pb_id}|{r.get('Check')}|{r.get('Host')}|{r.get('Details', '')[:120]}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def build_threat_model(results: List[dict]) -> List[dict]:
    """Return threat-model rows (separate schema from audit findings).

    Each row:
      Stream, FindingRef, Host, Title, Priority, Actors, Assets, AttackPath,
      Impact, Likelihood, MITRE, Detect, Hunt, Triage, SourceRisk, SourceCheck
    """
    cards = []
    seen = set()
    for r in _open_findings(results):
        pb = _match_playbook(r)
        fp = _fingerprint(r, pb["id"])
        if fp in seen:
            continue
        seen.add(fp)
        mitre = list(pb.get("mitre") or [])
        extra = (r.get("MITRE") or "").strip()
        if extra and extra not in mitre:
            mitre.insert(0, extra)
        cards.append({
            "Stream": "ThreatModel",
            "FindingRef": fp,
            "Host": r.get("Host") or "",
            "Title": pb["title"],
            "Priority": pb.get("priority") or "P3",
            "Actors": "; ".join(pb.get("actors") or []),
            "Assets": "; ".join(pb.get("assets") or []),
            "AttackPath": pb.get("attack_path") or "",
            "Impact": pb.get("impact") or "",
            "Likelihood": pb.get("likelihood") or "",
            "MITRE": ", ".join(mitre),
            "Detect": " | ".join(pb.get("detect") or []),
            "Hunt": " | ".join(pb.get("hunt") or []),
            "Triage": " | ".join(pb.get("triage") or []),
            "SourceRisk": r.get("Risk") or "",
            "SourceCheck": r.get("Check") or "",
            "SourceDetails": str(r.get("Details") or "")[:300],
            "PlaybookId": pb["id"],
        })
    # Priority sort P0 → P3
    order = {"P0": 0, "P1": 1, "P2": 2, "P3": 3}
    cards.sort(key=lambda c: (order.get(c["Priority"], 9), c["Title"], c["Host"]))
    return cards


def build_hunt_triage_rows(threat_cards: List[dict]) -> List[dict]:
    """Expand threat cards into hunt/detect/triage action rows (still separate stream)."""
    rows = []
    for c in threat_cards:
        base = {
            "Stream": "HuntTriage",
            "FindingRef": c["FindingRef"],
            "Host": c["Host"],
            "Title": c["Title"],
            "Priority": c["Priority"],
            "MITRE": c["MITRE"],
            "SourceCheck": c["SourceCheck"],
        }
        for kind, key in (("Detect", "Detect"), ("Hunt", "Hunt"), ("Triage", "Triage")):
            blob = c.get(key) or ""
            steps = [s.strip() for s in blob.split("|") if s.strip()]
            for i, step in enumerate(steps, 1):
                rows.append({
                    **base,
                    "ActionType": kind,
                    "Step": i,
                    "Guidance": step,
                })
    return rows


def summarise_threat_model(cards: List[dict]) -> str:
    if not cards:
        return "No open audit issues qualified for threat modeling."
    by_p = defaultdict(int)
    for c in cards:
        by_p[c["Priority"]] += 1
    parts = [f"{by_p[p]} {p}" for p in ("P0", "P1", "P2", "P3") if by_p.get(p)]
    return f"{len(cards)} threat-model card(s): " + ", ".join(parts)


def threat_model_markdown(cards: List[dict], hunt_rows: Optional[List[dict]] = None) -> str:
    """Human-readable report for download / sharing."""
    lines = [
        "# Threat Model & Hunt / Detect / Triage",
        "",
        f"_Generated from open audit findings. {summarise_threat_model(cards)}_",
        "",
    ]
    if not cards:
        lines.append("No cards.")
        return "\n".join(lines)

    for c in cards:
        lines += [
            f"## [{c['Priority']}] {c['Title']}",
            f"- **Host:** `{c['Host'] or 'n/a'}`",
            f"- **Source check:** {c['SourceCheck']} ({c['SourceRisk']})",
            f"- **Actors:** {c['Actors']}",
            f"- **Assets:** {c['Assets']}",
            f"- **Attack path:** {c['AttackPath']}",
            f"- **Impact:** {c['Impact']}",
            f"- **Likelihood:** {c['Likelihood']}",
            f"- **MITRE:** {c['MITRE'] or '—'}",
            "",
            "### Detect",
        ]
        for s in (c.get("Detect") or "").split("|"):
            if s.strip():
                lines.append(f"- {s.strip()}")
        lines += ["", "### Hunt"]
        for s in (c.get("Hunt") or "").split("|"):
            if s.strip():
                lines.append(f"- {s.strip()}")
        lines += ["", "### Triage"]
        for s in (c.get("Triage") or "").split("|"):
            if s.strip():
                lines.append(f"- {s.strip()}")
        lines += ["", "---", ""]

    return "\n".join(lines)


def run_threat_analysis(results: List[dict]) -> dict:
    """Main entry: audit results → separate threat + hunt streams + markdown."""
    cards = build_threat_model(results)
    hunts = build_hunt_triage_rows(cards)
    return {
        "threat_model": cards,
        "hunt_triage": hunts,
        "summary": summarise_threat_model(cards),
        "markdown": threat_model_markdown(cards, hunts),
    }
