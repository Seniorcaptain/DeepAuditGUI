#!/usr/bin/env python3
"""AuditForensics network engine: host discovery, port scanning and service detection.

Stdlib + psutil/cryptography (+ optional scapy for authoritative ARP sweeps). Works unprivileged; extra privileges
only improve results (ARP sweep, nmap OS detection). Everything outbound goes through the scope/rate guard that the
caller sets up (af_scope.evaluate before, throttle values in ``ScanConfig``) - this module never decides *what* may be
scanned, only *how*.

Design notes
  * "Alive" is decided by several independent signals: ICMP echo, a TCP connect that succeeds OR is actively refused
    (an RST proves a host is there even when ICMP is filtered), ARP/neighbour entry, and broadcast responders
    (SSDP, mDNS) - so hosts that ignore ping are still found.
  * Port states are open / closed / filtered. UDP replies prove "open"; ICMP unreachable proves "closed"; silence is
    "open|filtered" and is reported as such, never as open.
  * A failed probe is reported as a failure, not as "nothing found".
"""
import asyncio, ipaddress, os, platform, re, socket, ssl, struct, subprocess, time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone

import af_oui

try:
    import psutil
except ImportError:                                   # pragma: no cover
    psutil = None


class Cancelled(Exception):
    pass


# ---------------------------------------------------------------- port lists / profiles
PORT_NAMES = {
    7: "echo", 20: "ftp-data", 21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 37: "time", 43: "whois", 53: "dns", 67: "dhcp", 68: "dhcp-client",
    69: "tftp", 79: "finger", 80: "http", 88: "kerberos", 102: "s7comm", 110: "pop3", 111: "rpcbind", 119: "nntp", 123: "ntp", 135: "msrpc",
    137: "netbios-ns", 138: "netbios-dgm", 139: "netbios-ssn", 143: "imap", 161: "snmp", 162: "snmp-trap", 179: "bgp", 389: "ldap", 443: "https",
    445: "smb", 464: "kpasswd", 465: "smtps", 500: "isakmp", 502: "modbus", 514: "syslog", 515: "lpd", 520: "rip", 523: "ibm-db2", 548: "afp",
    554: "rtsp", 587: "submission", 593: "http-rpc", 623: "ipmi", 631: "ipp", 636: "ldaps", 666: "doom", 873: "rsync", 902: "vmware-auth",
    990: "ftps", 993: "imaps", 995: "pop3s", 1080: "socks", 1194: "openvpn", 1433: "mssql", 1434: "mssql-browser", 1521: "oracle",
    1604: "citrix-ica", 1701: "l2tp", 1723: "pptp", 1812: "radius", 1883: "mqtt", 1900: "upnp", 2049: "nfs", 2181: "zookeeper", 2375: "docker",
    2376: "docker-tls", 2379: "etcd", 2380: "etcd-peer", 3000: "http-dev", 3128: "squid", 3260: "iscsi", 3306: "mysql", 3389: "rdp", 3478: "stun",
    4369: "epmd", 4443: "https-alt", 4500: "ipsec-nat-t", 4505: "salt", 4506: "salt", 4840: "opc-ua", 5000: "http-alt", 5001: "http-alt",
    5060: "sip", 5061: "sips", 5222: "xmpp", 5353: "mdns", 5432: "postgresql", 5555: "adb", 5601: "kibana", 5672: "amqp", 5683: "coap",
    5900: "vnc", 5901: "vnc", 5985: "winrm", 5986: "winrm-tls", 6000: "x11", 6379: "redis", 6443: "kubernetes-api", 6667: "irc", 7001: "weblogic",
    7077: "spark", 8000: "http-alt", 8008: "http-alt", 8009: "ajp", 8080: "http-proxy", 8081: "http-alt", 8086: "influxdb", 8088: "http-alt",
    8123: "home-assistant", 8200: "http-alt", 8443: "https-alt", 8500: "consul", 8530: "wsus", 8531: "wsus-tls", 8883: "mqtts", 8888: "http-alt",
    9000: "http-alt", 9042: "cassandra", 9090: "http-alt", 9092: "kafka", 9100: "jetdirect", 9200: "elasticsearch", 9300: "elasticsearch-node",
    9418: "git", 9999: "abyss", 10000: "webmin", 10250: "kubelet", 11211: "memcached", 15672: "rabbitmq-mgmt", 27017: "mongodb", 27018: "mongodb",
    32400: "plex", 44818: "ethernet-ip", 47808: "bacnet", 50000: "db2",
}
COMMON_TCP = sorted(set(PORT_NAMES) - {68, 137, 138, 162, 500, 520, 1434, 1900, 3478, 4500, 5353, 5683, 47808, 623, 123, 161, 67, 69} | {8089, 8090, 9443, 7443, 8181, 2222})
STANDARD_TCP = sorted(set(range(1, 1025)) | set(PORT_NAMES))
FULL_TCP = list(range(1, 65536))
# UDP: port -> probe key (see udp_payload)
UDP_PORTS = {53: "dns", 67: "empty", 69: "tftp", 123: "ntp", 137: "nbns", 161: "snmp", 500: "empty", 514: "empty", 1900: "ssdp", 5353: "mdns",
             4500: "empty", 623: "empty", 1194: "empty", 11211: "memcached", 5060: "sip", 1701: "empty", 88: "empty", 520: "empty", 5683: "empty"}
TLS_PORTS = {443, 465, 563, 636, 853, 989, 990, 992, 993, 995, 1443, 2376, 3269, 4443, 5061, 5986, 6443, 7443, 8443, 8531, 8883, 9443, 10250}
HTTP_PORTS = {80, 81, 3000, 5000, 5001, 5601, 8000, 8008, 8080, 8081, 8086, 8088, 8089, 8090, 8123, 8181, 8200, 8888, 9000, 9090, 9200, 10000, 15672,
              32400, 2375, 7001, 8500, 5985}
PROBE_PORTS = [80, 443, 22, 445, 135, 139, 3389, 8080, 53, 21, 25, 23, 5900, 8443, 3306, 5432, 1433, 111, 548, 62078, 9100, 631, 554, 1883]


@dataclass
class ScanConfig:
    profile: str = "standard"            # discovery | quick | standard | full
    udp: bool = False
    intensity: str = "standard"          # discovery (no extra probes) | standard | deep (adds safe misconfiguration probes)
    timeout: float = 1.0
    concurrency: int = 400
    rate_per_host: float = 0.0           # connection attempts per second per host (0 = unlimited)
    rate_total: float = 0.0
    host_concurrency: int = 4            # hosts port-scanned in parallel
    icmp: bool = True
    tcp_probe: bool = True
    arp: bool = True
    broadcast: bool = True               # SSDP + mDNS listeners
    netbios: bool = True
    reverse_dns: bool = True
    traceroute: bool = False
    use_nmap: bool = False
    ports: list = field(default_factory=list)       # explicit override
    max_fds: int = 0
    max_hosts: int = 0                   # 0 = scope policy limit (an administrator may raise it per scan)

    def tcp_ports(self):
        if self.ports:
            return sorted(set(self.ports))
        return {"discovery": [], "quick": COMMON_TCP, "standard": STANDARD_TCP, "full": FULL_TCP}.get(self.profile, STANDARD_TCP)


PROFILES = {
    "Discovery only": ScanConfig(profile="discovery"),
    "Quick (well-known service ports)": ScanConfig(profile="quick", timeout=0.8),
    "Standard (ports 1-1024 + service ports)": ScanConfig(profile="standard", udp=True),
    "Full (all 65,535 TCP + common UDP)": ScanConfig(profile="full", udp=True, timeout=1.0, concurrency=800),
}


def raise_nofile(want=8192):
    """Raise RLIMIT_NOFILE (many parallel connects need many descriptors). Returns the limit in force."""
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        target = want if hard == resource.RLIM_INFINITY else min(want, hard)
        if soft < target:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
            soft = target
        return soft
    except Exception:
        return 1024


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------- host / interface information
def local_networks():
    """Directly attached IPv4 networks of this machine: [{iface, ip, cidr, mac, loopback}] (link-local excluded)."""
    out = []
    if psutil:
        try:
            addrs, stats = psutil.net_if_addrs(), psutil.net_if_stats()
            for ifn, lst in addrs.items():
                if ifn in stats and not stats[ifn].isup:
                    continue
                mac = next((a.address for a in lst if getattr(a.family, "name", "") in ("AF_LINK", "AF_PACKET")), "")
                for a in lst:
                    if a.family == socket.AF_INET and a.netmask:
                        ip = ipaddress.ip_address(a.address)
                        if ip.is_link_local:
                            continue
                        net = ipaddress.ip_network(f"{a.address}/{a.netmask}", strict=False)
                        out.append({"iface": ifn, "ip": a.address, "cidr": str(net), "mac": mac, "loopback": ip.is_loopback})
        except Exception:
            pass
    if not out:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("192.0.2.1", 9))                  # no packet is sent; selects the outbound interface
            ip = s.getsockname()[0]
            s.close()
            out.append({"iface": "?", "ip": ip, "cidr": str(ipaddress.ip_network(f"{ip}/24", strict=False)), "mac": "", "loopback": False})
        except OSError:
            pass
    return out


def parse_proc_route(text):
    """/proc/net/route -> [(iface, gateway_ip)] for default routes."""
    gws = []
    for ln in text.splitlines()[1:]:
        f = ln.split()
        if len(f) >= 3 and f[1] == "00000000" and int(f[3], 16) & 2:
            gws.append((f[0], socket.inet_ntoa(struct.pack("<L", int(f[2], 16)))))
    return gws


def parse_netstat_default(text):
    """`netstat -rn` / `route -n get default` (macOS/BSD/Windows) -> [gateway_ip]."""
    gws = []
    for ln in text.splitlines():
        m = re.match(r"^\s*(?:default|0\.0\.0\.0)\s+(?:0\.0\.0\.0\s+)?(\d+\.\d+\.\d+\.\d+)", ln)
        if m:
            gws.append(m.group(1))
        m = re.match(r"^\s*gateway:\s*(\d+\.\d+\.\d+\.\d+)", ln)
        if m:
            gws.append(m.group(1))
    return gws


def default_gateways(run=None):
    run = run or (lambda cmd: subprocess.run(cmd, capture_output=True, text=True, timeout=10).stdout)
    try:
        if platform.system() == "Linux" and os.path.exists("/proc/net/route"):
            return [g for _, g in parse_proc_route(open("/proc/net/route").read())]
        if platform.system() == "Darwin":
            return parse_netstat_default(run(["route", "-n", "get", "default"]))
        return parse_netstat_default(run(["netstat", "-rn"]))
    except Exception:
        return []


def parse_proc_arp(text):
    """/proc/net/arp -> {ip: mac} (complete entries only)."""
    out = {}
    for ln in text.splitlines()[1:]:
        f = ln.split()
        if len(f) >= 4 and f[2] != "0x0" and f[3] != "00:00:00:00:00:00":
            out[f[0]] = f[3].lower()
    return out


def parse_arp_an(text):
    """`arp -an` (Linux/macOS: '? (10.0.0.1) at aa:bb:.. on en0') and `arp -a` (Windows: '10.0.0.1  aa-bb-..  dynamic')."""
    out = {}
    for ln in text.splitlines():
        m = re.search(r"\((\d+\.\d+\.\d+\.\d+)\) at ([0-9a-fA-F:]{11,17})", ln) or re.match(r"^\s*(\d+\.\d+\.\d+\.\d+)\s+([0-9a-fA-F\-]{17})\s+\w+", ln)
        if m:
            mac = m.group(2).lower().replace("-", ":")
            if mac not in ("ff:ff:ff:ff:ff:ff",) and "incomplete" not in ln:
                out[m.group(1)] = ":".join(p.zfill(2) for p in mac.split(":"))
    return out


def read_arp_table(run=None):
    run = run or (lambda cmd: subprocess.run(cmd, capture_output=True, text=True, timeout=10).stdout)
    try:
        if os.path.exists("/proc/net/arp"):
            return parse_proc_arp(open("/proc/net/arp").read())
        return parse_arp_an(run(["arp", "-an"] if platform.system() != "Windows" else ["arp", "-a"]))
    except Exception:
        return {}


# ---------------------------------------------------------------- ICMP / TCP liveness
_HOST_OK = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.\-:]{0,251}[A-Za-z0-9])?$")


def parse_ping(out):
    """-> (alive, ttl|None, rtt_ms|None) from Linux/macOS/Windows ping output."""
    ttl = re.search(r"ttl[=:](\d+)", out, re.I)
    rtt = re.search(r"time[=<]([\d.]+)\s*ms", out, re.I)
    alive = bool(ttl) or bool(re.search(r"1 (packets )?received|Received = 1|bytes from", out, re.I)) and "unreachable" not in out.lower()
    return alive, int(ttl.group(1)) if ttl else None, float(rtt.group(1)) if rtt else None


def icmp_ping(ip, timeout=1.0, run=None):
    """ICMP echo through the system ping (no raw socket needed). -> (alive, ttl, rtt)."""
    if not _HOST_OK.match(str(ip)) or str(ip).startswith("-"):
        return False, None, None
    sysname = platform.system()
    cmd = (["ping", "-n", "1", "-w", str(int(timeout * 1000)), ip] if sysname == "Windows"
           else ["ping", "-c", "1", "-W", str(max(1, int(timeout))) if sysname == "Linux" else str(int(timeout * 1000)), ip])
    try:
        out = (run or (lambda c: subprocess.run(c, capture_output=True, text=True, timeout=timeout + 3).stdout))(cmd)
    except (OSError, subprocess.SubprocessError):
        return False, None, None
    return parse_ping(out)


class AsyncRate:
    """Token bucket for asyncio code (rate <= 0 = unlimited)."""

    def __init__(self, rate):
        self.rate, self.tokens, self.t = float(rate), float(max(rate, 1)), time.monotonic()

    async def acquire(self):
        if self.rate <= 0:
            return
        while True:
            now = time.monotonic()
            self.tokens = min(max(self.rate, 1), self.tokens + (now - self.t) * self.rate)
            self.t = now
            if self.tokens >= 1:
                self.tokens -= 1
                return
            await asyncio.sleep((1 - self.tokens) / self.rate)


async def tcp_state(ip, port, timeout):
    """-> 'open' | 'closed' | 'filtered' | 'unreachable'. 'closed' (connection refused) still proves the host is alive."""
    try:
        r, w = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout)
    except asyncio.TimeoutError:
        return "filtered"
    except ConnectionRefusedError:
        return "closed"
    except OSError as e:
        if e.errno in (101, 113, 65, 51, 10051, 10065):          # net/host unreachable (Linux, BSD, Windows)
            return "unreachable"
        if e.errno in (24, 23, 10055):                           # out of descriptors: not a verdict about the port
            await asyncio.sleep(0.05)
            return "error"
        return "filtered"
    try:
        w.close()
        await asyncio.wait_for(w.wait_closed(), 1)
    except Exception:
        pass
    return "open"


async def _probe_host_tcp(ip, groups, timeout, sem):
    """Probe ports in parallel *groups* (first group = most likely ports). A host is alive as soon as any port is open
    or actively refused. Dead addresses cost one timeout per group, not one per port."""
    best = "filtered"
    for ports in groups:
        if not ports:
            continue

        async def one(p):
            async with sem:
                return await tcp_state(ip, p, timeout), p
        for st, p in await asyncio.gather(*(one(p) for p in ports)):
            if st in ("open", "closed"):
                return st, p
            if st == "unreachable":
                best = st
    return best, None


def discover_hosts(ips, cfg, progress=None, cancel=None, run=None):
    """Layered host discovery. -> {ip: device-skeleton dict}. ``run`` injects the ping/arp command runner (tests)."""
    found, lock = {}, __import__("threading").Lock()

    def mark(ip, how, **kw):
        with lock:
            d = found.setdefault(ip, new_device(ip))
            if how not in d["discovered_by"]:
                d["discovered_by"].append(how)
            for k, v in kw.items():
                if v and not d.get(k):
                    d[k] = v

    total = max(len(ips), 1)
    done = [0]

    def tick():
        done[0] += 1
        if progress and done[0] % 8 == 0:
            progress(min(done[0] / (total * (2 if cfg.icmp and cfg.tcp_probe else 1)), 1.0), f"probing {done[0]} of {total}")

    icmp_ok = bool(cfg.icmp and (run is not None or __import__("shutil").which("ping")))
    if icmp_ok:
        def ping(ip):
            if cancel and cancel():
                return
            alive, ttl, rtt = icmp_ping(ip, cfg.timeout, run)
            if alive:
                mark(ip, "icmp", ttl=ttl, rtt_ms=rtt)
            tick()
        with ThreadPoolExecutor(max_workers=min(96, max(4, len(ips)))) as ex:
            list(ex.map(ping, ips))

    if cfg.tcp_probe:
        # hosts ICMP already found need no TCP probe; big ranges use only the short list (time grows with addresses x ports)
        todo = [ip for ip in ips if not (icmp_ok and ip in found)]
        groups = [PROBE_PORTS[:5]] + ([PROBE_PORTS[5:]] if len(ips) <= 1024 else [])

        async def run_probes():
            sem = asyncio.Semaphore(min(max(cfg.concurrency, 64), 600))

            async def one(ip):
                if cancel and cancel():
                    return
                st, p = await _probe_host_tcp(ip, groups, min(cfg.timeout, 0.8), sem)
                if st in ("open", "closed"):
                    mark(ip, f"tcp-{st}:{p}")
                tick()
            for i in range(0, len(todo), 2048):
                await asyncio.gather(*(one(ip) for ip in todo[i:i + 2048]))
        asyncio.run(run_probes())

    if cancel and cancel():
        raise Cancelled()
    if cfg.arp:
        wanted = set(ips)
        for ip, mac in read_arp_table(run).items():
            if ip in wanted:
                mark(ip, "arp", mac=mac)
        for ip, mac in scapy_arp_sweep(ips).items():
            mark(ip, "arp-sweep", mac=mac)
    for ip, d in found.items():
        if d.get("mac"):
            d["vendor"], d["mac_note"] = af_oui.describe(d["mac"])
    return found


def scapy_arp_sweep(ips, timeout=2):
    """Authoritative L2 sweep for directly attached networks (needs scapy + root). {} when unavailable."""
    try:
        if not (hasattr(os, "geteuid") and os.geteuid() == 0):
            return {}
        from scapy.all import ARP, Ether, srp
        nets = {str(ipaddress.ip_network(f"{i}/24", strict=False)) for i in ips if ipaddress.ip_address(i).is_private}
        out = {}
        for n in nets:
            ans, _ = srp(Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=n), timeout=timeout, verbose=0)
            out.update({r.psrc: r.hwsrc.lower() for _, r in ans})
        return out
    except Exception:
        return {}


def new_device(ip):
    return {"ip": ip, "mac": "", "vendor": "", "mac_note": "", "hostnames": [], "names": {}, "ttl": None, "rtt_ms": None, "os": "", "os_conf": 0,
            "os_hints": [], "dtype": "", "dtype_reasons": [], "services": [], "udp": [], "cves": [], "findings": [], "discovered_by": [],
            "public": _is_public(ip), "gateway": False, "hops": None, "criticality": "medium", "first_seen": utc_now(), "notes": [],
            "closed_tcp": 0, "filtered_tcp": 0, "ports_scanned": 0}


def _is_public(ip):
    try:
        return ipaddress.ip_address(ip).is_global
    except ValueError:
        return False


# ---------------------------------------------------------------- DNS / mDNS / SSDP / NetBIOS / SNMP / NTP packets
def dns_query(name, qtype=1, qclass=1, txid=0x1234, rd=True):
    q = b"".join(bytes([len(p)]) + p.encode() for p in name.strip(".").split(".")) + b"\x00"
    return struct.pack(">HHHHHH", txid, 0x0100 if rd else 0, 1, 0, 0, 0) + q + struct.pack(">HH", qtype, qclass)


def _read_name(data, off, depth=0):
    labels = []
    while off < len(data) and depth < 10:
        n = data[off]
        if n == 0:
            return ".".join(labels), off + 1
        if n & 0xC0 == 0xC0:
            ptr = ((n & 0x3F) << 8) | data[off + 1]
            nm, _ = _read_name(data, ptr, depth + 1)
            return ".".join(labels + ([nm] if nm else [])), off + 2
        labels.append(data[off + 1:off + 1 + n].decode("utf-8", "replace"))
        off += 1 + n
    return ".".join(labels), off


def parse_dns(data):
    """Minimal DNS message parser -> {id, rcode, answers:[(name, type, ttl, rdata_text)]} (A, AAAA, PTR, TXT, SRV, CNAME)."""
    if len(data) < 12:
        return None
    tid, flags, qd, an, ns, ar = struct.unpack(">HHHHHH", data[:12])
    off, answers = 12, []
    try:
        for _ in range(qd):
            _, off = _read_name(data, off)
            off += 4
        for _ in range(an + ns + ar):
            name, off = _read_name(data, off)
            t, c, ttl, rl = struct.unpack(">HHIH", data[off:off + 10])
            off += 10
            rd = data[off:off + rl]
            if t == 1 and rl == 4:
                txt = socket.inet_ntoa(rd)
            elif t == 28 and rl == 16:
                txt = socket.inet_ntop(socket.AF_INET6, rd)
            elif t in (5, 12):
                txt = _read_name(data, off)[0]
            elif t == 16:
                parts, i = [], 0
                while i < len(rd):
                    n = rd[i]; parts.append(rd[i + 1:i + 1 + n].decode("utf-8", "replace")); i += 1 + n
                txt = " ".join(parts)
            elif t == 33 and rl >= 6:
                txt = f"{_read_name(data, off + 6)[0]}:{struct.unpack('>H', rd[4:6])[0]}"
            else:
                txt = rd.hex()
            answers.append((name, t, ttl, txt))
            off += rl
    except (struct.error, IndexError):
        pass
    return {"id": tid, "rcode": flags & 0xF, "answers": answers}


MDNS_ADDR, SSDP_ADDR = ("224.0.0.251", 5353), ("239.255.255.250", 1900)
SSDP_MSEARCH = (b"M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n")


def parse_ssdp(data):
    """SSDP response -> {server, location, st, usn} (header values)."""
    h = {}
    for ln in data.decode("utf-8", "replace").splitlines()[1:]:
        k, _, v = ln.partition(":")
        if v:
            h[k.strip().lower()] = v.strip()
    return {"server": h.get("server", ""), "location": h.get("location", ""), "st": h.get("st", ""), "usn": h.get("usn", "")}


def _udp_collect(sock, deadline, handler):
    while time.time() < deadline:
        try:
            data, addr = sock.recvfrom(4096)
        except (socket.timeout, BlockingIOError):
            continue
        except OSError:
            break
        handler(data, addr[0])


def broadcast_discovery(timeout=3.0):
    """Listen for SSDP and mDNS responders on the local segment. -> {ip: {'ssdp': {...}, 'mdns': [names]}}. Never raises."""
    out = {}
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.4)
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        for q in (SSDP_MSEARCH,):
            s.sendto(q, SSDP_ADDR)
        s.sendto(dns_query("_services._dns-sd._udp.local", 12, 1, 0, rd=False), MDNS_ADDR)
        s.sendto(dns_query("_workstation._tcp.local", 12, 1, 0, rd=False), MDNS_ADDR)

        def handler(data, ip):
            if data.startswith(b"HTTP/1.1 200") or data.startswith(b"NOTIFY"):
                out.setdefault(ip, {}).setdefault("ssdp", parse_ssdp(data))
            else:
                msg = parse_dns(data)
                if msg:
                    out.setdefault(ip, {}).setdefault("mdns", []).extend(a[3] for a in msg["answers"] if a[1] in (12, 33, 1, 28))
        _udp_collect(s, time.time() + timeout, handler)
        s.close()
    except OSError:
        pass
    return out


def nbstat_query():
    return struct.pack(">HHHHHH", 0x4142, 0x0000, 1, 0, 0, 0) + b"\x20" + b"CK" + b"A" * 30 + b"\x00" + struct.pack(">HH", 0x21, 1)


def parse_nbstat(data):
    """NetBIOS node status reply -> {'names': [(name, suffix, is_group)], 'mac': 'aa:bb:..'} or None."""
    try:
        qd, an = struct.unpack(">HH", data[4:8])
        off = 12
        for _ in range(qd):                                    # echoed question(s): name + type + class
            _, off = _read_name(data, off)
            off += 4
        if an < 1:
            return None
        _, off = _read_name(data, off)                         # answer name (labels or a compression pointer)
        off += 2 + 2 + 4 + 2                                   # type, class, ttl, rdlength
        n = data[off]
        off += 1
        names = []
        for _ in range(n):
            raw = data[off:off + 18]
            if len(raw) < 18:
                return None
            names.append((raw[:15].decode("ascii", "replace").strip(), raw[15], bool(struct.unpack(">H", raw[16:18])[0] & 0x8000)))
            off += 18
        mac = ":".join(f"{b:02x}" for b in data[off:off + 6])
        return {"names": names, "mac": "" if mac in ("00:00:00:00:00:00", "") else mac}
    except (IndexError, ValueError, struct.error):
        return None


def _ber_len(n):
    return bytes([n]) if n < 128 else bytes([0x81, n]) if n < 256 else bytes([0x82, n >> 8, n & 255])


def _ber(tag, payload):
    return bytes([tag]) + _ber_len(len(payload)) + payload


def _ber_int(n):
    b = n.to_bytes(max(1, (n.bit_length() + 8) // 8), "big", signed=True)
    return _ber(0x02, b)


def _ber_oid(oid):
    p = [int(x) for x in oid.split(".")]
    body = bytes([p[0] * 40 + p[1]]) + b"".join(
        bytes([((v >> s) & 0x7F) | (0x80 if s else 0) for s in range(((v.bit_length() - 1) // 7) * 7, -1, -7)]) if v else b"\x00" for v in p[2:])
    return _ber(0x06, body)


def snmp_get(community="public", oid="1.3.6.1.2.1.1.1.0", reqid=0x41424344, version=1):
    """SNMP GetRequest (v2c by default, version=1) for one OID."""
    vb = _ber(0x30, _ber(0x30, _ber_oid(oid) + b"\x05\x00"))
    pdu = _ber(0xA0, _ber_int(reqid) + _ber_int(0) + _ber_int(0) + vb)
    return _ber(0x30, _ber_int(version) + _ber(0x04, community.encode()) + pdu)


def _ber_read(data, off):
    tag = data[off]; ln = data[off + 1]; off += 2
    if ln & 0x80:
        n = ln & 0x7F; ln = int.from_bytes(data[off:off + n], "big"); off += n
    return tag, data[off:off + ln], off + ln


def parse_snmp_response(data):
    """-> string value of the first varbind (e.g. sysDescr) or None. Tolerant of malformed input."""
    try:
        _, msg, _ = _ber_read(data, 0)
        o = 0
        _, _, o = _ber_read(msg, o)                    # version
        _, _, o = _ber_read(msg, o)                    # community
        tag, pdu, _ = _ber_read(msg, o)
        if tag != 0xA2:
            return None
        o = 0
        for _ in range(3):                             # request-id, error-status, error-index
            _, _, o = _ber_read(pdu, o)
        _, vbl, _ = _ber_read(pdu, o)
        _, vb, _ = _ber_read(vbl, 0)
        o = 0
        _, _, o = _ber_read(vb, o)                     # oid
        t, val, _ = _ber_read(vb, o)
        return val.decode("utf-8", "replace") if t == 0x04 else str(int.from_bytes(val, "big"))
    except (IndexError, ValueError):
        return None


def ntp_request():
    return b"\x1b" + b"\x00" * 47


def udp_payload(kind, ip=""):
    return {"dns": dns_query("version.bind", 16, 3), "ntp": ntp_request(), "nbns": nbstat_query(), "snmp": snmp_get(), "ssdp": SSDP_MSEARCH,
            "mdns": dns_query("_services._dns-sd._udp.local", 12, 1, 0, rd=False), "memcached": b"\x00\x01\x00\x00\x00\x01\x00\x00version\r\n",
            "tftp": b"\x00\x01af-probe-nonexistent\x00octet\x00", "sip": b"OPTIONS sip:probe@" + ip.encode() + b" SIP/2.0\r\n\r\n",
            "empty": b"\x00"}.get(kind, b"\x00")


def udp_probe(ip, port, kind, timeout=1.5):
    """-> (state, reply_bytes). open (reply) / closed (ICMP port unreachable) / open|filtered (silence)."""
    try:
        s = socket.socket(socket.AF_INET6 if ":" in ip else socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        s.connect((ip, port))
        s.send(udp_payload(kind, ip))
        try:
            return "open", s.recv(4096)
        except socket.timeout:
            return "open|filtered", b""
        except ConnectionRefusedError:
            return "closed", b""
        finally:
            s.close()
    except OSError:
        return "error", b""


def scan_udp(ip, cfg, cancel=None):
    """Probe the common UDP ports with protocol-correct payloads and decode what answers."""
    ports = list(UDP_PORTS.items())
    out = []

    def one(item):
        port, kind = item
        if cancel and cancel():
            return None
        st, data = udp_probe(ip, port, kind, max(cfg.timeout, 1.0))
        return port, kind, st, data
    with ThreadPoolExecutor(max_workers=min(len(ports), 16)) as ex:
        for r in ex.map(one, ports):
            if not r or r[2] in ("closed", "error"):
                continue
            port, kind, st, data = r
            svc = {"port": port, "proto": "udp", "state": st, "name": PORT_NAMES.get(port, str(port)), "product": "", "product_key": "", "version": "",
                   "banner": "", "tls": None, "http": None, "notes": [], "os_hints": []}
            if st == "open":
                if kind == "snmp":
                    v = parse_snmp_response(data)
                    if v is not None:
                        svc["banner"] = v[:200]; svc["notes"].append("snmp-public-community")
                elif kind == "dns":
                    m = parse_dns(data)
                    txt = next((a[3] for a in (m or {}).get("answers", []) if a[1] == 16), "")
                    svc["banner"] = txt[:120]
                    ident = identify_banner(53, txt)
                    svc.update({k: v for k, v in ident.items() if k in ("product", "product_key", "version")})
                elif kind == "nbns":
                    nb = parse_nbstat(data)
                    if nb:
                        svc["banner"] = ", ".join(n for n, _, _ in nb["names"])[:200]; svc["netbios"] = nb
                elif kind == "ssdp":
                    svc["banner"] = (parse_ssdp(data).get("server") or "")[:200]
                elif kind == "ntp" and len(data) >= 48:
                    svc["banner"] = f"stratum {data[1]}"
                elif data:
                    svc["banner"] = data[:120].decode("utf-8", "replace")
            out.append(svc)
    return out


# ---------------------------------------------------------------- TCP port scan
async def scan_tcp(ip, ports, timeout=1.0, concurrency=400, rate=0.0, cancel=None, progress=None, early_abort=True):
    """Connect scan. -> {'open': [ports], 'closed': n, 'filtered': n, 'errors': n, 'all_filtered': bool}"""
    sem, limiter = asyncio.Semaphore(max(1, concurrency)), AsyncRate(rate)
    res = {"open": [], "closed": 0, "filtered": 0, "errors": 0, "all_filtered": False, "scanned": 0}

    async def one(p):
        async with sem:
            if cancel and cancel():                           # checked per probe, so Cancel takes effect within one timeout
                return
            await limiter.acquire()
            if cancel and cancel():
                return
            st = await tcp_state(ip, p, timeout)
            if st == "error":
                await asyncio.sleep(0.1)
                st = await tcp_state(ip, p, timeout)
        res["scanned"] += 1
        if st == "open":
            res["open"].append(p)
        elif st == "closed":
            res["closed"] += 1
        elif st == "error":
            res["errors"] += 1
        else:
            res["filtered"] += 1

    CH = 2048
    for i in range(0, len(ports), CH):
        if cancel and cancel():
            raise Cancelled()
        await asyncio.gather(*(one(p) for p in ports[i:i + CH]))
        if cancel and cancel():
            raise Cancelled()
        if progress:
            progress(min((i + CH) / max(len(ports), 1), 1.0))
        if early_abort and i == 0 and len(ports) > 4096 and res["filtered"] >= CH and not res["open"] and not res["closed"]:
            res["all_filtered"] = True                       # every probe silently dropped: a drop-all firewall, stop wasting minutes
            break
    res["open"].sort()
    return res


# ---------------------------------------------------------------- banner identification
SERVICE_RULES = [
    # (regex, name, product_key, product label, os hint)
    (r"^SSH-\d\.\d+-OpenSSH_for_Windows[_ ]?([\w.]+)", "ssh", "openssh", "OpenSSH for Windows", "windows"),
    (r"^SSH-\d\.\d+-OpenSSH_([\w.]+)(?:[ -]+(Ubuntu|Debian|Raspbian|FreeBSD|NetBSD)[\w.+~-]*)?", "ssh", "openssh", "OpenSSH", None),
    (r"^SSH-\d\.\d+-dropbear_([\w.]+)", "ssh", "dropbear", "Dropbear SSH", "embedded-linux"),
    (r"^SSH-\d\.\d+-ROSSSH", "ssh", "", "MikroTik RouterOS SSH", "routeros"),
    (r"^SSH-\d\.\d+-Cisco-([\d.]+)", "ssh", "", "Cisco SSH", "cisco"),
    (r"^SSH-\d\.\d+-libssh[_-]([\w.]+)", "ssh", "", "libssh", None),
    (r"^SSH-\d\.\d+-([\w.\-]+)", "ssh", "", "SSH", None),
    (r"ProFTPD\s+([\d.]+\w*)", "ftp", "proftpd", "ProFTPD", None),
    (r"\(vsFTPd\s+([\d.]+)\)", "ftp", "vsftpd", "vsftpd", None),
    (r"Pure-FTPd", "ftp", "pure-ftpd", "Pure-FTPd", None),
    (r"FileZilla Server(?: version)?\s*([\d.]+)?", "ftp", "", "FileZilla Server", "windows"),
    (r"Microsoft FTP Service", "ftp", "", "Microsoft FTP Service", "windows"),
    (r"ESMTP Postfix(?: \((\w+)\))?", "smtp", "postfix", "Postfix", None),
    (r"ESMTP Exim\s+([\d.]+)", "smtp", "exim", "Exim", None),
    (r"Sendmail\s+([\d.]+)", "smtp", "sendmail", "Sendmail", None),
    (r"Microsoft ESMTP MAIL Service", "smtp", "", "Microsoft Exchange/SMTP", "windows"),
    (r"Dovecot(?: ready| \(([\d.]+)\))", "imap/pop3", "dovecot", "Dovecot", None),
    (r"^RFB (\d{3}\.\d{3})", "vnc", "", "VNC (RFB)", None),
    (r"MariaDB", "mysql", "mariadb", "MariaDB", None),
    (r"^\S*RTSP/1\.0", "rtsp", "", "RTSP", None),
    (r"-NOAUTH|-DENIED|\+PONG|^-ERR (?:unknown command|wrong number of arguments|Protocol error)", "redis", "redis", "Redis", None),
    (r"Elasticsearch|\"cluster_name\"", "elasticsearch", "elasticsearch", "Elasticsearch", None),
    (r"^220 .*(?:Samba|Pure|Welcome to)", "ftp", "", "FTP", None),
]
_HTTP_SERVER_RULES = [
    (r"Apache(?:/([\d.]+))?(?:.*\((Ubuntu|Debian|Win\d+|Win32|CentOS|Red Hat|Unix|FreeBSD)\))?", "apache", "Apache httpd"),
    (r"nginx(?:/([\d.]+))?", "nginx", "nginx"),
    (r"Microsoft-IIS/([\d.]+)", "iis", "Microsoft IIS"),
    (r"lighttpd(?:/([\d.]+))?", "lighttpd", "lighttpd"),
    (r"Caddy", "caddy", "Caddy"),
    (r"Jetty(?:\(|/)([\d.]+)", "jetty", "Jetty"),
    (r"Apache-Coyote(?:/([\d.]+))?|Tomcat(?:/([\d.]+))?", "tomcat", "Apache Tomcat"),
    (r"HAProxy", "haproxy", "HAProxy"),
    (r"Squid/([\d.]+)", "squid", "Squid"),
    (r"Node\.js|Express", "nodejs", "Node.js"),
    (r"gunicorn(?:/([\d.]+))?", "", "gunicorn"),
    (r"MiniUPnPd/([\d.]+)", "", "MiniUPnPd"),
    (r"Werkzeug/([\d.]+)", "", "Werkzeug"),
    (r"openresty(?:/([\d.]+))?", "", "OpenResty"),
    (r"GoAhead-Webs", "", "GoAhead (embedded)"),
    (r"Boa/([\d.]+)", "", "Boa (embedded)"),
    (r"mini_httpd", "", "mini_httpd (embedded)"),
]
_OS_FROM_TEXT = [(r"ubuntu", "ubuntu"), (r"debian", "debian"), (r"raspbian", "raspbian"), (r"centos", "centos"), (r"red hat|rhel", "rhel"),
                 (r"freebsd", "freebsd"), (r"win(32|64|dows)", "windows"), (r"microsoft", "windows"), (r"mikrotik|routeros", "routeros"),
                 (r"cisco", "cisco"), (r"synology", "synology"), (r"qnap", "qnap"), (r"unix", "unix")]


def os_hints_from(text):
    t = (text or "").lower()
    return sorted({h for pat, h in _OS_FROM_TEXT if re.search(pat, t)})


def identify_banner(port, text):
    """Banner text -> {name, product, product_key, version, os_hints}. Empty strings when nothing is recognised."""
    out = {"name": PORT_NAMES.get(port, ""), "product": "", "product_key": "", "version": "", "os_hints": []}
    if not text:
        return out
    if port == 53:                                                       # DNS software answering version.bind
        m = re.match(r"\s*(dnsmasq|unbound|PowerDNS Authoritative Server|Knot DNS)?[- ]?(\d+\.\d+(?:\.\d+)*)", text, re.I)
        if m:
            k = {"dnsmasq": "dnsmasq", "unbound": "unbound"}.get((m.group(1) or "").lower(), "bind" if not m.group(1) else "")
            out.update(name="dns", product=(m.group(1) or "ISC BIND").strip(), product_key=k, version=m.group(2), os_hints=os_hints_from(text))
            return out
    m = re.search(r"\x0a(\d+\.\d+\.\d+[\w.\-+~]*)\x00", text)            # MySQL / MariaDB handshake
    if m and (port in (3306, 3307, 33060) or re.match(r"^.\x00\x00\x00\x0a\d", text, re.S)):
        v = m.group(1)
        mariadb = "mariadb" in text.lower()
        out.update(name="mysql", product="MariaDB" if mariadb else "MySQL", product_key="mariadb" if mariadb else "mysql", version=re.match(r"[\d.]+", v).group(0))
        out["os_hints"] = os_hints_from(v)
        return out
    for pat, name, key, label, os_ in SERVICE_RULES:
        m = re.search(pat, text, re.I | re.M)
        if m:
            ver = (m.group(1) if m.groups() and m.group(1) and re.match(r"[\d.]+[\w.]*$", m.group(1)) else "") or ""
            out.update(name=name if name else out["name"], product=label, product_key=key, version=ver)
            hints = set(os_hints_from(text[:200]))
            if os_:
                hints.add(os_)
            if m.groups() and len(m.groups()) > 1 and m.group(2):
                hints.add(m.group(2).lower())
            out["os_hints"] = sorted(hints)
            return out
    return out


def parse_http_response(raw):
    """Raw HTTP response bytes -> {status, reason, headers(lower-case), server, title, body_start}. None if not HTTP."""
    head, _, body = raw.partition(b"\r\n\r\n")
    lines = head.decode("latin-1", "replace").split("\r\n")
    m = re.match(r"HTTP/[\d.]+\s+(\d{3})\s*(.*)", lines[0] if lines else "")
    if not m:
        return None
    headers = {}
    for ln in lines[1:]:
        k, _, v = ln.partition(":")
        if v:
            headers.setdefault(k.strip().lower(), v.strip())
    t = re.search(rb"<title[^>]*>(.*?)</title>", body[:16384], re.I | re.S)
    return {"status": int(m.group(1)), "reason": m.group(2).strip(), "headers": headers, "server": headers.get("server", ""),
            "title": re.sub(r"\s+", " ", t.group(1).decode("utf-8", "replace")).strip()[:120] if t else "",
            "body_start": body[:600].decode("utf-8", "replace")}


def identify_http(port, http, tls=False):
    out = {"name": "https" if (tls or port in TLS_PORTS) else "http", "product": "", "product_key": "", "version": "", "os_hints": []}
    srv = http["server"] + " " + http["headers"].get("x-powered-by", "")
    for pat, key, label in _HTTP_SERVER_RULES:
        m = re.search(pat, srv, re.I)
        if m:
            ver = next((g for g in m.groups() if g and re.match(r"[\d.]+$", g)), "")
            out.update(product=label, product_key=key, version=ver)
            break
    php = re.search(r"PHP/([\d.]+)", srv, re.I)
    if php and not out["product_key"]:
        out.update(product="PHP", product_key="php", version=php.group(1))
    elif php:
        out.setdefault("extra", []).append(f"PHP/{php.group(1)}")
    body = http.get("body_start", "")
    if "You Know, for Search" in body:
        v = re.search(r'"number"\s*:\s*"([\d.]+)"', body)
        out.update(name="elasticsearch", product="Elasticsearch", product_key="elasticsearch", version=v.group(1) if v else "")
    out["os_hints"] = os_hints_from(srv)
    return out


# ---------------------------------------------------------------- TLS inspection
def parse_certificate(der):
    from cryptography import x509
    from cryptography.hazmat.primitives.asymmetric import ec, rsa
    c = x509.load_der_x509_certificate(der)
    cn = next((a.value for a in c.subject if a.oid == x509.oid.NameOID.COMMON_NAME), "")
    icn = next((a.value for a in c.issuer if a.oid == x509.oid.NameOID.COMMON_NAME), "")
    try:
        sans = c.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        san = [str(x.value) for x in sans][:20]
    except x509.ExtensionNotFound:
        san = []
    pk = c.public_key()
    kt = f"RSA-{pk.key_size}" if isinstance(pk, rsa.RSAPublicKey) else f"EC-{pk.curve.name}" if isinstance(pk, ec.EllipticCurvePublicKey) else type(pk).__name__
    now = datetime.now(timezone.utc)
    return {"subject_cn": cn, "issuer_cn": icn, "self_signed": c.subject == c.issuer, "san": san, "key": kt,
            "sig_alg": c.signature_algorithm_oid._name, "not_before": c.not_valid_before_utc.isoformat(timespec="seconds"),
            "not_after": c.not_valid_after_utc.isoformat(timespec="seconds"), "expired": c.not_valid_after_utc < now,
            "days_left": (c.not_valid_after_utc - now).days}


def tls_probe(ip, port, timeout=3.0, server_name=None, legacy=None):
    """TLS handshake without verification (we are inspecting, not trusting). -> dict or None.
    ``legacy`` = ssl.TLSVersion to force (for the weak-protocol check)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    try:
        if legacy is not None:
            ctx.minimum_version = ctx.maximum_version = legacy
            ctx.set_ciphers("ALL:@SECLEVEL=0")
        ctx.set_alpn_protocols(["h2", "http/1.1"])
    except (ssl.SSLError, ValueError, AttributeError):
        if legacy is not None:
            return None
    try:
        with socket.create_connection((ip, port), timeout=timeout) as raw:
            with ctx.wrap_socket(raw, server_hostname=server_name) as s:
                der = s.getpeercert(binary_form=True)
                info = {"version": s.version(), "cipher": (s.cipher() or ("", "", 0))[0], "alpn": s.selected_alpn_protocol() or ""}
                if der:
                    try:
                        info["cert"] = parse_certificate(der)
                    except Exception as e:
                        info["cert_error"] = type(e).__name__
                return info
    except (ssl.SSLError, OSError, ValueError):
        return None


# ---------------------------------------------------------------- active service detection
HTTP_REQ = b"GET / HTTP/1.1\r\nHost: %s\r\nUser-Agent: AuditForensics-Discovery\r\nAccept: */*\r\nConnection: close\r\n\r\n"
# SMBv1 negotiate (NetBIOS header + 32-byte SMB header + dialect "NT LM 0.12"): a reply starting \xffSMB means SMBv1 is enabled
SMB1_NEGOTIATE = bytes.fromhex("0000002f" "ff534d42" "72" "00000000" "18" "53c8" "0000" "0000000000000000" "0000" "ffff" "fffe" "0000" "0000"
                               "00" "0c00" "02" "4e54204c4d20302e3132" "00")
# RDP X.224 connection request asking for TLS + CredSSP: the confirm tells us which security layer the server selects
RDP_X224 = bytes.fromhex("03000013" "0ee0" "0000" "0000" "00" "01000800" "03000000")
PG_SSLREQ = bytes.fromhex("0000000804d2162f")
RTSP_REQ = b"OPTIONS rtsp://%s/ RTSP/1.0\r\nCSeq: 1\r\n\r\n"
# service-specific first probe by well-known port; ports not listed fall back to GENERIC_PROBES (works on any port number)
PORT_PROBES = {6379: b"PING\r\n", 5432: PG_SSLREQ, 3389: RDP_X224, 445: SMB1_NEGOTIATE, 554: RTSP_REQ}
GENERIC_PROBES = ["http", "rdp"]


async def _read(reader, n=4096, timeout=1.5):
    try:
        return await asyncio.wait_for(reader.read(n), timeout)
    except (asyncio.TimeoutError, ConnectionError, OSError):
        return b""


async def _first_response(ip, port, timeout):
    """Passive banner first (services that speak first), then protocol probes - each on a fresh connection, because
    many servers close after one exchange. Probing is by *response*, not by port number, so HTTP/Redis/RDP on
    non-standard ports are still identified."""
    raw = await _talk(ip, port, None, timeout, wait_first=0.9) or b""
    if raw:
        return raw
    first = PORT_PROBES.get(port)
    seq = ([first] if first else []) + [HTTP_REQ % ip.encode() if k == "http" else RDP_X224 for k in GENERIC_PROBES]
    for probe in dict.fromkeys(seq):
        raw = await _talk(ip, port, probe, timeout) or b""
        if raw:
            return raw
    return b""


async def _talk(ip, port, send, timeout, wait_first=0.0):
    """Connect, optionally wait for a passive banner, send a probe, return everything received."""
    try:
        r, w = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout)
    except (asyncio.TimeoutError, OSError):
        return None
    got = b""
    try:
        if wait_first:
            got = await _read(r, 2048, wait_first)
        if not got and send:
            w.write(send)
            await w.drain()
            got = await _read(r, 8192, timeout)
            if send.startswith(b"GET "):                       # collect a little more of the page for the title
                got += await _read(r, 8192, 0.3)
    except (ConnectionError, OSError):
        pass
    finally:
        try:
            w.close()
        except Exception:
            pass
    return got


def parse_rdp_negotiation(data):
    """RDP X.224 connection-confirm -> {'protocol': 'rdp'|'tls'|'nla'|..., 'nla': bool} or None."""
    if len(data) < 19 or data[0] != 3 or data[5] != 0xD0:
        return None
    if data[11] == 0x02:
        sel = struct.unpack("<I", data[15:19])[0]
        return {"protocol": {0: "standard-rdp", 1: "tls", 2: "nla", 8: "nla-ex"}.get(sel, str(sel)), "nla": sel in (2, 8)}
    return {"protocol": "unknown", "nla": False}


async def detect_tcp_service(ip, port, cfg):
    """Identify what is listening on an open TCP port. Always returns a service dict."""
    svc = {"port": port, "proto": "tcp", "state": "open", "name": PORT_NAMES.get(port, ""), "product": "", "product_key": "", "version": "",
           "banner": "", "tls": None, "http": None, "notes": [], "os_hints": []}
    t = max(cfg.timeout * 2, 2.0)
    raw = b""
    if port not in TLS_PORTS:
        raw = await _first_response(ip, port, t)
    text = raw.decode("latin-1", "replace")
    http = parse_http_response(raw) if raw[:5] == b"HTTP/" else None
    plain_to_tls = bool(http and http["status"] == 400 and re.search(r"plain http request was sent to https port|sent to https", http["body_start"], re.I))
    silent_plain = not raw and port not in (9100, 515, 445, 3389, 5900, 5901)
    if port in TLS_PORTS or silent_plain or plain_to_tls:
        tlsinfo = await asyncio.get_running_loop().run_in_executor(None, tls_probe, ip, port, t)
        if tlsinfo:
            svc["tls"] = tlsinfo
            resp = await asyncio.get_running_loop().run_in_executor(None, _https_get, ip, port, t)
            if resp:
                raw = resp
                http = parse_http_response(raw)
                text = raw.decode("latin-1", "replace")
            svc["name"] = "https" if http else (svc["name"] or "tls")
    rdp = parse_rdp_negotiation(raw) if raw[:1] == b"\x03" else None
    if rdp:
        if True:
            svc.update(name="rdp"); svc["rdp"] = rdp
            svc["notes"].append("rdp-nla-required" if rdp["nla"] else "rdp-nla-not-required")
    if raw[4:8] == b"\xffSMB":
        svc.update(name="smb", product="SMBv1 enabled"); svc["notes"].append("smb1-enabled")
    elif raw[4:8] == b"\xfeSMB":
        svc.update(name="smb"); svc["notes"].append("smb2-or-later")
    if port == 5432 and raw[:1] in (b"S", b"N"):
        svc.update(name="postgresql", product="PostgreSQL", product_key="postgresql")
    if http:
        svc["http"] = {"status": http["status"], "server": http["server"], "title": http["title"],
                       "headers": {k: v for k, v in http["headers"].items() if k in ("server", "x-powered-by", "www-authenticate", "location", "content-type", "set-cookie", "strict-transport-security")}}
        ident = identify_http(port, http, tls=bool(svc["tls"]))
        svc.update({k: ident[k] for k in ("name", "product", "product_key", "version")})
        svc["os_hints"] = ident["os_hints"]
        svc["banner"] = (http["server"] or f"HTTP {http['status']}")[:200]
        if http["headers"].get("www-authenticate", "").lower().startswith("basic") and not svc["tls"]:
            svc["notes"].append("http-basic-auth-cleartext")
    elif text.strip() and not svc["product"]:
        svc["banner"] = re.sub(r"[^\x20-\x7e]+", " ", text).strip()[:200]
        ident = identify_banner(port, text)
        for k in ("name", "product", "product_key", "version"):
            if ident[k]:
                svc[k] = ident[k]
        svc["os_hints"] = ident["os_hints"]
        if text[:1] == "\xff" and port in (23, 2323):
            svc["name"] = "telnet"
    if cfg.intensity == "deep":
        svc["notes"] += await _deep_checks(ip, port, svc, t)
    return svc


def _https_get(ip, port, timeout):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    try:
        with socket.create_connection((ip, port), timeout=timeout) as raw:
            with ctx.wrap_socket(raw, server_hostname=None) as s:
                s.settimeout(timeout)
                s.sendall(HTTP_REQ % ip.encode())
                buf = b""
                while len(buf) < 16384:
                    try:
                        c = s.recv(8192)
                    except (socket.timeout, ssl.SSLError):
                        break
                    if not c:
                        break
                    buf += c
                return buf
    except (ssl.SSLError, OSError, ValueError):
        return b""


async def _deep_checks(ip, port, svc, t):
    """Safe, read-only probes for well-known misconfigurations. No credentials are guessed beyond the documented
    anonymous FTP login; nothing is written or exploited."""
    notes = []
    if svc["name"] == "ftp" or port == 21:
        try:
            rd, wr = await asyncio.wait_for(asyncio.open_connection(ip, port), t)
            await _read(rd, 1024, 1.0)
            wr.write(b"USER anonymous\r\n"); await wr.drain()
            a = (await _read(rd, 1024, 1.5)).decode("latin-1", "replace")
            if a.startswith("331"):
                wr.write(b"PASS af-audit@example.com\r\n"); await wr.drain()
                b = (await _read(rd, 1024, 1.5)).decode("latin-1", "replace")
                if b.startswith("230"):
                    notes.append("ftp-anonymous-login")
            elif a.startswith("230"):
                notes.append("ftp-anonymous-login")
            wr.close()
        except (asyncio.TimeoutError, OSError):
            pass
    if svc["name"] == "redis" or port == 6379:
        r = (await _talk(ip, port, b"INFO server\r\n", t) or b"").decode("latin-1", "replace")
        if "redis_version" in r:
            notes.append("redis-no-auth")
            v = re.search(r"redis_version:([\d.]+)", r)
            if v:
                svc.update(product="Redis", product_key="redis", version=v.group(1), name="redis")
    if port in (2375,) or "docker" in (svc["http"] or {}).get("server", "").lower():
        r = await _talk(ip, port, b"GET /version HTTP/1.0\r\n\r\n", t)
        if r and b'"ApiVersion"' in r:
            notes.append("docker-api-no-auth")
            v = re.search(rb'"Version"\s*:\s*"([\d.]+)"', r)
            if v:
                svc.update(product="Docker Engine", product_key="docker", version=v.group(1).decode())
    if svc["product_key"] == "elasticsearch" and svc["http"] and svc["http"]["status"] == 200:
        notes.append("elasticsearch-no-auth")
    if svc["tls"]:
        legacy = []
        for name, ver in (("TLSv1.0", ssl.TLSVersion.TLSv1), ("TLSv1.1", ssl.TLSVersion.TLSv1_1)):
            r = await asyncio.get_running_loop().run_in_executor(None, tls_probe, ip, port, t, None, ver)
            if r:
                legacy.append(name)
        if legacy:
            notes.append("tls-legacy:" + ",".join(legacy))
    return notes


async def detect_services(ip, open_ports, cfg, cancel=None, progress=None):
    sem = asyncio.Semaphore(32)
    out, done = [], [0]

    async def one(p):
        async with sem:
            if cancel and cancel():
                return
            s = await detect_tcp_service(ip, p, cfg)
            out.append(s)
            done[0] += 1
            if progress:
                progress(done[0] / max(len(open_ports), 1))
    await asyncio.gather(*(one(p) for p in open_ports))
    return sorted(out, key=lambda s: s["port"])


def scan_host(ip, dev, cfg, cancel=None, progress=None):
    """Port-scan + identify one device (mutates and returns ``dev``)."""
    ports = cfg.tcp_ports()
    if not ports:
        return dev

    async def go():
        res = await scan_tcp(ip, ports, cfg.timeout, cfg.concurrency, cfg.rate_per_host, cancel, None)
        dev["closed_tcp"], dev["filtered_tcp"], dev["ports_scanned"] = res["closed"], res["filtered"], res["scanned"]
        if res["all_filtered"]:
            dev["notes"].append("every probed port was silently dropped (drop-all firewall); remaining ports were not scanned")
        if res["closed"]:
            if "tcp-closed" not in "".join(dev["discovered_by"]):
                dev["discovered_by"].append("tcp-rst")
        if res["open"] and "tcp-open" not in "".join(dev["discovered_by"]):
            dev["discovered_by"].append(f"tcp-open:{res['open'][0]}")
        if cfg.intensity != "discovery" and res["open"]:
            dev["services"] = await detect_services(ip, res["open"], cfg, cancel, progress)
        else:
            dev["services"] = [{"port": p, "proto": "tcp", "state": "open", "name": PORT_NAMES.get(p, ""), "product": "", "product_key": "", "version": "",
                                "banner": "", "tls": None, "http": None, "notes": [], "os_hints": []} for p in res["open"]]
    asyncio.run(go())
    if cfg.udp and not (cancel and cancel()):
        dev["udp"] = scan_udp(ip, cfg, cancel)
    return dev
