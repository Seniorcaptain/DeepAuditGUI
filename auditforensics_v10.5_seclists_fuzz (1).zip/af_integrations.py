#!/usr/bin/env python3
"""Outbound integrations: SIEM export, ticketing and alerts for new Critical/High findings and drift.

Configure with AF_HOME/integrations.json (secrets are read from the environment variables it NAMES, never stored):
{
  "min_severity": "High", "cooldown_hours": 24,
  "syslog":     {"url": "udp://siem.corp:514", "format": "cef"},
  "splunk_hec": {"url": "https://splunk.corp:8088/services/collector/event", "token_env": "AF_SPLUNK_TOKEN", "index": "security"},
  "webhook":    {"url": "https://hooks.slack.com/services/...", "kind": "slack"},            // or "generic"
  "email":      {"host": "smtp.corp", "port": 587, "starttls": true, "from": "af@corp", "to": ["soc@corp"],
                 "user_env": "AF_SMTP_USER", "pass_env": "AF_SMTP_PASS"},
  "jira":       {"base_url": "https://corp.atlassian.net", "project": "SEC", "issue_type": "Task",
                 "email_env": "AF_JIRA_EMAIL", "token_env": "AF_JIRA_TOKEN", "min_severity": "Critical"},
  "servicenow": {"instance_url": "https://corp.service-now.com", "user_env": "AF_SNOW_USER", "pass_env": "AF_SNOW_PASS"}
}
Everything is best-effort: a failing integration never breaks a scan. Each alert is de-duplicated per finding for
``cooldown_hours`` so a persistent problem does not page you every scan.
"""
import hashlib, ipaddress, json, logging, logging.handlers, os, smtplib, socket, sqlite3, ssl
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import urlparse

from af_util import af_home, utc_iso, utcnow

log = logging.getLogger("af_integrations")
SEV_RANK = {"Info": 0, "Low": 1, "Medium": 2, "High": 3, "Critical": 4}
OCSF_SEV = {"Info": 1, "Low": 2, "Medium": 3, "High": 4, "Critical": 5}
CEF_SEV = {"Info": 1, "Low": 3, "Medium": 5, "High": 8, "Critical": 10}
DB_PATH = Path(os.environ.get("AF_DB_PATH") or (Path.home() / ".auditforensics" / "history.db"))


def load_config():
    try:
        return json.loads((af_home() / "integrations.json").read_text())
    except (OSError, ValueError):
        return {}


def norm(f, host=""):
    """Accept both agent-style (check_name/risk) and UI-style (Check/Risk) finding dicts."""
    g = lambda *k: next((f[x] for x in k if f.get(x) not in (None, "")), "")
    return {"host": g("Host", "host") or host, "category": g("Category", "category"), "check": g("Check", "check_name"),
            "status": g("Status", "status"), "risk": g("Risk", "risk") or "Info", "details": str(g("Details", "details"))[:1000],
            "recommendation": str(g("Recommendation", "recommendation"))[:500], "mitre": g("MITRE", "mitre"),
            "check_id": g("check_id", "CheckID"), "timestamp": g("Timestamp", "timestamp") or utc_iso()}


def fingerprint(n):
    return hashlib.sha256(f"{n['host']}|{n['check_id'] or n['check']}|{n['details'][:80]}".encode()).hexdigest()[:20]


# ---------------------------------------------------------------- formats
def _cef_h(s):
    return str(s).replace("\\", "\\\\").replace("|", "\\|")


def _cef_e(s):
    return str(s).replace("\\", "\\\\").replace("=", "\\=").replace("\n", " ").replace("\r", " ")


def to_cef(n, source="AuditForensics"):
    ext = (f"dhost={_cef_e(n['host'])} cat={_cef_e(n['category'])} msg={_cef_e(n['details'])} "
           f"cs1Label=mitre cs1={_cef_e(n['mitre'])} cs2Label=checkId cs2={_cef_e(n['check_id'])} "
           f"cs3Label=recommendation cs3={_cef_e(n['recommendation'])} rt={_cef_e(n['timestamp'])}")
    return f"CEF:0|AuditForensics|{_cef_h(source)}|10.5|{_cef_h(n['check_id'] or n['check'])}|{_cef_h(n['check'])}|{CEF_SEV.get(n['risk'], 1)}|{ext}"


def to_ocsf(n, source="AuditForensics"):
    """OCSF 1.1 Detection Finding (class_uid 2004)."""
    return {"class_uid": 2004, "category_uid": 2, "class_name": "Detection Finding", "activity_id": 1,
            "severity_id": OCSF_SEV.get(n["risk"], 1), "severity": n["risk"], "time": n["timestamp"], "status": n["status"],
            "message": n["details"], "metadata": {"product": {"name": "AuditForensics", "vendor_name": "AuditForensics"}, "version": "1.1.0"},
            "finding_info": {"title": n["check"], "uid": n["check_id"] or fingerprint(n), "types": [n["category"]],
                             "attacks": [{"technique": {"uid": n["mitre"]}}] if n["mitre"] else []},
            "device": {"hostname": n["host"]}, "unmapped": {"source": source, "recommendation": n["recommendation"]}}


def to_slack(items, source):
    top = items[:10]
    lines = [f"*{len(items)} new High/Critical finding(s)* from `{source}`"]
    lines += [f"• [{n['risk']}] {n['host'] or '-'}: {n['check']} - {n['details'][:140]}" for n in top]
    if len(items) > len(top):
        lines.append(f"…and {len(items) - len(top)} more")
    return {"text": "\n".join(lines)}


# ---------------------------------------------------------------- safe URLs
def _check_url(url):
    u = urlparse(url)
    if u.scheme not in ("https", "http") or not u.hostname:
        raise ValueError("integration URL must be http(s)")
    try:
        ips = {ai[4][0] for ai in socket.getaddrinfo(u.hostname, None)}
    except OSError:
        ips = set()
    for ip in ips:
        a = ipaddress.ip_address(ip.split("%")[0])
        if a.is_link_local:                                   # cloud metadata endpoints (169.254.169.254 / fe80::)
            raise ValueError("integration URL resolves to a link-local address")
    return url


def _env(name):
    v = os.environ.get(name or "", "")
    if not v:
        raise ValueError(f"environment variable {name} is not set")
    return v


# ---------------------------------------------------------------- senders: each returns (ok, message)
def send_syslog(items, cfg, source):
    u = urlparse(cfg["url"])
    lg = logging.getLogger(f"af_integrations.syslog.{cfg['url']}")
    if not lg.handlers:
        if u.scheme == "unix":
            h = logging.handlers.SysLogHandler(address=u.path)
        else:
            h = logging.handlers.SysLogHandler(address=(u.hostname, u.port or 514),
                                               socktype=socket.SOCK_STREAM if u.scheme == "tcp" else socket.SOCK_DGRAM)
        lg.addHandler(h); lg.setLevel(logging.INFO); lg.propagate = False
    for n in items:
        lg.info(json.dumps(to_ocsf(n, source)) if cfg.get("format") == "ocsf" else to_cef(n, source))
    return True, f"{len(items)} event(s)"


def send_splunk(items, cfg, source, http=None):
    import requests
    http = http or requests
    body = "\n".join(json.dumps({"event": to_ocsf(n, source), "sourcetype": "auditforensics:finding", "index": cfg.get("index", "main"),
                                 "host": n["host"] or source}) for n in items)
    r = http.post(_check_url(cfg["url"]), data=body, headers={"Authorization": f"Splunk {_env(cfg.get('token_env'))}"}, timeout=15)
    return r.status_code == 200, f"HTTP {r.status_code}"


def send_webhook(items, cfg, source, http=None):
    import requests
    http = http or requests
    payload = to_slack(items, source) if cfg.get("kind", "slack") == "slack" else {"source": source, "findings": [to_ocsf(n, source) for n in items]}
    r = http.post(_check_url(cfg["url"]), json=payload, timeout=15)
    return 200 <= r.status_code < 300, f"HTTP {r.status_code}"


def send_email(items, cfg, source, smtp_cls=smtplib.SMTP):
    m = EmailMessage()
    m["Subject"] = f"[AuditForensics] {len(items)} new High/Critical finding(s) - {source}"
    m["From"], m["To"] = cfg["from"], ", ".join(cfg["to"])
    m.set_content("\n".join(f"[{n['risk']}] {n['host'] or '-'} | {n['check']} | {n['details'][:200]}" for n in items[:100]))
    with smtp_cls(cfg["host"], int(cfg.get("port", 587)), timeout=20) as s:
        if cfg.get("starttls", True):
            s.starttls(context=ssl.create_default_context())
        if cfg.get("user_env"):
            s.login(_env(cfg["user_env"]), _env(cfg["pass_env"]))
        s.send_message(m)
    return True, f"sent to {len(cfg['to'])} recipient(s)"


def create_jira(n, cfg, http=None):
    import requests
    http = http or requests
    desc = (f"Host: {n['host']}\nCategory: {n['category']}\nRisk: {n['risk']}\nDetails: {n['details']}\n"
            f"Recommendation: {n['recommendation']}\nMITRE: {n['mitre']}\nCheck ID: {n['check_id']}")
    body = {"fields": {"project": {"key": cfg["project"]}, "issuetype": {"name": cfg.get("issue_type", "Task")},
                       "summary": f"[{n['risk']}] {n['check']} on {n['host'] or 'unknown host'}"[:250],
                       "description": {"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": [{"type": "text", "text": desc}]}]},
                       "labels": ["auditforensics", n["risk"].lower()]}}
    r = http.post(_check_url(cfg["base_url"].rstrip("/") + "/rest/api/3/issue"), json=body,
                  auth=(_env(cfg["email_env"]), _env(cfg["token_env"])), timeout=20)
    return r.status_code in (200, 201), (r.json().get("key", "") if r.status_code in (200, 201) else f"HTTP {r.status_code}")


def create_servicenow(n, cfg, http=None):
    import requests
    http = http or requests
    body = {"short_description": f"[{n['risk']}] {n['check']} on {n['host'] or 'unknown host'}"[:160],
            "description": f"{n['details']}\n\nRecommendation: {n['recommendation']}\nMITRE: {n['mitre']}",
            "urgency": {"Critical": "1", "High": "2"}.get(n["risk"], "3"), "category": "security"}
    r = http.post(_check_url(cfg["instance_url"].rstrip("/") + f"/api/now/table/{cfg.get('table', 'incident')}"), json=body,
                  auth=(_env(cfg["user_env"]), _env(cfg["pass_env"])), headers={"Accept": "application/json"}, timeout=20)
    return r.status_code in (200, 201), (r.json().get("result", {}).get("number", "") if r.status_code in (200, 201) else f"HTTP {r.status_code}")


# ---------------------------------------------------------------- de-duplication
def _db():
    c = sqlite3.connect(str(DB_PATH), timeout=30)
    c.execute("CREATE TABLE IF NOT EXISTS notified (fingerprint TEXT, channel TEXT, ts TEXT, PRIMARY KEY (fingerprint, channel))")
    return c


def _fresh(items, channel, cooldown_h):
    """Return the items not already sent on this channel within the cooldown, and mark them sent."""
    import datetime
    cutoff = (utcnow() - datetime.timedelta(hours=cooldown_h)).isoformat(timespec="seconds")
    out = []
    try:
        c = _db()
        for n in items:
            fp = fingerprint(n)
            row = c.execute("SELECT ts FROM notified WHERE fingerprint=? AND channel=?", (fp, channel)).fetchone()
            if row is None or row[0] < cutoff:
                out.append(n)
        return out, c
    except sqlite3.Error:
        return items, None


def _mark(c, items, channel):
    if c is None:
        return
    for n in items:
        c.execute("INSERT OR REPLACE INTO notified VALUES (?,?,?)", (fingerprint(n), channel, utc_iso()))
    c.commit(); c.close()


# ---------------------------------------------------------------- public API
def notify_findings(findings, source="scan", host="", config=None, http=None, smtp_cls=smtplib.SMTP):
    """Alert on FAIL/WARNING findings at or above ``min_severity`` (default High). -> {channel: message}."""
    cfg = config if config is not None else load_config()
    if not cfg:
        return {}
    min_rank = SEV_RANK.get(cfg.get("min_severity", "High"), 3)
    items = [n for n in (norm(f, host) for f in findings) if n["status"] in ("FAIL", "WARNING") and SEV_RANK.get(n["risk"], 0) >= min_rank]
    out = {}
    if not items:
        return out
    cd = float(cfg.get("cooldown_hours", 24))
    for ch, fn in (("syslog", lambda i, c: send_syslog(i, c, source)), ("splunk_hec", lambda i, c: send_splunk(i, c, source, http)),
                   ("webhook", lambda i, c: send_webhook(i, c, source, http)), ("email", lambda i, c: send_email(i, c, source, smtp_cls))):
        if ch not in cfg:
            continue
        fresh, conn = _fresh(items, ch, cd)
        if not fresh:
            out[ch] = "suppressed (cooldown)"
            if conn: conn.close()
            continue
        try:
            ok, msg = fn(fresh, cfg[ch])
        except Exception as e:
            ok, msg = False, f"{type(e).__name__}: {str(e)[:120]}"
            log.warning("integration %s failed: %s", ch, msg)
        out[ch] = ("ok: " if ok else "FAILED: ") + msg
        if ok:
            _mark(conn, fresh, ch)
        elif conn:
            conn.close()
    for ch, fn in (("jira", lambda n, c: create_jira(n, c, http)), ("servicenow", lambda n, c: create_servicenow(n, c, http))):
        if ch not in cfg:
            continue
        tmin = SEV_RANK.get(cfg[ch].get("min_severity", "Critical"), 4)
        cand = [n for n in items if SEV_RANK[n["risk"]] >= tmin]
        fresh, conn = _fresh(cand, ch, cd * 7)               # tickets: one per finding per week
        made = []
        for n in fresh[: int(cfg[ch].get("max_per_run", 10))]:
            try:
                ok, ref = fn(n, cfg[ch])
            except Exception as e:
                ok, ref = False, str(e)[:80]
            if ok:
                made.append(n); out.setdefault(ch, []).append(ref) if isinstance(out.get(ch, []), list) else None
        out[ch] = out.get(ch) or ("no new tickets" if not fresh else "FAILED")
        _mark(conn, made, ch)
    return out


def drift_new_findings(prev, cur):
    """Findings present now that were absent in the previous scan (FAIL/WARNING only)."""
    seen = {fingerprint(norm(f)) for f in prev}
    return [f for f in cur if f.get("Status", f.get("status")) in ("FAIL", "WARNING") and fingerprint(norm(f)) not in seen]


def notify_drift(prev, cur, source="scheduled scan", config=None, **kw):
    return notify_findings(drift_new_findings(prev or [], cur), source=source, config=config, **kw)


def export_events(findings, fmt="ocsf", host=""):
    """Bulk export for ingestion (returns a string): fmt = ocsf (NDJSON) | cef."""
    items = [norm(f, host) for f in findings]
    return "\n".join(json.dumps(to_ocsf(n)) if fmt == "ocsf" else to_cef(n) for n in items)
