"""Ed25519 signing for (a) evidence manifests and (b) manager->agent commands.

Keys live in AF_HOME as mode-600 PEM files and are created on first use. Public keys are distributed
to agents at enrollment (trust-on-first-use) or pinned with ``--manager-pubkey``.
"""
import base64
import json
import os
from pathlib import Path

from af_util import af_home, private_write

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature
    HAS_CRYPTO = True
except ImportError:           # pragma: no cover
    HAS_CRYPTO = False


def _key_path(name):
    return af_home() / f"{name}.ed25519.pem"


def _load_or_create(name):
    if not HAS_CRYPTO:
        raise RuntimeError("cryptography package not installed")
    p = _key_path(name)
    if not p.exists():
        k = Ed25519PrivateKey.generate()
        private_write(p, k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                         serialization.NoEncryption()))
        return k
    return serialization.load_pem_private_key(p.read_bytes(), None)


def public_pem(name):
    k = _load_or_create(name)
    return k.public_key().public_bytes(serialization.Encoding.PEM,
                                       serialization.PublicFormat.SubjectPublicKeyInfo).decode()


def sign(name, message: bytes) -> str:
    return base64.b64encode(_load_or_create(name).sign(message)).decode()


def verify(pub_pem, sig_b64, message: bytes) -> bool:
    if not HAS_CRYPTO:
        return False
    try:
        pub = serialization.load_pem_public_key(pub_pem.encode() if isinstance(pub_pem, str) else pub_pem)
        if not isinstance(pub, Ed25519PublicKey):
            return False
        pub.verify(base64.b64decode(sig_b64), message)
        return True
    except (InvalidSignature, ValueError, TypeError, Exception):
        return False


# ---------------------------------------------------------------- commands (manager -> agent)
CMD_KEY = "command_signing"


def command_message(agent_id, cmd_id, command, params, nonce, issued, expires) -> bytes:
    return json.dumps({"a": agent_id, "i": cmd_id, "c": command, "p": params if isinstance(params, dict)
                       else json.loads(params or "{}"), "n": nonce, "t": issued, "e": expires},
                      sort_keys=True, separators=(",", ":")).encode()


def sign_command(agent_id, cmd_id, command, params, nonce, issued, expires) -> str:
    return sign(CMD_KEY, command_message(agent_id, cmd_id, command, params, nonce, issued, expires))


# ---------------------------------------------------------------- evidence manifests
MANIFEST_KEY = "manifest_signing"


def sign_manifest(manifest_bytes: bytes):
    """-> (signature_b64, public_key_pem). Verify with verify_manifest()."""
    return sign(MANIFEST_KEY, manifest_bytes), public_pem(MANIFEST_KEY)


def verify_manifest(manifest_bytes: bytes, sig_b64: str, pub_pem: str) -> bool:
    return verify(pub_pem, sig_b64, manifest_bytes)
