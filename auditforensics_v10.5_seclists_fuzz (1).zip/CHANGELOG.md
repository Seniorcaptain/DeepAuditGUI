# v10.5 — what changed (and what did not)

## Subdomain discovery + consent PDF/WhatsApp (added after the Network Map work)
Web Application scans can now discover subdomains (crt.sh + DNS brute force, wildcard-DNS aware), classify them as
in-scope vs. third-party-hosted (SaaS/cloud platforms excluded from active scanning by default), and flag dangling
CNAMEs as possible subdomain takeovers - all under the same written authorization as the parent domain, worded to
say so. Every scan-authorization (consent) form can now generate a signed, tamper-evident PDF of the record and
send it over WhatsApp (Meta Cloud API), with a click-to-chat fallback when WhatsApp isn't configured; every attempt
is recorded on the authorization row and in the audit trail. 28 new tests (resolver tested against a local fake DNS
server; crt.sh, NVD-adjacent flows, and the WhatsApp API tested against fakes, not the live services - no network
access to crt.sh or graph.facebook.com from the build environment). One real bug was found and fixed while testing:
the WhatsApp opt-in checkbox and phone field were in the same Streamlit form, which cannot update a field's
disabled state before the whole form is submitted - the field is now always available instead of conditionally
disabled. A second fix: the "Scan authorizations" panel was nested inside "if scan history exists," making it
invisible until a scan had actually run; it is now always visible.


## Network Map (new tab, added after the checklist work)
Device discovery (ICMP, TCP connect/RST, ARP, SSDP, mDNS, NetBIOS, reverse DNS) with an *alive confidence*; TCP scanning up to all 65,535 ports plus
UDP; service/version detection (banners, HTTP, TLS certificates, RDP/SMB/Redis/MySQL/PostgreSQL/…); OS and device-type inference with evidence;
per-service CVE lookup (NVD) with KEV/EPSS/asset-context priority and explicit backport/unverified caveats; topology (subnets, gateways, traceroute);
change detection and a persistent asset inventory; cancellable background jobs; scope/authorization/rate-limit enforcement inside the job;
exports (CSV/JSON/GraphML/DOT); optional nmap enrichment. 90 new tests, run against real listening sockets on loopback.
Not tested here: ICMP/ARP/traceroute on a real LAN (none in the build sandbox; parsers tested on recorded output), NVD (no access; tested with a fake),
Windows/macOS, nmap itself (parser and merge tested on sample XML), scapy ARP sweep.


Status of the 36-item improvement checklist. **Done** = implemented and covered by tests; **Partial** = works but with a stated gap;
**Not done** = deliberately left out.

## Done
Fix Linux firewall check · scope `/results` to the owning agent (+ size/field caps, gzip-bomb guard) · stop re-registration hijacking ·
token no longer exported to `os.environ` · command leases/retries/spool/idempotent results · coverage states (ERROR/SKIPPED) in agent and UI ·
service keeps TLS flags · scan range cap + argument-injection guard · safe-by-default API bind + surfaced bind failures · tests ·
UTC timestamps · one-time/short-lived/tagged enrollment tokens · client-generated agent ID bound to its certificate (mTLS) ·
API/worker outside Streamlit · permissions enforced inside actions · step-up auth · scan guardrails (scope, authorization, blackout, rate limits) ·
noisy agent checks fixed (bind-aware ports, 172.16/12 + IPv6, `sshd -T`/Include/Match, narrower process & file scans, hashing, IOC list) ·
retention/pruning (+ audit checkpoints) · single version source · CI · CSR enrollment, short-lived auto-renewing certs, revocation, encrypted CA key ·
YAML check catalog + stable IDs · shared check library for agent and app · hash-chained audit logs + Ed25519-signed manifests ·
vault v2 (key IDs, AES-GCM, row-bound AAD, rotation, re-encryption, OS keyring) · findings stored as rows (+ trend/backfill) ·
SIEM export (CEF/OCSF/Splunk/syslog), Jira/ServiceNow tickets, alerts · OSV matching with KEV/EPSS/asset-criticality/exposure priority ·
AI prompt hardening + local LLM + configurable models + HTML report escaping · MFA recovery codes, breached-password check, first-run setup code, OIDC SSO ·
signed commands · systemd hardening · triage collection with chain of custody, IOC/YARA sweeps · live response with two-person approval ·
SCAP/OpenSCAP results import · pyproject, Dockerfile, compose, hash-pinned lock, single-file `.pyz` and a Linux PyInstaller binary.

## Partial (read before relying on it)
* **Scheduler split:** fleet schedules + maintenance run in `af_worker.py`; *local* scheduled scans still run inside the UI process because the scan engines live in the monolith.
* **Catalog / stable IDs:** every finding gets a deterministic ID and the catalog is complete for the checks found in code (163 entries), but only a few entries carry hand-written rationale/frameworks; the regex topic mapping remains as fallback. Exception/POA&M fingerprints were deliberately **not** changed (would orphan existing exceptions).
* **Findings as rows:** dual-written alongside the encrypted blob (which stays the evidence of record).
* **Swallowed exceptions in the monolith:** 84 of 132 engine-level `except Exception` sites now record to the coverage report (environmental errors are summarised as one SKIPPED row; bugs become ERROR rows). Errors in worker threads of thread pools are not collected.
* **Shared checks:** the agent uses `af_checks` exclusively; the app's own deep engines keep their implementations (their ~170 checks are not re-based on it).
* **SSO:** OIDC via Streamlit's native login, tested with simulated claims only (no live IdP). No SAML.
* **Live response:** kill/quarantine tested; host isolation tested through command-plan and rollback logic with a fake runner, **not** against a real firewall or Windows.
* **OSV matching:** tested against a fake OSV; ecosystem names follow OSV naming but were not verified against the live service from the build sandbox.
* **Windows/macOS:** new Windows PowerShell checks, triage and isolation, and macOS code paths were not executed on those systems.
* **Docker:** files provided, image not built.

## Not done
WebAuthn · KMS/HSM key wrapping · Postgres backend · memory acquisition · agent self-update · SAML.

## Found and fixed while testing (bugs I introduced and caught)
The error recorder recursed into itself (regex rewrote its own handler) and then silently did nothing because `sys` was not imported; the scan-authorization form was lost on rerun because it was only drawn inside the button branch. Both now have regression tests.
