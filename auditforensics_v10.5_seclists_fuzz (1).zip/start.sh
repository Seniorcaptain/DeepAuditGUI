#!/usr/bin/env bash
# Launch the UI bound to localhost. Optional keys: export NVD_API_KEY=... AF_DB_KEY=... before running.
cd "$(dirname "$0")"
[ -d venv ] && source venv/bin/activate
# export AF_ADMIN_USER=admin AF_ADMIN_PASSWORD='long-passphrase'     # headless first admin (otherwise use the setup code)
exec streamlit run auditforensics_web.py --server.address 127.0.0.1 --server.port 8501
