@echo off
cd /d "%~dp0"
if exist venv\Scripts\activate.bat call venv\Scripts\activate.bat
streamlit run auditforensics_web.py --server.address 127.0.0.1 --server.port 8501
