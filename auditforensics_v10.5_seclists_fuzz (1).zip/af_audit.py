"""Tamper-evident audit trail: every row stores SHA-256(prev_hash | canonical(row)), so editing or deleting
a row in the middle breaks the chain. Rows can also be shipped to syslog (AF_SYSLOG=udp://host:514,
tcp://host:514 or unix:///dev/log) which acts as an external anchor against tail truncation.

Legacy rows written before the chain existed have NULL hashes and are ignored by verify().
"""
import hashlib
import json
import logging
import logging.handlers
import os
import sqlite3
from urllib.parse import urlparse

GENESIS = "0" * 64
CHAIN_FIELDS = {
    "ui_audit": ["ts", "username", "event", "detail"],
    "api_audit": ["ts", "event", "agent_id", "ip", "detail"],
    "custody_log": ["ts", "agent_id", "command_id", "action", "actor", "detail", "sha256"],
}
_syslog = {"url": None, "logger": None}


def _connect(path):
    c = sqlite3.connect(str(path), timeout=30, isolation_level=None)
    c.row_factory = sqlite3.Row
    return c


def ensure_chain_columns(c, table):
    cols = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
    for col in ("prev_hash", "row_hash"):
        if col not in cols:
            c.execute(f"ALTER TABLE {table} ADD COLUMN {col} TEXT")


def _canon(table, fields):
    return json.dumps([str(fields.get(k, "")) for k in CHAIN_FIELDS[table]], separators=(",", ":"), ensure_ascii=True)


def _hash(prev, table, fields):
    return hashlib.sha256((prev + "|" + table + "|" + _canon(table, fields)).encode()).hexdigest()


def _ship(table, fields, row_hash):
    url = os.environ.get("AF_SYSLOG", "")
    if not url:
        return
    try:
        if _syslog["url"] != url:
            u = urlparse(url)
            if u.scheme == "unix":
                h = logging.handlers.SysLogHandler(address=u.path)
            else:
                import socket
                h = logging.handlers.SysLogHandler(address=(u.hostname, u.port or 514),
                                                   socktype=socket.SOCK_STREAM if u.scheme == "tcp" else socket.SOCK_DGRAM)
            lg = logging.getLogger("auditforensics.audit")
            lg.handlers = [h]
            lg.setLevel(logging.INFO)
            lg.propagate = False
            _syslog.update(url=url, logger=lg)
        _syslog["logger"].info("auditforensics %s", json.dumps({"table": table, "hash": row_hash, **fields}, default=str))
    except Exception:
        pass


def append(path, table, **fields):
    """Insert one chained audit row atomically. Never raises (auditing must not break the app)."""
    try:
        c = _connect(path)
        try:
            ensure_chain_columns(c, table)
            c.execute("BEGIN IMMEDIATE")
            r = c.execute(f"SELECT row_hash FROM {table} WHERE row_hash IS NOT NULL ORDER BY id DESC LIMIT 1").fetchone()  # nosec B608 - identifiers come from internal constants, values are bound
            prev = r[0] if r else GENESIS
            h = _hash(prev, table, fields)
            cols = CHAIN_FIELDS[table] + ["prev_hash", "row_hash"]
            vals = [str(fields.get(k, "")) for k in CHAIN_FIELDS[table]] + [prev, h]
            c.execute(f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)  # nosec B608 - identifiers come from internal constants, values are bound
            c.execute("COMMIT")
        finally:
            c.close()
        _ship(table, fields, h)
        return h
    except Exception:
        return None


def verify(path, table):
    """-> dict(ok, checked, head, first_bad_id, message). Walks the chain in id order."""
    c = _connect(path)
    try:
        ensure_chain_columns(c, table)
        prev, n = None, 0
        for r in c.execute(f"SELECT * FROM {table} WHERE row_hash IS NOT NULL ORDER BY id"):  # nosec B608 - identifiers come from internal constants, values are bound
            fields = {k: r[k] for k in CHAIN_FIELDS[table]}
            expect_prev = prev if prev is not None else r["prev_hash"]
            if prev is None and r["prev_hash"] != GENESIS:
                return {"ok": False, "checked": n, "head": prev, "first_bad_id": r["id"],
                        "message": "chain does not start at genesis (earlier chained rows were deleted)"}
            if r["prev_hash"] != expect_prev or _hash(r["prev_hash"], table, fields) != r["row_hash"]:
                return {"ok": False, "checked": n, "head": prev, "first_bad_id": r["id"],
                        "message": "row modified or an earlier row was deleted"}
            prev, n = r["row_hash"], n + 1
        return {"ok": True, "checked": n, "head": prev, "first_bad_id": None, "message": "chain intact"}
    finally:
        c.close()
