#!/usr/bin/env python3
"""Vulnerability matching from distro-aware sources (OSV.dev) plus context-aware prioritisation.

Why not just match CPE/version strings: Debian, Ubuntu and RHEL backport fixes without changing the upstream
version, so upstream-version matching reports fixed packages as vulnerable. OSV's Debian/Ubuntu/Alpine records are
built from the distro security trackers and carry the *distro* fixed versions.

  findings = osv_findings(inventory, agent={"criticality": "high", "exposure": "internet"}, kev=set_of_cves, epss={cve: p})
Network access: https://api.osv.dev (query + vuln details). Results are cached for 24 h (AF_HOME/osv_cache.json).
Ecosystem names follow OSV's published naming; verify them for your distribution before relying on them.
"""
import json, math, re, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from af_util import af_home

OSV_BATCH = "https://api.osv.dev/v1/querybatch"
OSV_VULN = "https://api.osv.dev/v1/vulns/"
CACHE_TTL = 24 * 3600
SEV_BASE = {"Critical": 9.5, "High": 8.0, "Medium": 5.5, "Low": 2.5, "Info": 0.5}


# ---------------------------------------------------------------- ecosystem detection
def ecosystem_from_os_release(rel):
    """/etc/os-release dict -> OSV ecosystem string, or None when the distro is not covered."""
    i, v = (rel.get("ID") or "").lower(), rel.get("VERSION_ID") or ""
    if i == "debian" and v:
        return f"Debian:{v.split('.')[0]}"
    if i == "ubuntu" and v:
        yr, _, mo = v.partition(".")
        return f"Ubuntu:{v}:LTS" if mo == "04" and yr.isdigit() and int(yr) % 2 == 0 else f"Ubuntu:{v}"
    if i == "alpine" and v:
        return "Alpine:v" + ".".join(v.split(".")[:2])
    if i in ("almalinux", "rocky") and v:
        return {"almalinux": "AlmaLinux", "rocky": "Rocky Linux"}[i] + f":{v.split('.')[0]}"
    return None


def osv_name(pkg):
    """OSV's Debian/Ubuntu records are keyed by *source* package name."""
    return pkg.get("source") or pkg["name"]


# ---------------------------------------------------------------- CVSS v3.x base score
_AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2}
_AC = {"L": 0.77, "H": 0.44}
_UI = {"N": 0.85, "R": 0.62}
_CIA = {"H": 0.56, "L": 0.22, "N": 0.0}


def _roundup(x):
    i = round(x * 100000)
    return i / 100000.0 if i % 10000 == 0 else (math.floor(i / 10000) + 1) / 10.0


def cvss3_score(vector):
    """Base score from a CVSS:3.x vector string; None when it cannot be parsed."""
    try:
        m = dict(p.split(":") for p in vector.split("/")[1:])
        scope_changed = m["S"] == "C"
        pr = {"N": 0.85, "L": 0.68 if scope_changed else 0.62, "H": 0.5 if scope_changed else 0.27}[m["PR"]]
        iss = 1 - (1 - _CIA[m["C"]]) * (1 - _CIA[m["I"]]) * (1 - _CIA[m["A"]])
        impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15 if scope_changed else 6.42 * iss
        expl = 8.22 * _AV[m["AV"]] * _AC[m["AC"]] * pr * _UI[m["UI"]]
        if impact <= 0:
            return 0.0
        return _roundup(min(1.08 * (impact + expl), 10)) if scope_changed else _roundup(min(impact + expl, 10))
    except (KeyError, ValueError, IndexError):
        return None


def sev_label(score):
    return "Critical" if score >= 9 else "High" if score >= 7 else "Medium" if score >= 4 else "Low" if score > 0 else "Info"


# ---------------------------------------------------------------- OSV records
def parse_vuln(v):
    """OSV vulnerability JSON -> {id, cves, summary, cvss, severity, fixed}."""
    cves = sorted({a for a in ([v.get("id", "")] + v.get("aliases", [])) if a.startswith("CVE-")})
    score = None
    for s in v.get("severity", []):
        if s.get("type", "").startswith("CVSS_V3"):
            score = cvss3_score(s.get("score", "")) or score
    sev = None
    if score is None:
        txt = str((v.get("database_specific") or {}).get("severity", "")).capitalize()
        sev = txt if txt in SEV_BASE else None
        score = SEV_BASE.get(sev) if sev else None
    fixed = sorted({e["fixed"] for a in v.get("affected", []) for r in a.get("ranges", []) for e in r.get("events", []) if "fixed" in e})
    return {"id": v.get("id", ""), "cves": cves, "summary": (v.get("summary") or v.get("details", ""))[:200], "cvss": score,
            "severity": sev_label(score) if score is not None and not sev else (sev or "Medium"), "fixed": fixed,
            "severity_known": score is not None}


def _cache():
    p = af_home() / "osv_cache.json"
    try:
        return p, json.loads(p.read_text())
    except (OSError, ValueError):
        return p, {}


def query_packages(packages, ecosystem, http=None, batch=500, max_pages=5):
    """-> {index_in_packages: [vuln ids]} using /v1/querybatch (with pagination)."""
    import requests
    http = http or requests
    found = {}
    for start in range(0, len(packages), batch):
        chunk = packages[start:start + batch]
        pending = {i: {"package": {"name": osv_name(p), "ecosystem": ecosystem}, "version": p["version"]} for i, p in enumerate(chunk)}
        for _ in range(max_pages):
            if not pending:
                break
            keys = list(pending)
            r = http.post(OSV_BATCH, json={"queries": [pending[k] for k in keys]}, timeout=60)
            r.raise_for_status()
            nxt = {}
            for k, res in zip(keys, r.json().get("results", [])):
                found.setdefault(start + k, []).extend(v["id"] for v in res.get("vulns", []))
                if res.get("next_page_token"):
                    nxt[k] = {**pending[k], "page_token": res["next_page_token"]}
            pending = nxt
    return found


def fetch_vulns(ids, http=None, cap=400, workers=8):
    import requests
    http = http or requests
    path, cache = _cache()
    now, out, todo = time.time(), {}, []
    for i in sorted(set(ids))[:cap]:
        e = cache.get(i)
        (out.__setitem__(i, e["v"]) if e and now - e["t"] < CACHE_TTL else todo.append(i))

    def get(i):
        try:
            r = http.get(OSV_VULN + i, timeout=30)
            return i, (r.json() if r.status_code == 200 else None)
        except Exception:
            return i, None
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for i, v in ex.map(get, todo):
            if v:
                out[i] = v
                cache[i] = {"t": now, "v": v}
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(cache))
    except OSError:
        pass
    return out


# ---------------------------------------------------------------- prioritisation
CRIT = {"low": -1.0, "medium": 0.0, "high": 1.0, "critical": 1.5}
EXPO = {"internal": 0.0, "dmz": 0.75, "internet": 1.5}


def priority_score(cvss, kev=False, epss=0.0, criticality="medium", exposure="internal"):
    """0-10 score: 70 % base severity + exploit evidence (KEV +3, else EPSS x 3) + asset criticality + exposure."""
    base = 5.5 if cvss is None else cvss
    s = base * 0.7 + (3.0 if kev else min(max(epss or 0.0, 0.0), 1.0) * 3.0) + CRIT.get(criticality, 0.0) + EXPO.get(exposure, 0.0)
    return round(max(0.0, min(10.0, s)), 1)


def priority_label(score):
    return "Act now" if score >= 8.5 else "Act" if score >= 7 else "Attend" if score >= 5 else "Track"


def osv_findings(inventory, agent=None, kev=None, epss=None, http=None, epss_fn=None):
    """Packages in an agent inventory -> findings, ordered by priority. Skips (with an INFO finding) unsupported distros."""
    from af_checks import F
    agent = agent or {}
    kev, epss = kev or set(), epss or {}
    eco = ecosystem_from_os_release(inventory.get("os_release") or {})
    pk = inventory.get("packages") or []
    if not eco:
        return [F("Vulnerability", "OSV Matching Skipped", "SKIPPED", "Info", "distribution not covered by OSV ecosystems", check_id="AF-VULN-osv-skipped")]
    if not pk:
        return [F("Vulnerability", "OSV Matching Skipped", "SKIPPED", "Info", "inventory has no package list (run collect_inventory)", check_id="AF-VULN-osv-skipped")]
    hits = query_packages(pk, eco, http)
    vulns = fetch_vulns([v for ids in hits.values() for v in ids], http)
    if epss_fn:                                           # EPSS needs the CVE ids, which only exist after the OSV lookup
        try:
            all_cves = sorted({c for i in vulns.values() for c in parse_vuln(i)["cves"]})
            epss = {**{c: v[0] for c, v in (epss_fn(all_cves) or {}).items()}, **epss}
        except Exception:
            pass
    out = []
    for idx, ids in hits.items():
        p, parsed = pk[idx], [parse_vuln(vulns[i]) for i in dict.fromkeys(ids) if i in vulns]
        if not parsed:
            continue
        cves = sorted({c for v in parsed for c in v["cves"]})
        cvss = max((v["cvss"] for v in parsed if v["cvss"] is not None), default=None)
        is_kev = any(c in kev for c in cves)
        e = max((epss.get(c, 0.0) for c in cves), default=0.0)
        score = priority_score(cvss, is_kev, e, agent.get("criticality", "medium"), agent.get("exposure", "internal"))
        fixed = sorted({f for v in parsed for f in v["fixed"]})
        sev = max((v["severity"] for v in parsed), key=lambda s: ["Info", "Low", "Medium", "High", "Critical"].index(s))
        out.append((score, F("Vulnerability", f"OSV: {p['name']}", "FAIL", sev,
                             f"{p['name']} {p['version']} ({eco}): {len(parsed)} advisory(ies) {', '.join(v['id'] for v in parsed[:4])}"
                             + (f"; CVEs {', '.join(cves[:5])}" if cves else "") + (f"; fixed in {', '.join(fixed[:3])}" if fixed else "")
                             + f"; priority {score}/10 ({priority_label(score)}{', KEV' if is_kev else ''}, EPSS {e:.2f})",
                             f"Upgrade {p['name']} to a fixed version" + (f" ({fixed[0]})" if fixed else ""), "T1190", check_id="AF-VULN-osv-package")))
    out.sort(key=lambda t: -t[0])
    return [f for _, f in out]
