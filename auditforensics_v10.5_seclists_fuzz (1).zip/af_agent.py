#!/usr/bin/env python3
"""AuditForensics Agent - endpoint collector for the AuditForensics manager.

  AF_ENROLL_TOKEN=<token> python af_agent.py --manager https://MANAGER:8765 --ca-bundle ca.crt \\
        --enroll-url https://MANAGER:8766            # preferred: key is generated here, cert is short-lived and auto-renewed
  python af_agent.py --manager ... --client-cert a.crt --client-key a.key --ca-bundle ca.crt   # legacy mTLS files
Requires af_checks.py next to this file (or use the single-file bundle: python build_agent.py).
Dependencies: requests, psutil (recommended), cryptography (needed for CSR enrollment and signed commands).
"""
import argparse, base64, gzip, json, logging, logging.handlers, os, platform, random, re, shlex, socket, subprocess, sys
import threading, time, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

try:
    import requests
except ImportError:
    sys.exit("pip install requests psutil")
try:
    from af_checks import (Collector, Ctx, F, Skip, NotApplicable, build_triage, check_scap, collect_inventory, ioc_sweep,
                           isolation_plan, kill_process, load_ioc_hashes, quarantine_file, release_plan, run_file_scan,
                           run_local_audit, run_network_scan, run_process_scan, run_service_scan)
except ImportError:
    sys.exit("af_checks.py must be in the same folder as af_agent.py (or deploy the single-file bundle from build_agent.py)")
try:
    from af_version import AGENT_VERSION
except ImportError:
    AGENT_VERSION = "10.5.0"          # keep in sync with af_version.py (tests enforce this)

HEARTBEAT_INTERVAL = 30
POLL_WAIT = 20
MAX_BACKOFF = 300
SPOOL_MAX_FILES = 200
GZIP_OVER = 64 * 1024
CLOCK_SKEW = 300
LIVE_RESPONSE = {"kill_process", "quarantine_file", "isolate_host", "release_isolation"}
log = logging.getLogger("af_agent")


def state_dir():
    return Path(os.environ.get("AF_AGENT_HOME") or (Path.home() / ".af_agent"))


def private_write(path, data, mode=0o600):
    """Atomic, never world-readable (no write-then-chmod window)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    with os.fdopen(fd, "wb") as f:
        f.write(data if isinstance(data, bytes) else data.encode())
    os.replace(tmp, path)
    return path


def setup_logging(log_file=None, verbose=False):
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    if log.handlers:
        return
    fmt = logging.Formatter("%(asctime)sZ %(levelname)s %(message)s", "%Y-%m-%dT%H:%M:%S")
    fmt.converter = time.gmtime
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    log.addHandler(sh)
    try:
        lf = Path(log_file) if log_file else state_dir() / "agent.log"
        lf.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(lf, maxBytes=1_000_000, backupCount=3)
        fh.setFormatter(fmt)
        log.addHandler(fh)
    except OSError:
        pass


# ---------------------------------------------------------------- crypto helpers (cryptography is optional)
def command_message(agent_id, cmd_id, command, params, nonce, issued, expires):
    return json.dumps({"a": agent_id, "i": cmd_id, "c": command, "p": params, "n": nonce, "t": issued, "e": expires},
                      sort_keys=True, separators=(",", ":")).encode()


def verify_signature(pub_pem, sig_b64, msg):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        pub = serialization.load_pem_public_key(pub_pem.encode())
        if not isinstance(pub, Ed25519PublicKey):
            return False
        pub.verify(base64.b64decode(sig_b64), msg)
        return True
    except Exception:
        return False


def make_key_and_csr(cn="af-agent"):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    key = ec.generate_private_key(ec.SECP256R1())
    csr = x509.CertificateSigningRequestBuilder().subject_name(
        x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])).sign(key, hashes.SHA256())
    return (key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()),
            csr.public_bytes(serialization.Encoding.PEM))


def cert_lifetime(pem_path):
    """-> (days_left, total_days) of a PEM certificate file."""
    from cryptography import x509
    c = x509.load_pem_x509_certificate(Path(pem_path).read_bytes())
    now = datetime.now(timezone.utc)
    return (c.not_valid_after_utc - now).total_seconds() / 86400, (c.not_valid_after_utc - c.not_valid_before_utc).total_seconds() / 86400


class CommandRejected(Exception):
    pass


class AuditForensicsAgent:
    def __init__(self, manager_url, enroll_token=None, verify_tls=True, client_cert=None, enroll_url=None,
                 manager_pubkey=None, allow_live_response=None, http=None, ctx=None):
        self.manager_url = manager_url.rstrip("/")
        self.enroll_url = enroll_url.rstrip("/") if enroll_url else None
        self.enroll_token = enroll_token
        self.verify_tls = verify_tls
        self.client_cert = client_cert
        self.http = http or requests.Session()
        self.ctx = ctx or Ctx()
        self.dir = state_dir()
        self.state = {}
        self.agent_id = self.agent_token = None
        self.pinned_pubkey = Path(manager_pubkey).read_text() if manager_pubkey else None
        self.allow_live = (os.environ.get("AF_ALLOW_LIVE_RESPONSE") == "1") if allow_live_response is None else allow_live_response
        self._seen_nonces = []
        self._stop = threading.Event()
        self._fail = 0
        self._current_cmd = None
        self._load_state()

    # ------------------------------------------------------------ state
    @property
    def state_file(self):
        return self.dir / "state.json"

    def _load_state(self):
        try:
            self.state = json.loads(self.state_file.read_text())
        except (OSError, ValueError):
            self.state = {}
        if not self.state.get("agent_uid"):                      # stable identity, independent of any manager/token
            self.state["agent_uid"] = str(uuid.uuid4())
            self._save_state()
        if self.state.get("manager_url") == self.manager_url:
            self.agent_id = self.state.get("agent_id")
            self.agent_token = self.state.get("agent_token")
            if self.state.get("managed_cert") and Path(self.state.get("cert", "")).exists():
                self.client_cert = (self.state["cert"], self.state["key"])
                self.verify_tls = self.state.get("ca") or self.verify_tls
        try:
            self._seen_nonces = json.loads((self.dir / "nonces.json").read_text())[-500:]
        except (OSError, ValueError):
            self._seen_nonces = []

    def _save_state(self):
        private_write(self.state_file, json.dumps(self.state, indent=2))

    @property
    def pubkey(self):
        return self.pinned_pubkey or self.state.get("command_pubkey")

    def _headers(self):
        return {"X-Agent-Token": self.agent_token or ""}

    def _req(self, method, path, base=None, **kw):
        kw.setdefault("timeout", 20)
        kw.setdefault("verify", self.verify_tls)
        if self.client_cert and base is None:
            kw.setdefault("cert", self.client_cert)
        return getattr(self.http, method)((base or self.manager_url) + path, **kw)

    def _get_ip(self):
        """Address used to reach the manager (no packets are sent by a UDP connect)."""
        try:
            host = urlparse(self.manager_url).hostname or "127.0.0.1"
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect((host, 9))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def _identity(self):
        return {"hostname": socket.gethostname(), "os": f"{platform.system()} {platform.release()}", "os_full": platform.platform(),
                "arch": platform.machine(), "version": AGENT_VERSION, "ip": self._get_ip(), "agent_uid": self.state["agent_uid"]}

    # ------------------------------------------------------------ enrollment
    def _adopt(self, d):
        self.agent_id, self.agent_token = d["agent_id"], d["agent_token"]
        self.state.update(agent_id=self.agent_id, agent_token=self.agent_token, manager_url=self.manager_url)
        if d.get("command_pubkey") and not self.pinned_pubkey:
            self.state["command_pubkey"] = d["command_pubkey"]
        self._save_state()

    def register(self):
        """-> 'ok' | 'conflict' | 'denied' | 'error'. Uses CSR enrollment when --enroll-url was given."""
        if not self.enroll_token:
            log.error("no enrollment token available")
            return "denied"
        try:
            if self.enroll_url:
                return self._enroll_csr()
            payload = {"enroll_token": self.enroll_token, **self._identity()}
            r = self._req("post", "/register", json=payload, headers=self._headers() if self.agent_token else {})
            return self._after_register(r)
        except Exception as e:
            log.error("registration failed: %s", e)
            return "error"

    def _after_register(self, r):
        if r.status_code == 409:
            log.error("manager says this agent is already enrolled - an administrator must release it (Agents tab) before it can re-enrol")
            return "conflict"
        if r.status_code in (403, 429):
            log.error("registration refused (%s): %s", r.status_code, r.text[:120])
            return "denied"
        r.raise_for_status()
        self._adopt(r.json())
        log.info("registered as agent %s", self.agent_id)
        return "ok"

    def _enroll_csr(self):
        keyp, csr = make_key_and_csr()
        pki = self.dir / "pki"
        private_write(pki / "agent.key", keyp)                          # key is created here and never leaves the host
        r = self._req("post", "/enroll", base=self.enroll_url, json={"enroll_token": self.enroll_token, "csr_pem": csr.decode(), **self._identity()})
        if r.status_code in (409, 403, 429, 400, 503):
            return self._after_register(r) if r.status_code in (409, 403, 429) else self._log_fail(r)
        r.raise_for_status()
        d = r.json()
        private_write(pki / "agent.crt", d["cert_pem"], 0o644)
        private_write(pki / "ca.crt", d["ca_pem"], 0o644)
        self.client_cert, self.verify_tls = (str(pki / "agent.crt"), str(pki / "agent.key")), str(pki / "ca.crt")
        self.state.update(managed_cert=True, cert=str(pki / "agent.crt"), key=str(pki / "agent.key"), ca=str(pki / "ca.crt"))
        self._adopt(d)
        log.info("enrolled with a short-lived client certificate; agent %s", self.agent_id)
        return "ok"

    def _log_fail(self, r):
        log.error("enrollment rejected (%s): %s", r.status_code, r.text[:160])
        return "denied"

    def maybe_renew_cert(self, force=False):
        if not self.state.get("managed_cert"):
            return False
        try:
            left, total = cert_lifetime(self.state["cert"])
        except Exception as e:
            log.warning("cannot read agent certificate: %s", e)
            return False
        if not force and left > total / 3:
            return False
        keyp, csr = make_key_and_csr()
        r = self._req("post", "/pki/renew", json={"csr_pem": csr.decode()}, headers=self._headers())
        if r.status_code != 200:
            log.error("certificate renewal failed (%s): %s", r.status_code, r.text[:120])
            return False
        d = r.json()
        pki = Path(self.state["cert"]).parent
        # swap in one step: new key first under a temp name, then both files
        private_write(pki / "agent.key.new", keyp)
        private_write(pki / "agent.crt.new", d["cert_pem"], 0o644)
        os.replace(pki / "agent.key.new", pki / "agent.key")
        os.replace(pki / "agent.crt.new", pki / "agent.crt")
        if d.get("ca_pem"):
            private_write(pki / "ca.crt", d["ca_pem"], 0o644)
        log.info("client certificate renewed (%.1f of %.0f days were left)", left, total)
        return True

    # ------------------------------------------------------------ liveness
    def heartbeat(self):
        try:
            r = self._req("post", "/heartbeat", json=self._vitals(), headers=self._headers(), timeout=10)
            if r.status_code == 401:
                log.warning("manager rejected the agent token (401)")
            return r.status_code == 200
        except Exception:
            return False

    def _vitals(self):
        v = {"cpu": 0.0, "memory": 0.0, "disk": 0.0, "uptime": 0}
        ps = self.ctx.psutil
        if ps:
            try:
                v.update(cpu=ps.cpu_percent(interval=0.5), memory=ps.virtual_memory().percent, disk=ps.disk_usage("/").percent,
                         uptime=int(time.time() - ps.boot_time()))
            except Exception:
                pass
        return v

    def _heartbeat_thread(self):
        while not self._stop.wait(HEARTBEAT_INTERVAL):            # keeps the command lease alive during long scans
            self.heartbeat()

    # ------------------------------------------------------------ command authenticity
    def verify_command(self, cmd):
        pub = self.pubkey
        if not pub:
            if not getattr(self, "_warned_unsigned", False):
                log.warning("no manager public key known: commands are NOT being signature-checked (pin one with --manager-pubkey)")
                self._warned_unsigned = True
            return
        if not cmd.get("sig"):
            raise CommandRejected("unsigned command")
        try:
            msg = command_message(self.agent_id, cmd["id"], cmd["command"], cmd.get("params") or {}, cmd["nonce"], cmd["issued"], cmd["expires"])
        except KeyError as e:
            raise CommandRejected(f"missing field {e}")
        try:
            ok = verify_signature(pub, cmd["sig"], msg)
        except ImportError:
            raise CommandRejected("cryptography package missing: cannot verify signed commands")
        if not ok:
            raise CommandRejected("bad signature")
        now = datetime.now(timezone.utc)
        try:
            issued, expires = datetime.fromisoformat(cmd["issued"]), datetime.fromisoformat(cmd["expires"])
        except ValueError:
            raise CommandRejected("bad timestamps")
        if now > expires:
            raise CommandRejected("expired")
        if issued > now + timedelta(seconds=CLOCK_SKEW):
            raise CommandRejected("issued in the future (clock skew?)")
        if cmd["nonce"] in self._seen_nonces:
            raise CommandRejected("replayed nonce")
        self._seen_nonces = (self._seen_nonces + [cmd["nonce"]])[-500:]
        try:
            private_write(self.dir / "nonces.json", json.dumps(self._seen_nonces))
        except OSError:
            pass

    # ------------------------------------------------------------ execution
    def _ioc(self):
        return load_ioc_hashes(str(self.dir / "ioc_sha256.txt"))

    def execute(self, cmd):
        """-> dict(status, summary, findings, inventory, coverage). Never raises."""
        name, params = cmd["command"], cmd.get("params") or {}
        started = time.time()
        try:
            self.verify_command(cmd)
            if name in LIVE_RESPONSE and not self.allow_live:
                raise CommandRejected("live response is disabled on this agent (start it with --allow-live-response)")
            findings, cov, inv, summary = self._dispatch(name, params)
            return {"status": "done", "summary": f"{summary} in {time.time() - started:.1f}s", "findings": findings,
                    "inventory": inv, "coverage": cov}
        except CommandRejected as e:
            log.error("command %s (%s) rejected: %s", cmd.get("id"), name, e)
            return {"status": "failed", "summary": f"rejected by agent: {e}", "findings": [], "inventory": {}, "coverage": {}}
        except Exception as e:
            log.exception("command %s failed", name)
            return {"status": "failed", "summary": f"{type(e).__name__}: {str(e)[:200]}", "findings": [], "inventory": {}, "coverage": {}}

    def _dispatch(self, name, p):
        ctx, inv = self.ctx, {}
        if name == "ping":
            f = [F("Agent", "Ping", "PASS", "Info", f"pong from {socket.gethostname()} v{AGENT_VERSION}")]
            return f, {"run": 1}, inv, "pong"
        if name == "collect_inventory":
            inv = collect_inventory(ctx, self._get_ip())
            return [], {"run": 1}, inv, f"inventory ({len(inv['packages'])} packages)"
        if name == "run_local_audit":
            c = run_local_audit(ctx, self._ioc())
            return c.findings, c.coverage(), inv, c.summary()
        if name == "run_network_scan":
            c = run_network_scan(ctx)
            return c.findings, c.coverage(), inv, c.summary()
        if name == "run_process_scan":
            c = run_process_scan(ctx, self._ioc())
            return c.findings, c.coverage(), inv, c.summary()
        if name == "run_service_scan":
            c = run_service_scan(ctx)
            return c.findings, c.coverage(), inv, c.summary()
        if name == "run_file_scan":
            c = run_file_scan(ctx, p.get("paths") or None, self._ioc())
            return c.findings, c.coverage(), inv, c.summary()
        if name == "run_ioc_sweep":
            c = Collector().run("ioc_sweep", ioc_sweep, ctx, p.get("paths") or [], p.get("sha256") or [], p.get("yara") or "")
            return c.findings, c.coverage(), inv, c.summary()
        if name == "run_scap":
            c = Collector().run("scap", check_scap, ctx, p.get("profile", ""), p.get("datastream", ""))
            return c.findings, c.coverage(), inv, c.summary()
        if name == "collect_triage":
            return self._triage(bool(p.get("upload", True)))
        if name == "kill_process":
            info = kill_process(ctx.psutil, int(p["pid"]), p.get("name", ""), protected_pids=(os.getpid(), os.getppid()))
            return [F("Live Response", "Process Killed", "INFO", "Info", f"PID {info['pid']} {info['name']} ({info['exe']})")], {"run": 1}, inv, "killed"
        if name == "quarantine_file":
            m = quarantine_file(p["path"], self.dir / "quarantine")
            return [F("Live Response", "File Quarantined", "INFO", "Info", f"{m['original_path']} -> sha256 {m['sha256']}", sha256=m["sha256"])], {"run": 1}, inv, "quarantined"
        if name == "isolate_host":
            return self._isolate(int(p.get("ttl_minutes", 60)))
        if name == "release_isolation":
            return self._release_isolation()
        raise CommandRejected(f"unknown command {name}")

    def _triage(self, upload):
        host = socket.gethostname()
        zp, man = build_triage(self.ctx, self.dir / "triage", host, AGENT_VERSION)
        details = f"{len(man['entries'])} artifacts, {man['archive_bytes']} bytes, sha256 {man['archive_sha256']}, kept at {zp}"
        status = "INFO"
        if upload:
            ok, msg = self._upload_artifact(zp, man["archive_sha256"])
            details += f"; upload {'ok' if ok else 'FAILED: ' + msg}"
            status = "INFO" if ok else "WARNING"
        light = {k: v for k, v in man.items() if k != "entries"}
        light["entry_count"] = len(man["entries"])
        return ([F("Forensics", "Triage Package Collected", status, "Info", details, sha256=man["archive_sha256"])] +
                [F("Forensics", "Triage Collection Error", "WARNING", "Info", e) for e in man["errors"][:20]],
                {"run": 1, "errors": len(man["errors"])}, {"triage": light}, f"triage {man['archive_bytes']} bytes")

    def _upload_artifact(self, zp, sha, cmd_id=None):
        cid = cmd_id or self._current_cmd
        try:
            with open(zp, "rb") as fh:
                r = self._req("post", f"/artifacts/{cid}", data=fh, headers={**self._headers(), "X-Content-SHA256": sha,
                                                                              "Content-Type": "application/zip"}, timeout=600)
            return (r.status_code == 200, f"HTTP {r.status_code} {r.text[:80]}")
        except Exception as e:
            return False, str(e)[:100]

    # ---- isolation (agent-side opt-in, auto-expiring)
    def _manager_ips(self):
        ips = set()
        for u in (self.manager_url, self.enroll_url):
            if not u:
                continue
            try:
                for ai in socket.getaddrinfo(urlparse(u).hostname, None):
                    ips.add(ai[4][0])
            except OSError:
                pass
        return sorted(ips)

    def _run_plan(self, plan):
        errs = []
        for c in plan:
            o, rc = self.ctx.run(c, 20)
            if rc != 0:
                errs.append(f"{' '.join(c)} -> rc={rc} {o[:80]}")
        return errs

    def _isolate(self, ttl):
        plan = isolation_plan(self.ctx.system, self._manager_ips())      # raises if the manager address is unknown
        expires = (datetime.now(timezone.utc) + timedelta(minutes=ttl)).isoformat(timespec="seconds")
        private_write(self.dir / "isolation.json", json.dumps({"expires": expires, "system": self.ctx.system}))   # written BEFORE changing the firewall
        errs = self._run_plan(plan)
        if errs:
            self._run_plan(release_plan(self.ctx.system))                 # failed halfway: roll back
            (self.dir / "isolation.json").unlink(missing_ok=True)
            raise RuntimeError("isolation failed and was rolled back: " + "; ".join(errs[:2]))
        return ([F("Live Response", "Host Isolated", "WARNING", "Info", f"Only {', '.join(self._manager_ips())} reachable; auto-release at {expires}")],
                {"run": 1}, {}, f"isolated until {expires}")

    def _release_isolation(self):
        errs = self._run_plan(release_plan(self.ctx.system))
        (self.dir / "isolation.json").unlink(missing_ok=True)
        return [F("Live Response", "Isolation Released", "INFO", "Info", "; ".join(errs[:2]) or "firewall rules removed")], {"run": 1}, {}, "released"

    def isolation_watchdog(self):
        """Auto-release an expired isolation (also after a reboot) so a lost manager can never strand a host."""
        p = self.dir / "isolation.json"
        try:
            d = json.loads(p.read_text())
            if datetime.now(timezone.utc) >= datetime.fromisoformat(d["expires"]):
                log.warning("isolation TTL expired: releasing")
                self._release_isolation()
        except (OSError, ValueError, KeyError):
            pass

    # ------------------------------------------------------------ results: retry, spool, gzip
    def _post_result(self, payload):
        body = json.dumps(payload).encode()
        headers = {**self._headers(), "Content-Type": "application/json"}
        if len(body) > GZIP_OVER:
            body, headers["Content-Encoding"] = gzip.compress(body), "gzip"
        return self._req("post", "/results", data=body, headers=headers, timeout=120)

    def send_result(self, cmd_id, res):
        payload = {"command_id": cmd_id, "status": res["status"], "summary": res["summary"], "findings": res["findings"],
                   "inventory": res["inventory"], "coverage": res["coverage"], "result_id": uuid.uuid4().hex}
        if not self._try_send(payload):
            self._spool(payload)

    def _try_send(self, payload, attempts=3):
        """True when delivered OR permanently rejected (retrying cannot help); False to keep and retry later."""
        for i in range(attempts):
            try:
                r = self._post_result(payload)
                if r.status_code == 200:
                    return True
                if r.status_code in (400, 401, 403, 404, 409, 413, 422):
                    log.error("manager rejected result for command %s (%s): %s - dropping", payload["command_id"], r.status_code, r.text[:100])
                    return True
                log.warning("upload attempt %d failed: HTTP %s", i + 1, r.status_code)
            except Exception as e:
                log.warning("upload attempt %d failed: %s", i + 1, e)
            time.sleep(min(2 ** (i + 1), 8) + random.random())
        return False

    def _spool(self, payload):
        sp = self.dir / "spool"
        files = sorted(sp.glob("*.json.gz")) if sp.exists() else []
        for old in files[:max(0, len(files) - SPOOL_MAX_FILES + 1)]:
            old.unlink(missing_ok=True)
        private_write(sp / f"{int(time.time())}_{payload['result_id']}.json.gz", gzip.compress(json.dumps(payload).encode()))
        log.warning("manager unreachable: result for command %s spooled for retry", payload["command_id"])

    def flush_spool(self):
        sp = self.dir / "spool"
        if not sp.exists():
            return 0
        n = 0
        for f in sorted(sp.glob("*.json.gz")):
            try:
                payload = json.loads(gzip.decompress(f.read_bytes()))
            except (OSError, ValueError):
                f.unlink(missing_ok=True)
                continue
            if self._try_send(payload, attempts=1):
                f.unlink(missing_ok=True)
                n += 1
            else:
                break                                                       # still offline: keep order, retry next round
        return n

    # ------------------------------------------------------------ main loop
    def poll(self):
        r = self._req("get", f"/commands?wait={POLL_WAIT}", headers=self._headers(), timeout=POLL_WAIT + 15)
        if r.status_code == 401:
            raise PermissionError("token rejected")
        r.raise_for_status()
        return r.json().get("commands", [])

    def step(self):
        """One loop iteration. Returns seconds to sleep before the next one."""
        self.isolation_watchdog()
        if not self.agent_token:
            res = self.register()
            if res != "ok":
                self._fail += 1
                return self._backoff()
            self._fail = 0
        self.flush_spool()
        try:
            self.maybe_renew_cert()
            cmds = self.poll()
            self._fail = 0
        except PermissionError:
            log.warning("agent token no longer accepted; trying to re-enrol (needs an administrator release)")
            self.agent_token = None
            self._fail += 1
            return self._backoff()
        except Exception as e:
            self._fail += 1
            log.warning("poll failed: %s", e)
            return self._backoff()
        for cmd in cmds:
            self._current_cmd = cmd["id"]
            log.info("executing command %s: %s", cmd["id"], cmd["command"])
            self.send_result(cmd["id"], self.execute(cmd))
        return 0.5 + random.random() if not cmds else 1

    def _backoff(self):
        return min(MAX_BACKOFF, 5 * 2 ** min(self._fail, 6)) * (0.7 + 0.6 * random.random())

    def run_loop(self):
        log.info("AuditForensics agent %s (%s) -> %s", AGENT_VERSION, platform.system(), self.manager_url)
        threading.Thread(target=self._heartbeat_thread, daemon=True).start()
        while True:                                                         # registration failures back off, never exit
            try:
                time.sleep(self.step())
            except KeyboardInterrupt:
                self._stop.set()
                log.info("stopping")
                return


# ---------------------------------------------------------------- service installation
def _self_path():
    """Path to run in the service definition: the .pyz bundle when bundled, otherwise this file."""
    a = Path(sys.argv[0]).resolve()
    return a if a.suffix == ".pyz" else Path(__file__).resolve()


def agent_args(a):
    """CLI arguments that must survive into the service definition (never the enrollment token)."""
    out = ["--manager", a.manager]
    for flag, val in (("--ca-bundle", a.ca_bundle), ("--client-cert", a.client_cert), ("--client-key", a.client_key),
                      ("--enroll-url", a.enroll_url), ("--manager-pubkey", a.manager_pubkey)):
        if val:
            out += [flag, str(Path(val).resolve())]
    if a.no_verify_tls:
        out.append("--no-verify-tls")
    if a.allow_live_response:
        out.append("--allow-live-response")
    return out


def render_systemd_unit(py, script, args, env_path, workdir, state_dir_path="/var/lib/af_agent"):
    cmd = shlex.join([py, str(script)] + list(args))
    return f"""[Unit]
Description=AuditForensics Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile={env_path}
Environment=AF_AGENT_HOME={state_dir_path}
ExecStart={cmd}
Restart=always
RestartSec=10
User=root
UMask=0077
WorkingDirectory={workdir}
StateDirectory=af_agent
StateDirectoryMode=0700
# Hardening. The agent must still read most of the system and (for live response) signal processes and edit
# firewall rules, so it keeps only the capabilities it needs. PrivateTmp is intentionally NOT set: it would hide
# the real /tmp from the file scan.
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=read-only
ProtectKernelModules=true
ProtectKernelTunables=true
ProtectControlGroups=true
ProtectClock=true
ProtectHostname=true
RestrictSUIDSGID=true
RestrictNamespaces=true
LockPersonality=true
SystemCallArchitectures=native
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX AF_NETLINK
CapabilityBoundingSet=CAP_DAC_READ_SEARCH CAP_DAC_OVERRIDE CAP_FOWNER CAP_KILL CAP_SYS_PTRACE CAP_NET_ADMIN CAP_NET_RAW CAP_CHOWN
AmbientCapabilities=

[Install]
WantedBy=multi-user.target
"""


def install_service(a, enroll_token):
    """Install as a service. The enrollment token stays OUT of the unit file / plist / command line (those are
    world-readable or visible in `ps`); every other option (TLS files, enroll URL, pinned key) is persisted."""
    script_path, py, args = _self_path(), sys.executable, agent_args(a)
    system = platform.system()
    if system == "Linux":
        env_path = "/etc/af_agent.env"
        svc = render_systemd_unit(py, script_path, args, env_path, script_path.parent)
        try:
            subprocess.run(["sudo", "sh", "-c", f"umask 077; cat > {env_path}"], input=f"AF_ENROLL_TOKEN={enroll_token}\n", text=True, check=True, capture_output=True)
            subprocess.run(["sudo", "chmod", "600", env_path], check=True)
            subprocess.run(["sudo", "tee", "/etc/systemd/system/af_agent.service"], input=svc, text=True, check=True, capture_output=True)
            subprocess.run(["sudo", "systemctl", "daemon-reload"], check=True)
            subprocess.run(["sudo", "systemctl", "enable", "--now", "af_agent"], check=True)
            print(f"[+] Service installed and started (token in {env_path}, mode 600). Options kept: {' '.join(args)}")
        except Exception as e:
            print(f"[!] Failed: {e}")
    elif system == "Darwin":
        import plistlib
        logdir = Path.home() / "Library/Logs"
        logdir.mkdir(parents=True, exist_ok=True)
        pl = {"Label": "com.auditforensics.agent", "ProgramArguments": [py, str(script_path)] + args,
              "EnvironmentVariables": {"AF_ENROLL_TOKEN": enroll_token}, "RunAtLoad": True, "KeepAlive": True,
              "StandardOutPath": str(logdir / "af_agent.log"), "StandardErrorPath": str(logdir / "af_agent.err")}
        dest = Path.home() / "Library/LaunchAgents/com.auditforensics.agent.plist"
        private_write(dest, plistlib.dumps(pl))
        subprocess.run(["launchctl", "load", str(dest)])
        print(f"[+] LaunchAgent installed: {dest} (mode 600)")
    elif system == "Windows":
        quoted = subprocess.list2cmdline([str(script_path)] + args)
        print("[*] Windows: use NSSM so the token stays out of the service ImagePath:")
        print(f'    nssm install AuditForensicsAgent "{py}" {quoted}')
        print("    nssm set AuditForensicsAgent AppEnvironmentExtra AF_ENROLL_TOKEN=<token>")
        print("    nssm start AuditForensicsAgent")


def main(argv=None):
    p = argparse.ArgumentParser(description="AuditForensics Agent")
    p.add_argument("--manager", help="Manager URL (e.g. https://10.0.0.5:8765)")
    p.add_argument("--token", help="Enrollment token (prefer the AF_ENROLL_TOKEN environment variable)")
    p.add_argument("--enroll-url", help="Bootstrap URL for CSR enrollment (e.g. https://10.0.0.5:8766)")
    p.add_argument("--no-verify-tls", action="store_true")
    p.add_argument("--client-cert", help="client certificate (PEM) for mutual TLS")
    p.add_argument("--client-key", help="client private key (PEM) for mutual TLS")
    p.add_argument("--ca-bundle", help="CA certificate/bundle to trust (self-signed https manager)")
    p.add_argument("--manager-pubkey", help="pin the manager's command-signing public key (PEM file)")
    p.add_argument("--allow-live-response", action="store_true", help="permit kill/quarantine/isolate commands (also AF_ALLOW_LIVE_RESPONSE=1)")
    p.add_argument("--install-service", action="store_true")
    p.add_argument("--once", action="store_true")
    p.add_argument("--log-file")
    p.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args(argv)
    setup_logging(a.log_file, a.verbose)
    a.token = a.token or os.environ.get("AF_ENROLL_TOKEN")
    if not a.manager:
        print("Usage: AF_ENROLL_TOKEN=<token> python af_agent.py --manager URL [--ca-bundle ca.crt] [--enroll-url URL]")
        sys.exit(1)
    if a.manager.startswith("http://") and not re.match(r"http://(127\.|localhost)", a.manager):
        print("WARNING: manager URL is plain HTTP - the enrollment token and findings cross the network "
              "unencrypted. Use HTTPS (AF_TLS_CERT/AF_TLS_KEY on the manager, --ca-bundle here).", file=sys.stderr)
    if a.install_service:
        if not a.token:
            sys.exit("set AF_ENROLL_TOKEN to install the service")
        install_service(a, a.token)
        return
    agent = AuditForensicsAgent(a.manager, a.token, verify_tls=(a.ca_bundle or not a.no_verify_tls),
                                client_cert=((a.client_cert, a.client_key) if a.client_cert and a.client_key else None),
                                enroll_url=a.enroll_url, manager_pubkey=a.manager_pubkey, allow_live_response=a.allow_live_response or None)
    if a.once:
        if not agent.agent_token:
            sys.exit(0 if agent.register() == "ok" else 1)
        agent.heartbeat()
        return
    agent.run_loop()


if __name__ == "__main__":
    main()
