#!/usr/bin/env python3
"""Network discovery orchestration: phases, optional nmap enrichment, traceroute, CVE matching, persistence, jobs.

``NetJob`` re-checks the scope policy itself (defence in depth: a caller that forgot the UI gate still cannot scan a
forbidden or unauthorised target), runs in a background thread, reports progress and can be cancelled.
"""
import hashlib, ipaddress, json, os, re, shutil, sqlite3, subprocess, threading, time, traceback, uuid
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import af_netintel as I
import af_netmap as N
import af_oui, af_scope
from af_util import utc_iso

try:
    import af_vault
except Exception:                                                  # pragma: no cover
    af_vault = None
DB_PATH = Path(os.environ.get("AF_DB_PATH") or (Path.home() / ".auditforensics" / "history.db"))


# ---------------------------------------------------------------- traceroute
def parse_traceroute(text):
    """traceroute -n / tracepath / tracert -d output -> [hop ip or '*']."""
    hops = []
    for ln in text.splitlines():
        if not re.match(r"^\s*\d+[:\s]", ln):
            continue
        m = re.search(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", ln.split(None, 1)[1] if len(ln.split(None, 1)) > 1 else "")
        hops.append(m.group(1) if m else "*")
    return hops


def traceroute(ip, run=None, max_hops=12):
    if not re.fullmatch(r"[0-9a-fA-F:.]+", ip):
        return []
    sysname = os.name
    cmd = (["tracert", "-d", "-h", str(max_hops), "-w", "500", ip] if sysname == "nt" else
           ["traceroute", "-n", "-q", "1", "-w", "1", "-m", str(max_hops), ip] if shutil.which("traceroute") else
           ["tracepath", "-n", "-m", str(max_hops), ip] if shutil.which("tracepath") else None)
    if not cmd and not run:
        return []
    try:
        out = (run or (lambda c: subprocess.run(c, capture_output=True, text=True, timeout=max_hops * 3 + 10).stdout))(cmd)
    except (OSError, subprocess.SubprocessError):
        return []
    return parse_traceroute(out)


# ---------------------------------------------------------------- nmap (optional engine for sharper fingerprints)
NMAP_KEYS = [("openssh", "openssh"), ("apache httpd", "apache"), ("apache tomcat", "tomcat"), ("nginx", "nginx"), ("microsoft iis", "iis"), ("lighttpd", "lighttpd"),
             ("haproxy", "haproxy"), ("squid", "squid"), ("proftpd", "proftpd"), ("vsftpd", "vsftpd"), ("pure-ftpd", "pure-ftpd"), ("postfix", "postfix"),
             ("exim", "exim"), ("dovecot", "dovecot"), ("mysql", "mysql"), ("mariadb", "mariadb"), ("postgresql", "postgresql"), ("redis", "redis"),
             ("mongodb", "mongodb"), ("elasticsearch", "elasticsearch"), ("samba", "samba"), ("isc bind", "bind"), ("dnsmasq", "dnsmasq"), ("openssl", "openssl"),
             ("php", "php"), ("jetty", "jetty"), ("node.js", "nodejs"), ("memcached", "memcached"), ("openvpn", "openvpn"), ("dropbear", "dropbear")]


def nmap_available():
    return bool(shutil.which("nmap"))


def parse_nmap_xml(xml_text):
    """nmap -oX output -> {ip: {mac, vendor, hostnames, os:[(name, accuracy)], ports:[{port, proto, state, name, product, version, cpe, extra}]}}"""
    if re.search(r"<!ENTITY", xml_text, re.I):
        raise ValueError("refusing nmap XML with entity declarations")
    root = ET.fromstring(xml_text)  # nosec B314 - entity declarations rejected above; this is the output of our own nmap run
    out = {}
    for h in root.iter("host"):
        st = h.find("status")
        if st is not None and st.get("state") != "up":
            continue
        ip = mac = vendor = ""
        for a in h.findall("address"):
            if a.get("addrtype") in ("ipv4", "ipv6"):
                ip = a.get("addr")
            elif a.get("addrtype") == "mac":
                mac, vendor = a.get("addr", "").lower(), a.get("vendor", "")
        if not ip:
            continue
        d = {"mac": mac, "vendor": vendor, "hostnames": [x.get("name") for x in h.iter("hostname") if x.get("name")], "os": [], "ports": [], "uptime": ""}
        for m in h.iter("osmatch"):
            d["os"].append((m.get("name", ""), int(m.get("accuracy", 0))))
        up = h.find("uptime")
        if up is not None:
            d["uptime"] = up.get("lastboot", "")
        for p in h.iter("port"):
            state = p.find("state")
            sv = p.find("service")
            d["ports"].append({"port": int(p.get("portid")), "proto": p.get("protocol", "tcp"), "state": state.get("state") if state is not None else "",
                               "name": sv.get("name", "") if sv is not None else "", "product": sv.get("product", "") if sv is not None else "",
                               "version": sv.get("version", "") if sv is not None else "", "extra": sv.get("extrainfo", "") if sv is not None else "",
                               "ostype": sv.get("ostype", "") if sv is not None else "", "cpe": [c.text for c in p.iter("cpe") if c.text]})
        out[ip] = d
    return out


def merge_nmap(dev, info):
    """Fold nmap's service/OS results into a device: fill gaps and upgrade empty versions, never discard our own evidence."""
    for np_ in info.get("ports", []):
        if np_["state"] != "open" or np_["proto"] != "tcp":
            continue
        s = next((x for x in dev["services"] if x["port"] == np_["port"]), None)
        if s is None:
            continue
        if np_["product"] and not s.get("product_key"):
            s["product"] = np_["product"]
            low = np_["product"].lower()
            s["product_key"] = next((k for pat, k in NMAP_KEYS if pat in low), "")
        if np_["version"] and not s.get("version"):
            v = re.match(r"[\d.]+[\w.]*", np_["version"])
            s["version"] = v.group(0) if v else np_["version"]
        if np_["name"] and not s.get("name"):
            s["name"] = np_["name"]
        if np_["extra"] or np_["ostype"]:
            s["os_hints"] = sorted(set(s.get("os_hints", [])) | set(N.os_hints_from(np_["extra"] + " " + np_["ostype"])))
        s["nmap"] = True
    if info.get("os"):
        dev["nmap_os"] = info["os"][:3]
        dev["os_hints"] = sorted(set(dev.get("os_hints", [])) | set(N.os_hints_from(info["os"][0][0])))
    if info.get("mac") and not dev.get("mac"):
        dev["mac"], dev["vendor"] = info["mac"], info.get("vendor", "") or af_oui.lookup(info["mac"])
    return dev


def nmap_enrich(dev, cfg, run=None, cancel=None):
    ports = [s["port"] for s in dev["services"] if s.get("state") == "open"]
    if not ports or (cancel and cancel()):
        return "no open ports"
    cmd = ["nmap", "-Pn", "-sV", "--version-intensity", "5", "-O", "--osscan-limit", "-p", ",".join(map(str, ports[:1000])), "-oX", "-", dev["ip"]]
    try:
        r = (run or (lambda c: subprocess.run(c, capture_output=True, text=True, timeout=300)))(cmd)
    except (OSError, subprocess.SubprocessError) as e:
        return f"nmap failed: {type(e).__name__}"
    out = r.stdout if hasattr(r, "stdout") else r
    if not out or "<nmaprun" not in out:
        return "nmap produced no XML (OS detection needs root)"
    info = parse_nmap_xml(out).get(dev["ip"])
    if info:
        merge_nmap(dev, info)
    return "ok"


# ---------------------------------------------------------------- persistence
def init_db(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS net_scans (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, targets_key TEXT, targets TEXT, profile TEXT,
        duration REAL, hosts INTEGER, open_ports INTEGER, cves INTEGER, username TEXT, auth_id INTEGER, devices_json TEXT, meta TEXT)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS net_assets (asset_key TEXT PRIMARY KEY, ip TEXT, mac TEXT, name TEXT, vendor TEXT, os TEXT, dtype TEXT,
        first_seen TEXT, last_seen TEXT, last_scan_id INTEGER, scans_seen INTEGER DEFAULT 1, services_json TEXT)""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_netscans_key ON net_scans(targets_key)")


def _enc(s, col, ctx):
    return af_vault.encrypt_text(s, af_vault.aad_for(col.split(".")[0], col.split(".")[1], ctx)) if af_vault else s


def _dec(s, col, ctx):
    return af_vault.decrypt_text(s, af_vault.aad_for(col.split(".")[0], col.split(".")[1], ctx)) if af_vault else s


def targets_key(targets):
    return hashlib.sha256("\n".join(sorted(t.strip() for t in targets)).encode()).hexdigest()[:16]


def save_scan(conn, result, username="", auth_id=None):
    init_db(conn)
    m, ts = result["meta"], result["meta"]["finished"]
    cur = conn.execute("INSERT INTO net_scans (timestamp,targets_key,targets,profile,duration,hosts,open_ports,cves,username,auth_id,devices_json,meta) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                       (ts, targets_key(m["targets"]), json.dumps(m["targets"]), m["profile"], m["duration"], len(result["devices"]),
                        sum(len(I._open(d)) for d in result["devices"]), sum(len(d.get("cves", [])) for d in result["devices"]), username, auth_id,
                        _enc(json.dumps({"devices": result["devices"], "topology": result.get("topology")}, default=str), "net_scans.devices_json", ts),
                        json.dumps({k: v for k, v in m.items() if k != "targets"}, default=str)))
    sid = cur.lastrowid
    for d in result["devices"]:
        key = (d.get("mac") or d["ip"]).lower()
        row = conn.execute("SELECT first_seen, scans_seen FROM net_assets WHERE asset_key=?", (key,)).fetchone()
        svc = json.dumps([{k: s.get(k) for k in ("port", "proto", "name", "product", "version")} for s in d.get("services", []) + d.get("udp", []) if s.get("state") == "open"])
        conn.execute("INSERT OR REPLACE INTO net_assets (asset_key,ip,mac,name,vendor,os,dtype,first_seen,last_seen,last_scan_id,scans_seen,services_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                     (key, d["ip"], d.get("mac", ""), d.get("name", ""), d.get("vendor", ""), d.get("os", ""), d.get("dtype", ""), row[0] if row else ts, ts, sid,
                      (row[1] + 1) if row else 1, _enc(svc, "net_assets.services_json", key)))
    conn.commit()
    return sid


def load_scan(conn, sid):
    r = conn.execute("SELECT * FROM net_scans WHERE id=?", (sid,)).fetchone()
    if not r:
        return None
    cols = [c[0] for c in conn.execute("SELECT * FROM net_scans LIMIT 0").description]
    row = dict(zip(cols, r))
    blob = json.loads(_dec(row["devices_json"], "net_scans.devices_json", row["timestamp"]))
    return {"id": sid, "meta": {**json.loads(row["meta"] or "{}"), "targets": json.loads(row["targets"]), "finished": row["timestamp"], "profile": row["profile"]},
            "devices": blob["devices"], "topology": blob.get("topology")}


def previous_scan(conn, targets, before_id=None):
    init_db(conn)
    r = conn.execute("SELECT id FROM net_scans WHERE targets_key=? AND (? IS NULL OR id<?) ORDER BY id DESC LIMIT 1", (targets_key(targets), before_id, before_id)).fetchone()
    return load_scan(conn, r[0]) if r else None


def list_scans(conn, limit=50):
    init_db(conn)
    cur = conn.execute("SELECT id,timestamp,targets,profile,duration,hosts,open_ports,cves,username FROM net_scans ORDER BY id DESC LIMIT ?", (int(limit),))
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def list_assets(conn):
    init_db(conn)
    cur = conn.execute("SELECT asset_key,ip,mac,name,vendor,os,dtype,first_seen,last_seen,scans_seen FROM net_assets ORDER BY last_seen DESC")
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


# ---------------------------------------------------------------- the scan
def _name_lookups(devices, cfg, cancel):
    """Reverse DNS + NetBIOS node status (+ SSDP/mDNS broadcasts) -> names, MACs, device advertisements."""
    by_ip = {d["ip"]: d for d in devices}
    if cfg.reverse_dns:
        def rdns(ip):
            try:
                return ip, N.socket.gethostbyaddr(ip)[0]
            except (OSError, UnicodeError):
                return ip, ""
        with ThreadPoolExecutor(max_workers=32) as ex:
            for ip, name in ex.map(rdns, list(by_ip)):
                if name and name != ip:
                    by_ip[ip]["hostnames"].append(name); by_ip[ip]["names"]["dns"] = name
    if cfg.netbios:
        def nb(ip):
            st, data = N.udp_probe(ip, 137, "nbns", 1.0)
            return ip, N.parse_nbstat(data) if st == "open" else None
        with ThreadPoolExecutor(max_workers=32) as ex:
            for ip, r in ex.map(nb, list(by_ip)):
                if r and r["names"]:
                    d = by_ip[ip]
                    d["netbios"] = r
                    d["names"]["netbios"] = next((n for n, suf, grp in r["names"] if suf == 0 and not grp), r["names"][0][0])
                    d["notes"].append("answers NetBIOS node status")
                    if r["mac"] and not d["mac"]:
                        d["mac"] = r["mac"]; d["vendor"], d["mac_note"] = af_oui.describe(r["mac"])
    if cfg.broadcast and not (cancel and cancel()):
        for ip, info in N.broadcast_discovery(3.0).items():
            d = by_ip.get(ip)
            if not d:
                continue
            if info.get("ssdp"):
                d["ssdp_server"] = info["ssdp"].get("server", "")
                d["names"]["ssdp"] = info["ssdp"].get("server", "")[:60]
                d["discovered_by"].append("ssdp")
            if info.get("mdns"):
                d["names"]["mdns"] = sorted(set(info["mdns"]))[0][:60]
                d["discovered_by"].append("mdns")
    for d in devices:
        d["hostnames"] = list(dict.fromkeys(d["hostnames"] + [v for k, v in d["names"].items() if k in ("netbios", "mdns") and v]))


def run_scan(targets, cfg, progress=None, cancel=None, cve_fn=None, conn=None, username="", auth_id=None, run=None, log=None):
    """Full network scan. ``progress(pct, message)``. ``cve_fn(devices, progress)`` fills device['cves'].
    Returns {'meta','devices','topology','diff','findings','stats'}."""
    t0, started = time.time(), utc_iso()
    log = log or (lambda m: None)
    prog = progress or (lambda p, m: None)
    N.raise_nofile()
    ips = []
    for t in targets:
        ips += af_scope.expand_ip_range(t, max_hosts=getattr(cfg, "max_hosts", None) or None)
    ips = list(dict.fromkeys(ips))
    log(f"{len(ips)} address(es) to probe")
    prog(1, f"discovering hosts among {len(ips)} address(es)")
    found = N.discover_hosts(ips, cfg, progress=lambda f, m: prog(2 + 18 * f, m), cancel=cancel, run=run)
    if cancel and cancel():
        raise N.Cancelled()
    devices = sorted(found.values(), key=lambda d: ipaddress.ip_address(d["ip"]))
    log(f"{len(devices)} host(s) alive")
    prog(21, f"{len(devices)} host(s) found; resolving names")
    _name_lookups(devices, cfg, cancel)
    done = [0]
    lock = threading.Lock()
    if cfg.tcp_ports() or cfg.udp:
        pc = N.ScanConfig(**{**cfg.__dict__, "concurrency": max(60, cfg.concurrency // max(cfg.host_concurrency, 1))})

        def one(d):
            if cancel and cancel():
                return
            try:
                N.scan_host(d["ip"], d, pc, cancel)
            except N.Cancelled:
                return
            except Exception as e:                            # a crash on one host must not abort the network scan
                d["notes"].append(f"port scan failed: {type(e).__name__}: {str(e)[:100]}")
            with lock:
                done[0] += 1
                prog(22 + 53 * done[0] / max(len(devices), 1), f"scanned {done[0]} of {len(devices)} hosts ({d['ip']}: {len(I._open(d))} open)")
        with ThreadPoolExecutor(max_workers=max(1, cfg.host_concurrency)) as ex:
            list(ex.map(one, devices))
        if cancel and cancel():
            raise N.Cancelled()
    if cfg.use_nmap and nmap_available():
        prog(76, "nmap fingerprinting")
        for d in devices:
            d["notes"].append("nmap: " + nmap_enrich(d, cfg, cancel=cancel))
    gws = N.default_gateways()
    nets = [n["cidr"] for n in N.local_networks() if not n["loopback"]]
    traces = {}
    if cfg.traceroute:
        prog(80, "tracing routes")
        picks, seen_nets = [], set()
        for d in devices:
            sn = I.subnet_of(d["ip"])
            if sn not in seen_nets and len(seen_nets) < 8:
                seen_nets.add(sn); picks.append(d["ip"])
        for ip in picks:
            if cancel and cancel():
                break
            traces[ip] = traceroute(ip, run=None)
    I.enrich_devices(devices, gws)
    stats = {"cve": None}
    if cve_fn and any(s.get("version") for d in devices for s in d["services"]):
        prog(85, "matching vulnerabilities")
        stats["cve"] = cve_fn(devices, lambda i, n, label: prog(85 + 10 * i / max(n, 1), f"CVE lookup {label}"))
        for d in devices:
            d.setdefault("cves", [])
    prog(96, "analysing")
    for d in devices:
        d["findings"] = I.device_findings(d) + I.cve_findings(d)
    local = N.local_networks()
    top = I.build_topology(devices, gws, next((n["ip"] for n in local if not n["loopback"]), local[0]["ip"] if local else ""), nets, traces)
    low = [d for d in devices if I.alive_confidence(d) == "low"]
    warnings = []
    if low and (len(low) >= max(3, 0.3 * len(devices))):
        warnings.append(f"{len(low)} of {len(devices)} hosts were detected only through TCP resets (no ICMP, ARP or open port). A firewall, proxy or "
                        "load balancer may be answering for hosts that do not exist - treat those as unconfirmed. Scanning from a machine on the same segment (ARP) is more reliable.")
    meta = {"targets": list(targets), "profile": cfg.profile, "udp": cfg.udp, "intensity": cfg.intensity, "started": started, "finished": utc_iso(),
            "duration": round(time.time() - t0, 1), "addresses_probed": len(ips), "ports_per_host": len(cfg.tcp_ports()), "nmap": bool(cfg.use_nmap and nmap_available()),
            "gateways": gws, "vendor_registry_entries": len(af_oui._table()), "warnings": warnings, "low_confidence_hosts": len(low)}
    result = {"meta": meta, "devices": devices, "topology": top, "diff": None, "findings": [], "stats": stats}
    result["findings"] = I.all_findings(devices)
    if conn is not None:
        prev = previous_scan(conn, targets)
        sid = save_scan(conn, result, username, auth_id)
        result["id"] = sid
        if prev:
            result["diff"] = I.diff_scans(prev["devices"], devices, scanned_ips=ips)
            result["findings"] += I.diff_findings(result["diff"])
    prog(100, f"done: {len(devices)} device(s), {sum(len(I._open(d)) for d in devices)} open port(s), {sum(len(d.get('cves', [])) for d in devices)} CVE(s)")
    return result


def to_ui_results(findings):
    """Finding dicts -> keys the main app's make_result()/Results tab use."""
    return [{"Host": f["host"], "Category": f["category"], "Check": f["check"], "Status": f["status"], "Risk": f["risk"], "Details": f["details"],
             "Recommendation": f["recommendation"], "MITRE": f["mitre"]} for f in findings]


# ---------------------------------------------------------------- background job
class NetJob:
    _lock = threading.Lock()
    registry = {}

    def __init__(self, targets, cfg, db_path=None, user="", auth_id=None, cve_fn=None, notify_fn=None, policy=None, resolver=None, run=None):
        self.id = uuid.uuid4().hex[:10]
        self.targets, self.cfg, self.user, self.auth_id = [t.strip() for t in targets if t.strip()], cfg, user, auth_id
        self.db_path, self.cve_fn, self.notify_fn, self.run = db_path or DB_PATH, cve_fn, notify_fn, run
        pol = policy or af_scope.load_policy()
        kw = {"resolver": resolver} if resolver else {}
        d = af_scope.evaluate(self.targets, pol, **kw)
        if not d.allowed:
            raise af_scope.ScopeError("; ".join(d.reasons))
        if d.needs_authorization and not auth_id:
            raise af_scope.ScopeError("public / external targets need a recorded scan authorization")
        self.state, self.pct, self.message, self.log_lines = "queued", 0.0, "", []
        self.result, self.error, self._cancel = None, "", threading.Event()
        self.started = self.finished = None
        self.thread = None

    def _log(self, m):
        self.log_lines.append(f"{utc_iso()} {m}")
        del self.log_lines[:-200]

    def _progress(self, pct, msg):
        self.pct, self.message = min(float(pct), 100.0), msg

    def start(self):
        with NetJob._lock:
            if any(j.state == "running" for j in NetJob.registry.values()):
                raise RuntimeError("another network scan is already running")
            NetJob.registry[self.id] = self
            self.state, self.started = "running", time.time()
        self.thread = threading.Thread(target=self._run, name=f"netjob-{self.id}", daemon=True)
        self.thread.start()
        return self

    def _run(self):
        conn = None
        try:
            conn = sqlite3.connect(str(self.db_path), timeout=30)
            self.result = run_scan(self.targets, self.cfg, self._progress, self._cancel.is_set, self.cve_fn, conn, self.user, self.auth_id, self.run, self._log)
            self.state = "done"
            if self.notify_fn:
                try:
                    self.notify_fn(self.result)
                except Exception as e:
                    self._log(f"notification failed: {type(e).__name__}")
        except N.Cancelled:
            self.state, self.message = "cancelled", "cancelled by user"
        except Exception as e:
            self.state, self.error = "failed", f"{type(e).__name__}: {e}"
            self._log(traceback.format_exc()[-1500:])
        finally:
            self.finished = time.time()
            if conn:
                conn.close()

    def cancel(self):
        self._cancel.set()
        self.message = "cancelling..."

    def status(self):
        el = (self.finished or time.time()) - (self.started or time.time())
        eta = (el * (100 - self.pct) / self.pct) if 3 < self.pct < 100 and self.state == "running" else None
        return {"id": self.id, "state": self.state, "pct": round(self.pct, 1), "message": self.message, "elapsed": round(el, 1), "eta": round(eta) if eta else None,
                "error": self.error, "log": self.log_lines[-12:], "targets": self.targets}

    @classmethod
    def latest(cls):
        return max(cls.registry.values(), key=lambda j: j.started or 0, default=None)

    @classmethod
    def get(cls, jid):
        return cls.registry.get(jid)
