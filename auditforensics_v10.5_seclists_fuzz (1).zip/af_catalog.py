#!/usr/bin/env python3
"""Check catalog: stable IDs plus title / rationale / remediation / framework mappings per check.

Entries live in checks_catalog.yaml (shipped) and any ``*.yaml`` in AF_HOME/catalog.d/ (yours; later files win):

  - id: AF-SSH-ssh-root-login          # stable; never rename. Exceptions and tickets can reference it.
    category: SSH
    title: SSH root login permitted
    match: ["SSH|SSH Root Login", "re:^SSH\\|.*root"]     # exact "Category|Check" strings, or regex with 're:'
    rationale: Direct root logins defeat per-user accountability.
    remediation: Set PermitRootLogin no in sshd_config.
    mitre: T1110
    frameworks: {NIST-800-53: [AC-6, AC-17], CIS: ["5.2.8"]}
    cis_benchmark: "CIS Ubuntu 22.04 5.2.8"
    stig: "V-238218"

``resolve_id`` returns the catalogued ID when an entry matches and otherwise a deterministic generated ID
(af_checks.make_check_id), so every finding has one. ``enrich`` fills missing fields from the catalog; frameworks
from the catalog are merged with (and take precedence over) the regex topic mapping used for uncatalogued checks.
python tools/gen_catalog.py  regenerates stubs for every check found in the code and reports catalog coverage.
"""
import re
from functools import lru_cache
from pathlib import Path

from af_checks import make_check_id
from af_util import af_home

try:
    import yaml
except ImportError:                                  # pragma: no cover
    yaml = None

SHIPPED = Path(__file__).with_name("checks_catalog.yaml")


def _files():
    fs = [SHIPPED] if SHIPPED.exists() else []
    d = af_home() / "catalog.d"
    return fs + (sorted(d.glob("*.yaml")) if d.is_dir() else [])


@lru_cache(maxsize=1)
def load_catalog():
    """-> (entries_by_id, exact_index {'cat|check': id}, regex_index [(compiled, id)])."""
    by_id, exact, rx = {}, {}, []
    if yaml is None:
        return by_id, exact, rx
    for f in _files():
        try:
            doc = yaml.safe_load(f.read_text()) or []
        except (OSError, yaml.YAMLError):
            continue
        for e in doc if isinstance(doc, list) else doc.get("checks", []):
            if not isinstance(e, dict) or not e.get("id"):
                continue
            by_id[e["id"]] = e
            for m in e.get("match", []) or []:
                if str(m).startswith("re:"):
                    try:
                        rx.insert(0, (re.compile(str(m)[3:], re.I), e["id"]))   # later files take precedence
                    except re.error:
                        pass
                else:
                    exact[str(m).lower()] = e["id"]
    return by_id, exact, rx


def reload():
    load_catalog.cache_clear()


def resolve_id(category, check):
    by_id, exact, rx = load_catalog()
    key = f"{category}|{check}"
    if key.lower() in exact:
        return exact[key.lower()]
    for pat, cid in rx:
        if pat.search(key):
            return cid
    return make_check_id(category, check)


def lookup(check_id):
    return load_catalog()[0].get(check_id)


def is_catalogued(category, check):
    by_id, exact, rx = load_catalog()
    key = f"{category}|{check}"
    return key.lower() in exact or any(p.search(key) for p, _ in rx)


def enrich(r):
    """UI-style result dict (Category/Check/...): set CheckID and fill gaps from the catalog. Idempotent."""
    cid = r.get("CheckID") or resolve_id(r.get("Category", ""), r.get("Check", ""))
    r["CheckID"] = cid
    e = lookup(cid)
    if not e:
        return r
    if e.get("remediation") and not r.get("Recommendation"):
        r["Recommendation"] = e["remediation"]
    if e.get("mitre") and not r.get("MITRE"):
        r["MITRE"] = e["mitre"]
    extra = dict(e.get("frameworks") or {})
    if e.get("cis_benchmark"):
        extra.setdefault("CIS-Benchmark", []).append(str(e["cis_benchmark"]))
    if e.get("stig"):
        extra.setdefault("DISA-STIG", []).append(str(e["stig"]))
    if extra:
        merged = {}
        for part in (r.get("Framework") or "").split(", "):
            if ":" in part:
                k, v = part.split(":", 1)
                merged.setdefault(k.strip(), [])
                merged[k.strip()] += [x for x in (s.strip() for s in v.split(",")) if x and x not in merged[k.strip()]]
        for k, ids in extra.items():
            lst = merged.setdefault(k, [])
            lst += [str(i) for i in ids if str(i) not in lst]
        r["Framework"] = ", ".join(f"{k}:{','.join(v)}" for k, v in merged.items())
    return r
